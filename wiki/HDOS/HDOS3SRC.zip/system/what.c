/*	.TITLE "what.c - find and display <what> strings"	*/
/*
**	program:	what.c
**
**	date:		October 3, 1986
**
**	purpose:	This program searches the given files for all
**			occurrences of the pattern @(#) and prints out
**			what follows until the first tilde (~), greater-
**			than-sign (>), new-line, backslash (\), or null
**			character.
**
**	usage:		what files
**
**	author:		Bill Parrott
**
**	history:
*/

/*
**	include files
*/

#include	"printf.h"

#define void	int
#define NULL	0

/*
**	local function declarations
*/

static void scan();
static int  iskey();
static void showwhat();
static char *strchr();

/*
**	local data
*/

static char what[]	= { "@(#)HDOS 3.0 WHAT Utility by Bill Parrott" };

static char delim[]	= { '~', '>', '\n', '\\', 0 };

static char *month[]	= { "Jan", "Feb", "Mar", "Apr", "May", "Jun",
			    "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
			  };

static int feof 	= 0;

/*	.SUBTITLE "main()"	.EJECT	*/

main( argc, argv )

int argc;
char *argv[];

{
	int infile;
	int f;

	if ( argc == 1 )
		{
		printf( "Usage:  WHAT files\n" );
		return ( 0 );
		}

	for ( f=1; f<argc; f++ )
		{
		printf( "\n%s:\n", argv[f] );
		feof = 0;
		if ( (infile = fopen( argv[f], "rb" )) == NULL )
			printf( "\tFile not found\n" );
		else
			scan( infile );
		}

	return ( 0 );
}


static void scan( f )

int f;

{
	while ( !feof )
		if ( iskey( f ) )
			showwhat( f );

	fclose( f );
}


static int iskey( f )

int f;

{
	int n;
	char ch;

	if ( (feof = ((ch = getc( f )) == -1)) )
		return ( 0 );

	if ( ch != what[0] )
		return ( 0 );

	for ( n=1; n<4; n++ )
		{
		if ( (feof = ((ch = getc( f )) == -1)) )
			return ( 0 );
		if ( ch != what[n] )
			return ( 0 );
		}

	return ( 1 );
}



static void showwhat( f )

int f;

{
	char ch, buf[4];
	int date, m, d, y;

	putchar( '\t' );

	while ( 1 )
		{
		if ( (feof = ((ch = getc( f )) == -1)) )
			break;

		if ( (ch == NULL) || (strchr(delim, ch))  )
			break;
		else
			putchar( ch );
		}

	putchar( '\n' );

	if ( ch == NULL )
		return;

	for ( m=0; m<4; m++ )
		if ( (feof = ((buf[m] = getc( f )) == -1)) )
			return;

	date = (buf[1] << 8) + buf[0];

	if ( date == 0 )
		return;

	y = ((date & 0x7E00) >> 9) + 70;
	m = ((date & 0x01E0) >> 5) - 1;
	d =  (date & 0x001F);

	printf( "\tassembled: %02d-%s-%2d at %02x:%02x\n", d, month[m], y, buf[2], buf[3] );
}



static char *strchr( s, c )

char *s, c;

{
	while ( *s )
		if ( *s++ == c )
			return ( --s );

	return ( 0 );
}



#asm
	XTEXT	PRINTF.ASM
#endif
