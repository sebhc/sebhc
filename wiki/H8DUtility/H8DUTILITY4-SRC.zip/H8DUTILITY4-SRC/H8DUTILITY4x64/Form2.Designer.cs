﻿namespace H8DUTILITY4x64
{
	partial class Form2
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			panel1 = new Panel();
			button2 = new Button();
			panel2 = new Panel();
			listBox1 = new ListBox();
			button1 = new Button();
			saveFileDialog1 = new SaveFileDialog();
			panel1.SuspendLayout();
			panel2.SuspendLayout();
			SuspendLayout();
			// 
			// panel1
			// 
			panel1.Controls.Add(button2);
			panel1.Controls.Add(panel2);
			panel1.Controls.Add(button1);
			panel1.Dock = DockStyle.Fill;
			panel1.Location = new Point(0, 0);
			panel1.Name = "panel1";
			panel1.Size = new Size(800, 450);
			panel1.TabIndex = 1;
			// 
			// button2
			// 
			button2.Enabled = false;
			button2.Location = new Point(713, 424);
			button2.Name = "button2";
			button2.Size = new Size(75, 23);
			button2.TabIndex = 3;
			button2.Text = "SAVE";
			button2.UseVisualStyleBackColor = true;
			button2.Click += button2_Click;
			// 
			// panel2
			// 
			panel2.Controls.Add(listBox1);
			panel2.Location = new Point(12, 0);
			panel2.Name = "panel2";
			panel2.Size = new Size(776, 418);
			panel2.TabIndex = 2;
			// 
			// listBox1
			// 
			listBox1.Dock = DockStyle.Fill;
			listBox1.Font = new Font("Consolas", 12F, FontStyle.Regular, GraphicsUnit.Point);
			listBox1.FormattingEnabled = true;
			listBox1.ItemHeight = 19;
			listBox1.Location = new Point(0, 0);
			listBox1.Name = "listBox1";
			listBox1.SelectionMode = SelectionMode.MultiSimple;
			listBox1.Size = new Size(776, 418);
			listBox1.TabIndex = 1;
			// 
			// button1
			// 
			button1.Location = new Point(374, 424);
			button1.Name = "button1";
			button1.Size = new Size(75, 23);
			button1.TabIndex = 0;
			button1.Text = "CLOSE";
			button1.UseVisualStyleBackColor = true;
			button1.Click += button1_Click;
			// 
			// Form2
			// 
			AutoScaleDimensions = new SizeF(7F, 15F);
			AutoScaleMode = AutoScaleMode.Font;
			ClientSize = new Size(800, 450);
			ControlBox = false;
			Controls.Add(panel1);
			FormBorderStyle = FormBorderStyle.FixedSingle;
			Name = "Form2";
			Text = "VIEW FILE";
			Load += Form2_Load;
			panel1.ResumeLayout(false);
			panel2.ResumeLayout(false);
			ResumeLayout(false);
		}

		#endregion

		private Panel panel1;
		private Panel panel2;
		private ListBox listBox1;
		private Button button1;
		private Button button2;
		private SaveFileDialog saveFileDialog1;
	}
}