﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;
using static System.Windows.Forms.LinkLabel;

namespace H8DUTILITY4x64
{
	public partial class Form2 : Form
	{
		public static Form2 thisForm = null;

		public Form2()
		{
			InitializeComponent();
			thisForm = this;
		}

		private void button1_Click(object sender, EventArgs e)
		{
			Form1.thisForm.Enabled = true;
			thisForm.Visible = false;
		}

		public void ResetListBox()
		{
			listBox1.Items.Clear();
			button2.Enabled = false;
		}

		public int FillListBox(string[] data)
		{
			for (int i = 0; i < data.Length; i++)
			{
				if (data[i].Length > 0 && data[i][0] == 0)
				{
					break;
				}
				listBox1.Items.Add(data[i]);
			}
			button2.Enabled = true;

			return listBox1.Items.Count;
		}

		private void Form2_Load(object sender, EventArgs e)
		{

		}

		private void button2_Click(object sender, EventArgs e)
		{
			saveFileDialog1.Filter = "Text Files | *.txt";
			saveFileDialog1.DefaultExt = "txt";

			DialogResult res = saveFileDialog1.ShowDialog();
			if (res == DialogResult.OK)
			{
				Debug.WriteLine(saveFileDialog1.FileName);

				List<string> textOutput = new List<string>();
				for (int i = 0; i < listBox1.Items.Count; i++)
				{
					textOutput.Add(listBox1.Items[i].ToString());
				}
				File.WriteAllLines(saveFileDialog1.FileName, textOutput.ToArray());
			}
		}
	}
}
