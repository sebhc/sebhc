﻿namespace H8DUTILITY4x64
{
	partial class Form3
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			comboBox1 = new ComboBox();
			comboBox2 = new ComboBox();
			progressBar1 = new ProgressBar();
			listBox1 = new ListBox();
			button1 = new Button();
			button2 = new Button();
			textBox1 = new TextBox();
			saveFileDialog1 = new SaveFileDialog();
			comboBox3 = new ComboBox();
			SuspendLayout();
			// 
			// comboBox1
			// 
			comboBox1.FormattingEnabled = true;
			comboBox1.Location = new Point(12, 0);
			comboBox1.Name = "comboBox1";
			comboBox1.Size = new Size(121, 23);
			comboBox1.TabIndex = 0;
			comboBox1.SelectedIndexChanged += comboBox1_SelectedIndexChanged;
			// 
			// comboBox2
			// 
			comboBox2.FormattingEnabled = true;
			comboBox2.Items.AddRange(new object[] { "4800", "9600", "38400" });
			comboBox2.Location = new Point(139, 0);
			comboBox2.Name = "comboBox2";
			comboBox2.Size = new Size(121, 23);
			comboBox2.TabIndex = 1;
			// 
			// progressBar1
			// 
			progressBar1.Location = new Point(0, 256);
			progressBar1.Name = "progressBar1";
			progressBar1.Size = new Size(615, 23);
			progressBar1.TabIndex = 5;
			// 
			// listBox1
			// 
			listBox1.Font = new Font("Consolas", 9F, FontStyle.Regular, GraphicsUnit.Point);
			listBox1.FormattingEnabled = true;
			listBox1.ItemHeight = 14;
			listBox1.Location = new Point(0, 29);
			listBox1.Name = "listBox1";
			listBox1.ScrollAlwaysVisible = true;
			listBox1.Size = new Size(615, 214);
			listBox1.TabIndex = 6;
			// 
			// button1
			// 
			button1.Location = new Point(540, 321);
			button1.Name = "button1";
			button1.Size = new Size(75, 23);
			button1.TabIndex = 7;
			button1.Text = "BEGIN";
			button1.UseVisualStyleBackColor = true;
			button1.Click += button1_Click;
			// 
			// button2
			// 
			button2.Location = new Point(12, 321);
			button2.Name = "button2";
			button2.Size = new Size(75, 23);
			button2.TabIndex = 8;
			button2.Text = "CANCEL";
			button2.UseVisualStyleBackColor = true;
			button2.Click += button2_Click;
			// 
			// textBox1
			// 
			textBox1.Location = new Point(0, 285);
			textBox1.Name = "textBox1";
			textBox1.ReadOnly = true;
			textBox1.Size = new Size(615, 23);
			textBox1.TabIndex = 9;
			// 
			// comboBox3
			// 
			comboBox3.FormattingEnabled = true;
			comboBox3.Items.AddRange(new object[] { "SY0:", "SY1:" });
			comboBox3.Location = new Point(266, 0);
			comboBox3.Name = "comboBox3";
			comboBox3.Size = new Size(121, 23);
			comboBox3.TabIndex = 10;
			// 
			// Form3
			// 
			AutoScaleDimensions = new SizeF(7F, 15F);
			AutoScaleMode = AutoScaleMode.Font;
			ClientSize = new Size(627, 356);
			ControlBox = false;
			Controls.Add(comboBox3);
			Controls.Add(textBox1);
			Controls.Add(button2);
			Controls.Add(button1);
			Controls.Add(listBox1);
			Controls.Add(progressBar1);
			Controls.Add(comboBox2);
			Controls.Add(comboBox1);
			Name = "Form3";
			Text = "IMAGER";
			ResumeLayout(false);
			PerformLayout();
		}

		#endregion

		private ComboBox comboBox1;
		private ComboBox comboBox2;
		private ProgressBar progressBar1;
		private ListBox listBox1;
		private Button button1;
		private Button button2;
		private TextBox textBox1;
		private SaveFileDialog saveFileDialog1;
		private ComboBox comboBox3;
	}
}