using System;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using static System.ComponentModel.Design.ObjectSelectorEditor;
using static System.Windows.Forms.DataFormats;
using static System.Windows.Forms.LinkLabel;

namespace H8DUTILITY4x64
{
	public partial class Form1 : Form
	{
		List<string> imageFileList = new List<string>();
		List<int> imageFileIndexList = new List<int>();

		string workingFolder = string.Empty;

		string settingsFileName = "SETTINGS.TXT";
		string[] settingsKey = { "WORKINGFOLDER=" };

		byte[] diskImageBytes;

		// 2S40T 00000900:65.CA.1A.08.01.18.01.04.01.20.0C.00.20.03.00.01
		// 2S40T 00000910:01
		// Valid DIR sectors
		// 1S40T 0x00DE00,0x00E200,0x00DC00,0x00E000,0x00E400,0x00E800,0x00EC00,0x00E600,0x00EA00,0x000000
		// 1S40T 0x008400,0x008800,0x008200,0x008600,0x008A00,0x008E00,0x009200,0x008C00,0x009000,0x000000
		// 2S40T 0x010800,0x010A00,0x010400,0x010600,0x010C00,0x010E00,0x011400,0x011600,0x011000,0x011200,0x000000
		// 2S80T 0x021800,0x021A00,0x021C00,0x021E00,0x021000,0x021200,0x021400,0x021600,0x022000,0x022200,0x022400,0x022600,0x000000
		public struct HDOSDiskInfo
		{
			public byte serial_num;         // 0x65
			public ushort init_date;        // 0x1ACA
			public long dir_sector;         // 0x0108 * 256
			public long grt_sector;         // 0x0118 * 256
			public byte sectors_per_group;  // 0x04
			public byte volume_type;        // 0x01
			public byte init_version;       // 0x20
			public long rgt_sector;         // 0x000C * 256
			public ushort volume_size;      // 0x0320
			public ushort phys_sector_size; // 0x0100
			public byte flags;              // 0x01
			public byte[] label;
			public ushort reserved;
			public byte sectors_per_track;
		}

		[StructLayout(LayoutKind.Sequential, Pack = 1)]
		public struct HDOSDirEntry
		{
			public byte[] filename;
			public byte[] fileext;
			public byte project;
			public byte version;
			public byte cluster_factor;
			public byte flags;
			public byte flags2;
			public byte first_group_num;
			public byte last_group_num;
			public byte last_sector_index;
			public ushort creation_date;
			public ushort alteration_date;
		}

		public struct DiskFileEntry
		{
			public int ListBox2Entry;
			public string DiskImageName;
			public string FileName;
			public HDOSDirEntry HDOSEntry;
		}

		public byte[] HDOSGrtTable;
		public byte[] FILEGrtAllocTable;
		private int HDOSSectorsPerGroup;
		private int HDOSDirOffset;
		private static string HDOSDiskLabel;
		private static string HDOSDiskVolume;

		private string extractDir = string.Empty;
		private int diskHash;

		private bool relabel;
		private string relabelImageFileName;

		public static Form thisForm;

		public Form1()
		{
			InitializeComponent();

			Form2 form2 = new Form2();
			form2.Visible = false;
			Form3 form3 = new Form3();
			form3.Visible = false;

			thisForm = this;
		}

		private void Form1_Load(object sender, EventArgs e)
		{
			LoadSettings();
		}

		private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
		{
			bool selected = listBox1.SelectedIndex != -1;
			button4.Enabled = selected;
			button11.Enabled = selected;
			button12.Enabled = selected;
			button13.Enabled = selected;

			button15.Enabled = false;
			button18.Enabled = false;
			button19.Enabled = false;
			if (listBox1.SelectedItems.Count == 1)
			{
				button15.Enabled = true;
				button18.Enabled = true;
				button19.Enabled = true;
			}
		}

		private void listBox2_SelectedIndexChanged(object sender, EventArgs e)
		{
			bool selected = listBox2.SelectedIndex != -1;
			button2.Enabled = selected;
			button8.Enabled = selected;
		}

		private void button1_Click(object sender, EventArgs e)
		{
			// add file
			// for CP/M call out to cpmcp with appropriate parameters: cpmcp [-f format] [-p] [-t] image file user:file
			// for HDOS must brute force it
			DialogResult r = openFileDialog1.ShowDialog();
			if (r == DialogResult.OK)
			{
				string imageName = listBox1.SelectedItem.ToString();
				string s = "ADD FILE(S) TO " + imageName + "?";
				if (MessageBox.Show(s, "ADD FILES TO IMAGE", MessageBoxButtons.YesNo) == DialogResult.Yes)
				{
					string[] files = openFileDialog1.FileNames;
					for (int i = 0; i < files.Length; i++)
					{
						string fileName = Path.GetFileNameWithoutExtension(files[i]);
						if (fileName.Length <= 8)
						{
							string fileExt = Path.GetExtension(files[i]);
							if (fileExt.Length <= 4)
							{
								// valid filename format
								Debug.WriteLine(files[i]);
								int idx = listBox1.SelectedIndex;
								string imageNameAndPath = imageFileList[idx];
								AddFilesToImage(imageNameAndPath, files[i]);
								button4_Click(sender, e);
							}
							else
							{
								Debug.WriteLine("FILE EXTENSION INVALID:" + fileExt);
							}
						}
						else
						{
							Debug.WriteLine("FILE NAME INVALID:" + fileName);
						}
					}

				}
			}
		}

		private void button2_Click(object sender, EventArgs e)
		{
			// view a file
			if (listBox2.SelectedItem != null)
			{
				string item = listBox2.SelectedItem.ToString();
				if (item.Length > 0 && !item.Contains("="))
				{
					thisForm.Enabled = false;
					Form2.thisForm.Visible = true;
					Form2.thisForm.ResetListBox();

					string selectedItem = listBox2.SelectedItem.ToString().Substring(0, 14).Trim();
					string[] sep = selectedItem.Split('.');
					selectedItem = sep[0].Trim() + "." + sep[1].Trim();

					int selectedIdx = listBox2.SelectedIndex;
					int imageIndex = imageFileIndexList[selectedIdx];
					string imageFile = imageFileList[imageIndex];

					string targetFile;
					if (IsHDOSDisk(imageFile))
					{
						targetFile = ExtractHDOSFile(imageFile, selectedItem);
					}
					else
					{
						targetFile = ExtractCPMFile(imageFile, selectedItem);
					}

					while (!File.Exists(targetFile))
					{
						// loop until file is available
						// this solves race conditions where sometimes the file is not immediately available to view
					}

					Debug.WriteLine(targetFile);

					byte[] data = File.ReadAllBytes(targetFile);
					bool isTextFile = true;
					for (int i = 0; i < 16; i++)
					{
						if (data[i] < 0x20 || data[i] > 0x7F)
						{
							if (data[i] != 0x09 && data[i] != 0x0D && data[i] != 0x0A)
							{
								isTextFile = false;
							}
						}
					}
					if (isTextFile)
					{
						// text file
						//Debug.WriteLine("View file: TEXT");

						string[] lines = File.ReadAllLines(targetFile);
						int numLines = Form2.thisForm.FillListBox(lines);

						Form2.thisForm.Text = "VIEW FILE " + selectedItem + " (" + numLines.ToString() + " LINES)";
					}
					else
					{
						// hex dump
						//Debug.WriteLine("View file: HEX");
						int lineCount = ViewInHex(data);

						Form2.thisForm.Text = "VIEW FILE " + selectedItem + " (" + lineCount.ToString() + " LINES)";
					}
					ShowResults("VIEWING " + selectedItem);
				}
				else
				{
					ShowResults("NOT A FILE");
				}
			}
		}

		private void button3_Click(object sender, EventArgs e)
		{
			// pick working folder
			DialogResult r = folderBrowserDialog1.ShowDialog();
			if (r == DialogResult.OK)
			{
				workingFolder = folderBrowserDialog1.SelectedPath;
				SaveSettings();

				GetWorkingFolderFileList();
			}
		}

		private void button4_Click(object sender, EventArgs e)
		{
			// list contents of disk image
			listBox2.Items.Clear();
			imageFileIndexList.Clear();

			ListBox.SelectedObjectCollection selectedItems = listBox1.SelectedItems;
			ListBox.SelectedIndexCollection selectedIndices = listBox1.SelectedIndices;

			button1.Enabled = true;
			button5.Enabled = true;

			if (selectedItems.Count > 20)
			{
				progressBar1.Visible = true;
			}
			progressBar1.Minimum = 0;
			progressBar1.Maximum = selectedItems.Count;
			progressBar1.Step = 1;
			progressBar1.Value = 0;
			progressBar1.Refresh();

			Application.DoEvents();

			for (int i = 0; i < selectedItems.Count; i++)
			{
				int idx = int.Parse(selectedIndices[i].ToString());
				string fileNameAndPath = imageFileList[idx];
				string fileNameTitle = string.Format("=== {0} ===", Path.GetFileName(fileNameAndPath));
				listBox2.Items.Add(fileNameTitle);
				imageFileIndexList.Add(idx);

				string[] files;

				int totalSize;
				int maxSize;

				bool isHDOS = IsHDOSDisk(fileNameAndPath);
				if (isHDOS)
				{
					Debug.WriteLine("HDOS DISK IMAGE " + fileNameAndPath);

					files = GetHDOSFileList();
					totalSize = 0;
					maxSize = (diskImageBytes.Length / 256) - 32;
				}
				else
				{
					Debug.WriteLine("CP/M DISK IMAGE " + fileNameAndPath);

					files = GetCPMFileList(fileNameAndPath);
					totalSize = 0;
					maxSize = (diskImageBytes.Length / 1024) - 10;
				}

				textBox4.Text = "[" + HDOSDiskVolume + "] " + HDOSDiskLabel;

				// 01234567890123456789012345678901234567890
				// -rwxrwxrwx   13824 Dec 31 1969  as.com
				for (int j = 0; j < files.Length; j++)
				{
					if (files[j].Length > 8)
					{
						string fileSize = files[j].Substring(10, 8).Trim();
						string fileName = files[j].Substring(32).ToUpper();
						string[] sep = fileName.Split('.');
						if (sep.Length == 2)
						{
							fileName = string.Format("{0,-8}.{1,-3}", sep[0], sep[1]);
						}
						else
						{
							if (fileName.Contains('.'))
							{
								fileName = string.Format("        " + fileName);
							}
							else
							{
								fileName = string.Format("{0,-8}.   ", fileName);
							}
						}
						string s = string.Format("{0,14} {1,10:N0}", fileName, int.Parse(fileSize));
						listBox2.Items.Add(s);
						imageFileIndexList.Add(idx);

						if (isHDOS && fileName.Contains("RGT") && fileName.Contains(".SYS"))
						{
							// skip size
						}
						else if (isHDOS && fileName.Contains("GRT") && fileName.Contains(".SYS"))
						{
							// skip size
						}
						else if (isHDOS && fileName.Contains("DIRECT") && fileName.Contains(".SYS"))
						{
							// skip size
						}
						else
						{
							int sizeDivisor = (isHDOS) ? 1 : 1024;
							totalSize += int.Parse(fileSize) / sizeDivisor;
						}
					}
				}
				string totals = string.Format("=== FILES={0:D3} SIZE={1:D4}/{2:D4} ===", files.Length - 1, totalSize, maxSize);
				listBox2.Items.Add(totals);
				imageFileIndexList.Add(idx);

				listBox2.Items.Add(string.Empty);
				imageFileIndexList.Add(idx);

				progressBar1.PerformStep();
				progressBar1.Refresh();

				Application.DoEvents();
			}

			progressBar1.Visible = false;

			bool selected = listBox2.Items.Count > 0;
			button6.Enabled = selected;
			button7.Enabled = selected;
		}

		private void button5_Click(object sender, EventArgs e)
		{
			// extract item
			if (listBox2.Items.Count > 0)
			{
				ListBox.SelectedObjectCollection selectedItems = listBox2.SelectedItems;

				if (selectedItems.Count == 0)
				{
					for (int i = 0; i < listBox2.Items.Count; i++)
					{
						if (listBox2.Items[i].ToString().Length > 0 && !listBox2.Items[i].ToString().Contains("="))
						{
							listBox2.SetSelected(i, true);
						}
					}

					listBox2.Refresh();

					selectedItems = listBox2.SelectedItems;
				}

				if (selectedItems.Count > 0)
				{
					int count = 0;
					for (int i = 0; i < selectedItems.Count; i++)
					{
						string item = selectedItems[i].ToString();
						if (item.Length > 0 && !item.Contains("="))
						{
							count++;
						}
					}

					if (MessageBox.Show("EXTRACT " + count.ToString() + " FILES?", "EXTRACT FILES", MessageBoxButtons.YesNo) == DialogResult.Yes)
					{
						ListBox.SelectedIndexCollection selectedIndices = listBox2.SelectedIndices;
						for (int i = 0; i < selectedItems.Count; i++)
						{
							string item = selectedItems[i].ToString();
							if (item.Length > 0 && !item.Contains("="))
							{
								int idx = int.Parse(selectedIndices[i].ToString());
								int imageIdx = imageFileIndexList[idx];
								string imageFileName = imageFileList[imageIdx];

								string s = item.Substring(0, 14);
								string[] sep = s.Split('.');
								s = sep[0].Trim() + "." + sep[1].Trim();

								if (IsHDOSDisk(imageFileName))
								{
									ExtractHDOSFile(imageFileName, s);
								}
								else
								{
									ExtractCPMFile(imageFileName, s);
								}
							}
						}

						ShowResults("EXTRACTED TO " + extractDir.ToUpper());
					}
					else
					{
						ShowResults("NO FILES EXTRACTED");
					}
				}
			}
		}

		private void button6_Click(object sender, EventArgs e)
		{
			// save file listing as text file
			if (listBox2.Items.Count > 0)
			{
				List<string> textList = new List<string>();

				string s = "DISK IMAGE CATALOG";
				textList.Add(s);
				textList.Add(string.Empty);

				for (int i = 0; i < listBox2.Items.Count; i++)
				{
					s = listBox2.Items[i].ToString();
					textList.Add(s);
				}

				textList.Add(string.Empty);
				textList.Add(string.Empty);

				s = "Created by H8DUTILITY 4 on " + DateTime.Now.ToShortDateString();
				textList.Add(s);

				string fileName = Path.Combine(textBox1.Text, "H8DCATALOG.TXT");
				File.WriteAllLines(fileName, textList.ToArray());

				ShowResults("TEXT FILE LIST SAVED TO " + fileName);
			}
		}

		private void button7_Click(object sender, EventArgs e)
		{
			// save file listing as HTML file
			/*
				<!DOCTYPE html>
				<html>
				<body>
				<center>
				<pre>
				<h2>DISK IMAGE CATALOG</h2>
				<hr>
				<h3>
				CPM_2_2_03_DISTRIBUTION\CPM_2_2_DISTRIBUTION_1
				</h3>
				SUBMIT  .COM 002K
				SYSGEN  .COM 002K
				XSUB    .COM 001K
				<h3>
				USED=84K FREE=6K
				</h3>
				<hr>
				<h3>TOTAL DISKS=855 TOTAL FILES=14520</h3>
				<h4>Created by H8DUTILITY 3 on 7/6/2023</h4>
				<hr>
				</pre>
				</center>
				</body>
				</html>
			*/

			List<string> htmlData = new List<string>();
			htmlData.Add("<!DOCTYPE html>");
			htmlData.Add("<html>");
			htmlData.Add("<body>");
			htmlData.Add("<center>");
			htmlData.Add("<pre>");

			htmlData.Add("<h2>DISK IMAGE CATALOG</h2>");

			int diskCount = 0;
			int fileCount = 0;
			int lastIdx = -1;

			for (int i = 0; i < listBox2.Items.Count; i++)
			{
				string item = listBox2.Items[i].ToString();
				int idx = imageFileIndexList[i];
				if (idx != lastIdx)
				{
					lastIdx = idx;
					// header
					htmlData.Add("<hr>");
					htmlData.Add("<h3>");
					htmlData.Add(item.Trim());
					htmlData.Add("</h3>");
					diskCount++;
				}
				else if (item.Contains('='))
				{
					// footer
					htmlData.Add("<h3>");
					htmlData.Add(item.Trim());
					htmlData.Add("</h3>");
				}
				else
				{
					// file data
					htmlData.Add(item);
					fileCount++;
				}
			}

			htmlData.Add("<hr>");

			string s = "<h3>TOTAL DISKS=" + diskCount.ToString() + " TOTAL FILES=" + fileCount.ToString() + "</h3>";
			htmlData.Add(s);

			htmlData.Add("<h4>Created by H8DUTILITY 4 on " + DateTime.Now.ToShortDateString() + "</h4>");

			htmlData.Add("<hr>");
			htmlData.Add("</pre>");
			htmlData.Add("</center>");
			htmlData.Add("</body>");
			htmlData.Add("</html>");

			string path = workingFolder;
			string filePath = System.IO.Path.Combine(path, "H8DCATALOG.HTML");

			Debug.WriteLine("SaveHTML() filePath=" + filePath);

			if (File.Exists(filePath))
			{
				File.Delete(filePath);
			}
			File.WriteAllLines(filePath, htmlData.ToArray());

			ShowResults("HTML FILE LIST SAVED TO " + filePath);
		}

		private void button8_Click(object sender, EventArgs e)
		{
			// delete a file from a disk image
			ListBox.SelectedIndexCollection idx = listBox2.SelectedIndices;

			string msgBoxText = "DELETE " + idx.Count.ToString() + " FILES?";
			if (MessageBox.Show(msgBoxText, "DELETE FILE(S)", MessageBoxButtons.YesNo) == DialogResult.Yes)
			{
				for (int i = 0; i < idx.Count; i++)
				{
					string[] sep = listBox2.SelectedItems[i].ToString().Split('.');
					string fileName = sep[0].Trim();
					string fileExt = sep[1].Substring(0, 3).Trim();
					fileName = fileName + "." + fileExt;
					string imageFile = imageFileList[imageFileIndexList[idx[i]]];
					DeleteFileFromImage(imageFile, fileName);
				}
				button4_Click(sender, e);
			}
		}

		private void button9_Click(object sender, EventArgs e)
		{
			// clear listBox1 selections
			listBox1.ClearSelected();
			button12.Enabled = false;
		}

		private void button10_Click(object sender, EventArgs e)
		{
			// clear listBox2 selections
			listBox2.ClearSelected();
		}

		private void button11_Click(object sender, EventArgs e)
		{
			// view disk image in HEX format
			if (listBox1.SelectedItem != null)
			{
				thisForm.Enabled = false;
				Form2.thisForm.Visible = true;
				Form2.thisForm.ResetListBox();

				int selectedIdx = listBox1.SelectedIndex;
				string imageFile = imageFileList[selectedIdx];

				if (File.Exists(imageFile))
				{
					Form2.thisForm.Refresh();

					byte[] data = File.ReadAllBytes(imageFile);
					int lineCount = ViewInHex(data);

					string fileName = Path.GetFileName(imageFile);
					Form2.thisForm.Text = "VIEW FILE " + fileName + " (" + lineCount.ToString() + " LINES)";
				}
			}
		}

		private void button12_Click(object sender, EventArgs e)
		{
			// duplicate a disk image
			if (listBox1.SelectedIndex != -1)
			{
				string imageFileName = imageFileList[listBox1.SelectedIndex];
				if (File.Exists(imageFileName))
				{
					byte[] dataBuf = File.ReadAllBytes(imageFileName);
					string fileName = Path.GetFileNameWithoutExtension(imageFileName);
					string fileExt = Path.GetExtension(imageFileName);
					fileName += "-DUP";
					string outFileName = Path.GetDirectoryName(imageFileName);
					outFileName = Path.Combine(outFileName, fileName + fileExt);
					//Debug.WriteLine("NEW FILENAME:" + outFileName);
					File.WriteAllBytes(outFileName, dataBuf);

					GetWorkingFolderFileList();
				}
			}
		}

		private void button13_Click(object sender, EventArgs e)
		{
			// delete a disk image
			ListBox.SelectedIndexCollection idx = listBox1.SelectedIndices;
			if (idx.Count > 0)
			{
				string msgBoxText = "DELETE " + idx.Count.ToString() + " DISK IMAGES(S)?";
				if (MessageBox.Show(msgBoxText, "DELETE IMAGE FILE", MessageBoxButtons.YesNo) == DialogResult.Yes)
				{
					for (int i = 0; i < idx.Count; i++)
					{
						string imageFileName = imageFileList[idx[i]];
						File.Delete(imageFileName);
					}
					GetWorkingFolderFileList();
				}
			}
		}

		private void button14_Click(object sender, EventArgs e)
		{
			string msgBoxText = "This action will standardize all image file names by doing the following:\n" +
				"(1) use the disk label if it is an HDOS disk\n" +
				"(2) keep the same name if it is a CP/M disk\n" +
				"(3) use underscores as separators\n" +
				"(4) append a checksum to the end of all image file names\n" +
				"WOULD YOU LIKE TO PROCEED?";
			if (MessageBox.Show(msgBoxText, "RENAME ALL IMAGES", MessageBoxButtons.YesNo) == DialogResult.Yes)
			{
				msgBoxText = "ALL DISK IMAGES WILL BE RENAMED IN-PLACE\n" +
					"CONTINUE?";
				if (MessageBox.Show(msgBoxText, "CONTINUE WITH RENAME?", MessageBoxButtons.OKCancel) == DialogResult.OK)
				{
					listBox2.Items.Clear();
					imageFileIndexList.Clear();

					for (int i = 0; i < imageFileList.Count; i++)
					{
						listBox1.SetSelected(i, true);
						listBox1.Refresh();

						RenameDiskImage(i);
					}

					GetWorkingFolderFileList();
				}
			}
		}

		private void button15_Click(object sender, EventArgs e)
		{
			// send image to H8DIMGR on port 340Q
			thisForm.Enabled = false;

			int idx = listBox1.SelectedIndex;
			if (idx >= 0)
			{
				Form3.thisForm.Visible = true;
				Form3.thisForm.SendDiskImage(imageFileList[idx]);
			}
		}

		private void button16_Click(object sender, EventArgs e)
		{
			// recv image from H8DIMGR on port 340Q
			thisForm.Enabled = false;

			Form3.thisForm.Visible = true;
			Form3.thisForm.ReceiveDiskImage();
		}

		private void button17_Click(object sender, EventArgs e)
		{
			// select all button
			for (int i = 0; i < listBox1.Items.Count; i++)
			{
				listBox1.SetSelected(i, true);
			}
		}

		private void button18_Click(object sender, EventArgs e)
		{
			// save selected image as
			int idx = listBox1.SelectedIndex;
			if (idx >= 0)
			{
				string fileName = Path.GetFileName(imageFileList[idx]);

				Debug.WriteLine(fileName);

				saveFileDialog1.Filter = "H8D Files | *.H8D";
				saveFileDialog1.DefaultExt = "H8D";
				saveFileDialog1.FileName = fileName;
				if (saveFileDialog1.ShowDialog() == DialogResult.OK)
				{
					// load file, delete old file, save as new file, update listbox
					int minDiskSize = 2560 * 40;
					byte[] imageBytes = File.ReadAllBytes(imageFileList[idx]);
					if (imageBytes.Length >= minDiskSize)
					{
						File.WriteAllBytes(saveFileDialog1.FileName, imageBytes);
						GetWorkingFolderFileList();
					}
				}
			}
		}

		private void button19_Click(object sender, EventArgs e)
		{
			relabelImageFileName = imageFileList[listBox1.SelectedIndex];
			if (IsHDOSDisk(relabelImageFileName))
			{
				// relabel an HDOS disk
				textBox4.ReadOnly = false;
				textBox4.Text = HDOSDiskLabel;
				textBox4.MaxLength = 60;
				textBox4.Select();

				relabel = true;
			}
			else
			{
				ShowResults("NOT AN HDOS DISK IMAGE");
			}
		}

		private void textBox4_KeyDown(object sender, KeyEventArgs e)
		{
			if (e.KeyCode == Keys.Enter || e.KeyCode == Keys.Return)
			{
				if (relabel)
				{
					string labelPadded = textBox4.Text.PadRight(60, ' ');
					byte[] labelName = UTF8Encoding.UTF8.GetBytes(labelPadded);
					Buffer.BlockCopy(labelName, 0, diskImageBytes, 0x911, labelName.Length);

					File.WriteAllBytes(relabelImageFileName, diskImageBytes);

					HDOSDiskLabel = GetHDOSLabel(diskImageBytes);

					textBox4.MaxLength = 32767;
					textBox4.Text = "[" + HDOSDiskVolume + "] " + HDOSDiskLabel;
					textBox4.ReadOnly = true;

					ShowResults("DISK LABEL CHANGED TO: " + HDOSDiskLabel);

					relabel = false;
				}
			}
		}

		private void GetWorkingFolderFileList()
		{
			imageFileList.Clear();
			imageFileIndexList.Clear();
			listBox1.Items.Clear();
			listBox2.Items.Clear();

			button11.Enabled = false;
			button12.Enabled = false;
			button13.Enabled = false;
			button14.Enabled = false;

			textBox1.Text = workingFolder;
			string[] workingFolderPathSep = workingFolder.Split(Path.DirectorySeparatorChar);

			string[] dirArray = Directory.GetDirectories(workingFolder);
			for (int i = 0; i < dirArray.Length; i++)
			{
				string[] fileArray = Directory.GetFiles(dirArray[i], "*.H8D");
				for (int j = 0; j < fileArray.Length; j++)
				{
					string fileNameAndPath = fileArray[j].ToUpper();
					imageFileList.Add(fileNameAndPath);
					//string fileName = Path.GetFileName(fileNameAndPath);
					//listBox1.Items.Add(fileName);
				}
			}

			string[] localFileArray = Directory.GetFiles(workingFolder, "*.H8D");
			for (int i = 0; i < localFileArray.Length; i++)
			{
				string fileNameAndPath = localFileArray[i].ToUpper();
				imageFileList.Add(fileNameAndPath);
			}

			if (imageFileList.Count > 0)
			{
				imageFileList.Sort();

				for (int i = 0; i < imageFileList.Count; i++)
				{
					string fileName = Path.GetFileName(imageFileList[i]);
					string[] pathSep = imageFileList[i].Split(Path.DirectorySeparatorChar);
					if (pathSep.Length > 2)
					{
						if (!pathSep[pathSep.Length - 2].Equals(workingFolderPathSep[workingFolderPathSep.Length - 1]))
						{
							fileName = pathSep[pathSep.Length - 2] + Path.DirectorySeparatorChar + fileName;
						}
					}
					listBox1.Items.Add(fileName);
				}

				button14.Enabled = true;
			}

			textBox3.Text = "TOTAL IMAGES " + listBox1.Items.Count.ToString();
		}

		private string GetCPMDiskFormat(int numBytes)
		{
			string format = "-f h8d1s40t ";
			if (numBytes / 1024 > 300)
			{
				format = "-f h8d2s80t ";
			}
			else if (numBytes / 1024 > 150)
			{
				format = "-f h8d2s40t ";
			}

			return format;
		}

		private string[] GetCPMFileList(string fileNameAndPath)
		{
			string format = GetCPMDiskFormat(diskImageBytes.Length);

			Process proc = new Process();

			proc.StartInfo.FileName = "cpmls.exe";

			proc.StartInfo.Arguments = format + "-l " + fileNameAndPath;
			proc.StartInfo.CreateNoWindow = true;
			proc.StartInfo.UseShellExecute = false;
			proc.StartInfo.RedirectStandardOutput = true;

			proc.Start();
			string output = proc.StandardOutput.ReadToEnd();
			string[] outputArray = output.Split(Environment.NewLine);

			proc.WaitForExit();

			return outputArray;
		}

		private string ExtractCPMFile(string imageNameAndPath, string fileName)
		{
			string[] sep = fileName.Split('.');
			fileName = sep[0].Trim() + "." + sep[1].Trim();

			Debug.WriteLine("ExtractCPMFile() imageNameAndPath=" + imageNameAndPath + " fileName=" + fileName);

			string targetFile = GetExtractTargetDir(imageNameAndPath, fileName);

			Debug.WriteLine("targetFile=" + targetFile);

			string format = GetCPMDiskFormat(diskImageBytes.Length);

			Process proc = new Process();

			// test.exe is a console application generated by VC6
			proc.StartInfo.FileName = "cpmcp.exe"; // @'C:\test\test.exe';

			proc.StartInfo.Arguments = format + imageNameAndPath + " 0:" + fileName + " " + targetFile;
			proc.StartInfo.CreateNoWindow = true;
			proc.StartInfo.UseShellExecute = false;
			proc.StartInfo.RedirectStandardOutput = true;

			proc.Start();

			proc.WaitForExit();

			return targetFile;
		}

		private HDOSDiskInfo GetHDOSDiskInfo()
		{
			HDOSDiskInfo diskInfo = new HDOSDiskInfo();
			diskInfo.label = new byte[60];
			int idx = 0x900;
			diskInfo.serial_num = diskImageBytes[idx++];
			diskInfo.init_date = BitConverter.ToUInt16(diskImageBytes, idx);
			idx += 2;
			diskInfo.dir_sector = BitConverter.ToUInt16(diskImageBytes, idx) * 256;
			idx += 2;
			diskInfo.grt_sector = BitConverter.ToUInt16(diskImageBytes, idx) * 256;
			idx += 2;
			diskInfo.sectors_per_group = diskImageBytes[idx++];
			diskInfo.volume_type = diskImageBytes[idx++];
			diskInfo.init_version = diskImageBytes[idx++];
			diskInfo.rgt_sector = BitConverter.ToUInt16(diskImageBytes, idx) * 256;
			idx += 2;
			diskInfo.volume_size = BitConverter.ToUInt16(diskImageBytes, idx);
			idx += 2;
			diskInfo.phys_sector_size = BitConverter.ToUInt16(diskImageBytes, idx);
			idx += 2;
			diskInfo.flags = diskImageBytes[idx++];
			Buffer.BlockCopy(diskImageBytes, idx, diskInfo.label, 0, 60);
			idx += 60;
			diskInfo.reserved = BitConverter.ToUInt16(diskImageBytes, idx);
			idx += 2;
			diskInfo.sectors_per_track = diskImageBytes[idx++];

			//string disk_label = string.Format("{0}", Encoding.UTF8.GetString(diskInfo.label, 0, 60));
			//disk_label = disk_label.Trim();

			HDOSGrtTable = new byte[256];
			Buffer.BlockCopy(diskImageBytes, (int)diskInfo.grt_sector, HDOSGrtTable, 0, 256);

			// used to compute disk free space size
			HDOSSectorsPerGroup = diskInfo.sectors_per_group;

			return diskInfo;
		}

		private HDOSDirEntry GetHDOSDirEntry(HDOSDiskInfo disk_info, string fileName)
		{
			List<int> nextDirBlockList = new List<int>();

			HDOSDirEntry entry = new HDOSDirEntry();
			entry.fileext = new byte[3];
			entry.filename = new byte[8];

			//Debug.WriteLine("GetHDOSDirEntry() searching for " + fname + "." + ext);

			int entry_count = 0;
			int offset = (int)disk_info.dir_sector;

			while (true)
			{
				HDOSDirOffset = offset;
				// try to read a valid directory entry skipping all empty entries
				Buffer.BlockCopy(diskImageBytes, offset, entry.filename, 0, 8);
				offset += 8;
				Buffer.BlockCopy(diskImageBytes, offset, entry.fileext, 0, 3);
				offset += 3;

				entry.project = diskImageBytes[offset++];
				entry.version = diskImageBytes[offset++];
				entry.cluster_factor = diskImageBytes[offset++];
				entry.flags = diskImageBytes[offset++];
				entry.flags2 = diskImageBytes[offset++];
				entry.first_group_num = diskImageBytes[offset++];
				entry.last_group_num = diskImageBytes[offset++];
				entry.last_sector_index = diskImageBytes[offset++];
				entry.creation_date = BitConverter.ToUInt16(diskImageBytes, offset);
				offset += 2;
				entry.alteration_date = BitConverter.ToUInt16(diskImageBytes, offset);
				offset += 2;

				entry_count++;
				if (entry_count == 22)
				{
					int max_entries = BitConverter.ToUInt16(diskImageBytes, offset);
					offset += 2;
					int cur_dir_blk = BitConverter.ToUInt16(diskImageBytes, offset) * 256;
					offset += 2;
					int nxt_dir_blk = BitConverter.ToUInt16(diskImageBytes, offset) * 256;
					offset += 2;
					offset = nxt_dir_blk;
					// prevent endless loop in case of corrupt directory structure
					if (nextDirBlockList.Contains(offset))
					{
						offset = 0;
					}
					else
					{
						nextDirBlockList.Add(offset);
					}
					entry_count = 0;
					//Debug.Log("offset=" + offset.ToString("X"));
				}
				// if looking for a file break if we find it else continue until first empty directory is found
				if (string.IsNullOrEmpty(fileName))
				{
					// looking for first available directory entry
					if (offset == 0 || entry.filename[0] == 0xFE || entry.filename[0] == 0xFF)
					{
						break;
					}
				}
				else
				{
					if (offset == 0 || entry.filename[0] == 0xFE)
					{
						break;
					}
					if (entry.filename[0] == 0xFF)
					{
						// empty entry - try next file
						continue;
					}

					string[] sep = fileName.Split('.');
					string fname = sep[0].Trim();
					string ext = sep[1].Trim();

					string f = Encoding.UTF8.GetString(entry.filename, 0, 8).Replace('\0', ' ').Trim();
					string e = Encoding.UTF8.GetString(entry.fileext, 0, 3).Replace('\0', ' ').Trim();
					if (f.Equals(fname) && e.Equals(ext))
					{
						// got correct file? return results otherwise keep searching
						break;
					}
				}

				//Debug.WriteLine("GetHDOSDirEntry() " + f + "." + e + " does not match, skipping");
			}

			return entry;
		}

		// Valid DIR sectors
		// 1S40T 0x00DE00,0x00E200,0x00DC00,0x00E000,0x00E400,0x00E800,0x00EC00,0x00E600,0x00EA00,0x000000
		// 1S40T 0x008400,0x008800,0x008200,0x008600,0x008A00,0x008E00,0x009200,0x008C00,0x009000,0x000000
		// 2S40T 0x010800,0x010A00,0x010400,0x010600,0x010C00,0x010E00,0x011400,0x011600,0x011000,0x011200,0x000000
		// 2S80T 0x021800,0x021A00,0x021C00,0x021E00,0x021000,0x021200,0x021400,0x021600,0x022000,0x022200,0x022400,0x022600,0x000000
		private List<string> ReadHDOSDiskContents(HDOSDiskInfo disk_info)
		{
			int offset = (int)disk_info.dir_sector;
			int entry_count = 0;
			int diskTotalSize = 0;
			List<int> nextDirBlockList = new List<int>();
			List<string> diskContents = new List<string>();

			int[] validDirSectorArray = {
				0x00DE00, 0x00E200, 0x00DC00, 0x00E000, 0x00E400, 0x00E800, 0x00EC00, 0x00E600, 0x00EA00, 0x000000,
				0x008400, 0x008800, 0x008200, 0x008600, 0x008A00, 0x008E00, 0x009200, 0x008C00, 0x009000, 0x000000,
				0x010800, 0x010A00, 0x010400, 0x010600, 0x010C00, 0x010E00, 0x011400, 0x011600, 0x011000, 0x011200, 0x000000,
				0x021800, 0x021A00, 0x021C00, 0x021E00, 0x021000, 0x021200, 0x021400, 0x021600, 0x022000, 0x022200, 0x022400, 0x022600, 0x000000
			};
			List<int> validDirSectors = new List<int>(validDirSectorArray);

			int nxt_dir_sector = 0;
			int nxt_dir_index = validDirSectors.IndexOf(offset);
			if (nxt_dir_index != -1)
			{
				nxt_dir_index++;
				nxt_dir_sector = validDirSectors[nxt_dir_index];
			}

			Debug.WriteLine("START DIR BLK=" + offset.ToString("X8") + " NEXT DIR BLK=" + nxt_dir_sector.ToString("X8"));

			while (true)
			{
				if (offset == 0)
				{
					break;
				}

				HDOSDirEntry entry = new HDOSDirEntry();
				entry.fileext = new byte[3];
				entry.filename = new byte[8];

				int cur_dir_sector = offset;

				while (true)
				{
					// try to read a valid directory entry skipping all empty entries
					Buffer.BlockCopy(diskImageBytes, offset, entry.filename, 0, 8);
					offset += 8;
					Buffer.BlockCopy(diskImageBytes, offset, entry.fileext, 0, 3);
					offset += 3;

					entry.project = diskImageBytes[offset++];
					entry.version = diskImageBytes[offset++];
					entry.cluster_factor = diskImageBytes[offset++];
					entry.flags = diskImageBytes[offset++];
					entry.flags2 = diskImageBytes[offset++];
					entry.first_group_num = diskImageBytes[offset++];
					entry.last_group_num = diskImageBytes[offset++];
					entry.last_sector_index = diskImageBytes[offset++];
					entry.creation_date = BitConverter.ToUInt16(diskImageBytes, offset);
					offset += 2;
					entry.alteration_date = BitConverter.ToUInt16(diskImageBytes, offset);
					offset += 2;

					entry_count++;

					if (entry.project == 0 && entry.version == 0 && entry.cluster_factor == 3 && entry.flags2 == 0)
					{
						// valid directory entry - proceed
					}
					else
					{
						if (entry.flags == 0xF0 || entry.flags == 0xE0)
						{
							// RGT.SYS, GRT.SYS, DIRECT.SYS
						}
						else if (entry.filename[0] != 0xFF && entry.filename[0] != 0xFE)
						{
							// invalid entry - treat like empty directory entry
							entry.filename[0] = 0xFF;
						}
					}

					if (entry_count == 22)
					{
						int max_entries = BitConverter.ToUInt16(diskImageBytes, offset);
						offset += 2;
						int cur_dir_blk = BitConverter.ToUInt16(diskImageBytes, offset) * 256;
						offset += 2;
						int nxt_dir_blk = BitConverter.ToUInt16(diskImageBytes, offset) * 256;
						offset += 2;
						offset = nxt_dir_blk;

						// this is for verification purposes to make sure directory is not corrupt
						if (offset != 0 && !validDirSectors.Contains(offset))
						{
							// next dir block is unexpected so force to the next valid entry
							Debug.WriteLine("** NXT DIR BLOCK UNEXPECTED: GOT " + offset.ToString("X8") + " INSTEAD OF " + nxt_dir_sector.ToString("X8"));

							nxt_dir_index = validDirSectors.IndexOf(cur_dir_sector);
							offset = validDirSectors[nxt_dir_index + 1];

							Debug.WriteLine("** NXT DIR BLOCK RESET TO " + offset.ToString("X8"));
						}

						cur_dir_sector = offset;

						if (offset != 0)
						{
							nxt_dir_index = validDirSectors.IndexOf(offset);
							nxt_dir_sector = validDirSectors[nxt_dir_index + 1];

							// prevent endless loop in case of corrupt directory structure
							if (nextDirBlockList.Contains(offset))
							{
								offset = 0;
							}
							else if (!validDirSectors.Contains(offset))
							{
								Debug.WriteLine("** DIR SECTOR " + offset.ToString("X8") + " NOT VALID");
								offset = 0;
							}
							else
							{
								nextDirBlockList.Add(offset);
							}
						}
						entry_count = 0;
						//Debug.Log("offset=" + offset.ToString("X"));
					}
					if (offset == 0 || entry.filename[0] == 0xFE)
					{
						break;
					}
					if (entry.filename[0] == 0xFF)
					{
						// empty entry - try next file
						continue;
					}
					break;
				}

				if (entry.filename[0] != 0xFE && entry.filename[0] != 0xFF)
				{
					int fsize = ComputeHDOSFileSize(entry, disk_info.sectors_per_group);

					if (fsize == -1)
					{
						Debug.WriteLine("!! DIRECTORY IS CORRUPT !!");
						Debug.WriteLine("!!   FILESIZE FAILED    !!");
						diskContents.Clear();

						return diskContents;
					}

					ushort day = (ushort)(entry.creation_date & 0x001F);
					if (day == 0) day = 1;
					ushort mon = (ushort)((entry.creation_date & 0x01E0) >> 5);
					string month = "Jan";
					switch (mon)
					{
						case 1:
							month = "Jan";
							break;
						case 2:
							month = "Feb";
							break;
						case 3:
							month = "Mar";
							break;
						case 4:
							month = "Apr";
							break;
						case 5:
							month = "May";
							break;
						case 6:
							month = "Jun";
							break;
						case 7:
							month = "Jul";
							break;
						case 8:
							month = "Aug";
							break;
						case 9:
							month = "Sep";
							break;
						case 10:
							month = "Oct";
							break;
						case 11:
							month = "Nov";
							break;
						case 12:
							month = "Dec";
							break;
					}

					ushort year = (ushort)((entry.creation_date & 0x7E00) >> 9);
					if (year == 0)
					{
						year = 9;
					}
					else if (year + 70 > 99)
					{
						year = 99;
					}
					string cre_date = string.Format("{0:D2}-{1}-{2}", day, month, year + 70);
					string fname = Encoding.UTF8.GetString(entry.filename, 0, 8);
					string f = fname.Replace('\0', ' ');
					string fext = Encoding.UTF8.GetString(entry.fileext, 0, 3);
					string e = fext.Replace('\0', ' ');

					if (fname.Equals("RGT") && fext.Equals("SYS"))
					{
						// skip size
					}
					else if (fname.Equals("GRT") && fext.Equals("SYS"))
					{
						// skip size
					}
					else if (fname.Equals("DIRECT") && fext.Equals("SYS"))
					{
						// skip size
					}
					else
					{
						diskTotalSize += fsize;
					}

					/*
					if (string.IsNullOrEmpty(searchFileName))
					{
						DiskContentItem item = new DiskContentItem();
						item.fileName = f;
						item.fileExt = e;
						item.fileSize = fsize;
						item.fileCreateDate = cre_date;
						item.fileAlterationDate = string.Empty;
						diskFileContentList.Add(item);
					}
					*/
					// 01234567890123456789012345678901234567890
					// -rwxrwxrwx   13824 Dec 31 1969  as.com
					//           00000010 01-Apr-80    README  .DOC
					string item = string.Format("          {0:D8} {1}    {2}.{3}", fsize, cre_date, f, e);
					diskContents.Add(item);

					//Debug.WriteLine(item);
				}
			}
			/*
			if (string.IsNullOrEmpty(searchFileName))
			{
				diskFileContentList.Sort(new DiskFileContentSorter());

				diskFreeSize = ComputeHDOSFreeSize(disk_info.sectors_per_group);
			}
			*/

			return diskContents;
		}

		int ComputeHDOSFileSize(HDOSDirEntry entry, int sectorsPerGroup)
		{
			int grp_count = 1;
			byte grp = entry.first_group_num;
			if (grp < 4 || grp >= 200)
			{
				return 0;
			}
			while (HDOSGrtTable[grp] != 0 && grp_count < 256)
			{
				if (grp < 4 || grp >= 200)
				{
					return (-1);
				}
				grp = HDOSGrtTable[grp];
				grp_count++;
			}
			if (grp_count == 256)
			{
				return (-1);
			}

			int total_size = ((grp_count - 1) * sectorsPerGroup) + entry.last_sector_index;
			return total_size;
		}

		int ComputeHDOSFreeSize()
		{
			int grp_count = 0;
			int grp = 0;
			while (HDOSGrtTable[grp] != 0 && grp_count < 256)
			{
				grp = HDOSGrtTable[grp];
				grp_count++;
			}
			if (grp_count == 256)
			{
				return (0);
			}
			return grp_count * HDOSSectorsPerGroup;
		}

		private string[] GetHDOSFileList()
		{
			HDOSDiskInfo disk_info = GetHDOSDiskInfo();

			List<string> diskContents = ReadHDOSDiskContents(disk_info);

			return diskContents.ToArray();
		}

		private string ExtractHDOSFile(string imageFileName, string fileName)
		{
			// diskImageBytes[] must already be filled with the disk image file contents
			HDOSDiskInfo disk_info = GetHDOSDiskInfo();
			HDOSDirEntry entry = GetHDOSDirEntry(disk_info, fileName);

			byte[] fileBytes = ReadHDOSFileContents(disk_info, entry);

			/*
			int grp = entry.first_group_num;
			List<byte> fileBytes = new List<byte>();
			byte[] fileSectorBuffer = new byte[256 * disk_info.sectors_per_group];

			int bytes_to_read;
			int sector_addr;

			do
			{
				sector_addr = grp * disk_info.sectors_per_group * 256;
				int nextGrp = HDOSGrtTable[grp];
				if (nextGrp == 0)
				{
					// next group is last so we break out and copy only last_sector_index sectors
					break;
				}
				bytes_to_read = disk_info.sectors_per_group * 256;
				Buffer.BlockCopy(diskImageBytes, sector_addr, fileSectorBuffer, 0, bytes_to_read);
				fileBytes.AddRange(fileSectorBuffer.ToArray());
				grp = HDOSGrtTable[grp];
			} while (grp != 0);

			//Debug.WriteLine("grp=" + grp.ToString() + " lastSectorIndex=" + entry.last_sector_index.ToString());

			bytes_to_read = entry.last_sector_index * 256;
			if (bytes_to_read > 0)
			{
				fileSectorBuffer = new byte[bytes_to_read];
				Buffer.BlockCopy(diskImageBytes, sector_addr, fileSectorBuffer, 0, bytes_to_read);
				fileBytes.AddRange(fileSectorBuffer.ToArray());
			}

			string targetFile = GetExtractTargetDir(imageFileName, fileName);

			File.WriteAllBytes(targetFile, fileBytes.ToArray());
			*/

			string targetFile = GetExtractTargetDir(imageFileName, fileName);

			File.WriteAllBytes(targetFile, fileBytes);

			return targetFile;
		}

		byte[] ReadHDOSFileContents(HDOSDiskInfo disk_info, HDOSDirEntry entry)
		{
			int grp = entry.first_group_num;
			List<byte> fileBytes = new List<byte>();
			byte[] fileSectorBuffer = new byte[256 * disk_info.sectors_per_group];

			int bytes_to_read;
			int sector_addr;

			do
			{
				sector_addr = grp * disk_info.sectors_per_group * 256;
				int nextGrp = HDOSGrtTable[grp];
				if (nextGrp == 0)
				{
					// next group is last so we break out and copy only last_sector_index sectors
					break;
				}
				bytes_to_read = disk_info.sectors_per_group * 256;
				Buffer.BlockCopy(diskImageBytes, sector_addr, fileSectorBuffer, 0, bytes_to_read);
				fileBytes.AddRange(fileSectorBuffer.ToArray());
				grp = HDOSGrtTable[grp];
			} while (grp != 0);

			//Debug.WriteLine("grp=" + grp.ToString() + " lastSectorIndex=" + entry.last_sector_index.ToString());

			bytes_to_read = entry.last_sector_index * 256;
			if (bytes_to_read > 0)
			{
				fileSectorBuffer = new byte[bytes_to_read];
				Buffer.BlockCopy(diskImageBytes, sector_addr, fileSectorBuffer, 0, bytes_to_read);
				fileBytes.AddRange(fileSectorBuffer.ToArray());
			}

			return fileBytes.ToArray();
		}

		// DirEntry and GRT must already be filled in
		void WriteHDOSFileContents(HDOSDiskInfo disk_info, HDOSDirEntry entry, byte[] fileBytes)
		{
			int grp = entry.first_group_num;

			int bytes_to_write;
			int sector_addr;
			int file_idx = 0;

			byte[] fileSectorBuffer = new byte[disk_info.sectors_per_group * 256];

			do
			{
				sector_addr = grp * disk_info.sectors_per_group * 256;

				bytes_to_write = fileBytes.Length - file_idx;
				if (bytes_to_write <= 0)
				{
					break;
				}
				if (bytes_to_write > fileSectorBuffer.Length)
				{
					bytes_to_write = fileSectorBuffer.Length;
				}

				int nextGrp = HDOSGrtTable[grp];
				if (nextGrp == 0)
				{
					// next group is last so we break out and copy only last_sector_index sectors
					break;
				}

				for (int i = 0; i < fileSectorBuffer.Length; i++)
				{
					fileSectorBuffer[i] = 0;
				}
				// copy file contents into zero-filled file buffer
				Buffer.BlockCopy(fileBytes, file_idx, fileSectorBuffer, 0, bytes_to_write);
				// copy file buffer into disk image
				Buffer.BlockCopy(fileSectorBuffer, 0, diskImageBytes, sector_addr, fileSectorBuffer.Length);
				file_idx += bytes_to_write;
				grp = HDOSGrtTable[grp];
			} while (grp != 0);

			//Debug.WriteLine("grp=" + grp.ToString() + " lastSectorIndex=" + entry.last_sector_index.ToString());

			bytes_to_write = entry.last_sector_index * 256;
			if (bytes_to_write > 0)
			{
				fileSectorBuffer = new byte[bytes_to_write];
				for (int i = 0; i < fileSectorBuffer.Length; i++)
				{
					fileSectorBuffer[i] = 0;
				}
				// copy file contents to zero-filled file buffer
				int bytes_left = fileBytes.Length - file_idx;
				Buffer.BlockCopy(fileBytes, file_idx, fileSectorBuffer, 0, bytes_left);
				// copy file buffer to disk image
				Buffer.BlockCopy(fileSectorBuffer, 0, diskImageBytes, sector_addr, fileSectorBuffer.Length);
			}
		}

		// checks disk image to determine if it is an HDOS disk
		bool IsHDOSDisk(string fileNameAndPath)
		{
			diskImageBytes = File.ReadAllBytes(fileNameAndPath);

			return IsHDOSDiskCheck(diskImageBytes);
		}

		public static bool IsHDOSDiskCheck(byte[] data)
		{
			if ((data[0] == 0xAF && data[1] == 0xD3 && data[2] == 0x7D && data[3] == 0xCD) ||   //  V1.x
				(data[0] == 0xC3 && data[1] == 0xA0 && data[2] == 0x22 && data[3] == 0x20) ||   //  V2.x
				(data[0] == 0xC3 && data[1] == 0xA0 && data[2] == 0x22 && data[3] == 0x30) ||   //  V3.x
				(data[0] == 0xC3 && data[1] == 0x1D && data[2] == 0x24 && data[3] == 0x20) ||   //  V2.x Super-89
				(data[0] == 0x18 && data[1] == 0x1E && data[2] == 0x13 && data[3] == 0x20) ||   //  OMDOS
				(data[0] == 0xC3 && data[1] == 0xD1 && data[2] == 0x23 && data[3] == 0x20))     //  OMDOS
			{
				HDOSDiskVolume = GetHDOSVolume(data);
				HDOSDiskLabel = GetHDOSLabel(data);
				return (true);
			}

			HDOSDiskVolume = "000";
			HDOSDiskLabel = "CP/M DISK IMAGE";
			return false;
		}

		public static string GetHDOSVolume(byte[] track_buffer)
		{
			string v = track_buffer[0x900].ToString("D3");
			return v;
		}

		public static string GetHDOSLabel(byte[] track_buffer)
		{
			ASCIIEncoding encoding = new ASCIIEncoding();
			byte[] l = new byte[60];
			for (int i = 0; i < 60; i++)
			{
				l[i] = track_buffer[0x911 + i];
			}
			string disk_label = string.Format("{0}", encoding.GetString(l, 0, 60));
			disk_label = disk_label.Trim();

			return disk_label;
		}

		private string GetExtractTargetDir(string imageNameAndPath, string fileName)
		{
			// C:\H8D\SEBHCARCHIVE_VOL1_20090625\885-1019_HDOS-DEVICE-DRIVER-TYPE-README-DOC-HUG-P-N-885-1019_006F789B.H8D
			// -> DESKTOP\SEBHCARCHIVE_VOL1_20090625\885-1019_HDOS-DEVICE-DRIVER-TYPE-README-DOC-HUG-P-N-885-1019_006F789B.H8D
			string targetDir = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
			string dirName = Path.GetDirectoryName(imageNameAndPath);

			//Debug.WriteLine("imageNameAndPath=" + imageNameAndPath + " dirName=" + dirName);

			int lastPathIdx = dirName.LastIndexOf(Path.DirectorySeparatorChar);
			dirName = dirName.Substring(lastPathIdx);

			targetDir += dirName;

			string imageName = Path.GetFileNameWithoutExtension(imageNameAndPath);
			string newImageName = string.Empty;

			bool isSpace = false;

			for (int i = 0; i < imageName.Length; i++)
			{
				if (imageName[i] == ' ')
				{
					if (!isSpace)
					{
						newImageName += '_';
						isSpace = true;
					}
				}
				else
				{
					if (imageName[i] >= '0' && imageName[i] <= '9')
					{
						newImageName += imageName[i];
					}
					else if (imageName[i] >= 'A' && imageName[i] <= 'Z')
					{
						newImageName += imageName[i];
					}
					else if (imageName[i] >= 'a' && imageName[i] <= 'z')
					{
						newImageName += imageName[i];
					}
					else if (imageName[i] == '[' || imageName[i] == ']' || imageName[i] == '_' || imageName[i] == '-')
					{
						newImageName += imageName[i];
					}
					isSpace = false;
				}
			}

			targetDir = Path.Combine(targetDir, newImageName).ToUpper();

			//Debug.WriteLine("newDirName=" + targetDir);

			if (!Directory.Exists(targetDir))
			{
				Directory.CreateDirectory(targetDir);
			}

			string targetFile = Path.Combine(targetDir, fileName);

			Debug.WriteLine("targetFile=" + targetFile);

			extractDir = targetDir;

			return targetFile;
		}

		private int ViewInHex(byte[] data)
		{
			int width = 16;
			List<string> lines = new List<string>();
			for (int i = 0; i < data.Length; i += width)
			{
				string s = i.ToString("X08") + ":";
				for (int j = i; j < i + width; j++)
				{
					if (j < data.Length)
					{
						s += data[j].ToString("X2");
					}
					else
					{
						s += "  ";
					}
					if (j + 1 < i + width)
					{
						s += ".";
					}
					else
					{
						s += " ";
					}
				}
				for (int j = i; j < i + width; j++)
				{
					if (j < data.Length)
					{
						if (data[j] >= 0x20 && data[j] <= 0x7F)
						{
							s += (char)data[j];
						}
						else
						{
							s += '.';
						}
					}
					else
					{
						s += ' ';
					}
				}
				lines.Add(s);
			}
			Form2.thisForm.FillListBox(lines.ToArray());

			return lines.Count;
		}

		private void AddFilesToImage(string imageNameAndPath, string fileToAdd)
		{
			if (IsHDOSDisk(imageNameAndPath))
			{
				// add HDOS file (brute force)
				AddFileToHDOSImage(fileToAdd);
				File.WriteAllBytes(imageNameAndPath, diskImageBytes);
			}
			else
			{
				// add CP/M file using cpmcp.exe
				string format = GetCPMDiskFormat(diskImageBytes.Length);
				string targetFile = Path.GetFileName(fileToAdd);

				Process proc = new Process();

				proc.StartInfo.FileName = "cpmcp.exe";

				proc.StartInfo.Arguments = format + imageNameAndPath + " " + fileToAdd + " 0:" + targetFile;
				proc.StartInfo.CreateNoWindow = true;
				proc.StartInfo.UseShellExecute = false;
				proc.StartInfo.RedirectStandardOutput = true;

				proc.Start();

				proc.WaitForExit();
			}
		}

		private void AddFileToHDOSImage(string fileName)
		{
			HDOSDiskInfo disk_info = GetHDOSDiskInfo();
			HDOSDirEntry dir_entry = GetHDOSDirEntry(disk_info, string.Empty);
			if (dir_entry.filename[0] == 0xFE || dir_entry.filename[0] == 0xFF)
			{
				// empty directory found
				byte[] fileBytes = File.ReadAllBytes(fileName);

				int sectorsNeeded = fileBytes.Length / 256;
				int sectorGroupsNeeded = sectorsNeeded / disk_info.sectors_per_group;
				if (sectorGroupsNeeded == 0)
				{
					sectorGroupsNeeded = 1;
				}

				int grpCount = 0;
				int grpFreeChain = HDOSGrtTable[0];
				int startGrp = grpFreeChain;
				if (grpFreeChain >= 4 && grpFreeChain < 200)
				{
					int last_grp = startGrp;
					for (int n = 0; n < 256; n++)
					{
						grpCount++;
						last_grp = HDOSGrtTable[last_grp];
						if (last_grp < 4 || last_grp >= 200)
						{
							break;
						}
						if (grpCount >= sectorGroupsNeeded)
						{
							break;
						}
					}
					if (last_grp >= 4 && last_grp < 200 && grpCount <= sectorGroupsNeeded)
					{
						// enough empty space
						string HDOSFileName = Path.GetFileNameWithoutExtension(fileName);
						string HDOSFileExt = Path.GetExtension(fileName);
						if (HDOSFileName.Length > 8)
						{
							HDOSFileName = HDOSFileName.Substring(0, 8);
						}
						if (HDOSFileExt.Length > 0)
						{
							// start at 1 to skip the period of the extension
							HDOSFileExt = HDOSFileExt.Substring(1, 3);
						}
						HDOSFileName = HDOSFileName.PadRight(8).ToUpper();
						HDOSFileExt = HDOSFileExt.PadRight(3).ToUpper();

						Debug.WriteLine("HDOS filename=" + HDOSFileName + "." + HDOSFileExt);

						//public byte[] filename;
						//public byte[] fileext;
						//public byte project;
						//public byte version;
						//public byte cluster_factor;
						//public byte flags;
						//public byte flags2;
						//public byte first_group_num;
						//public byte last_group_num;
						//public byte last_sector_index;
						//public ushort creation_date;
						//public ushort alteration_date;

						int lastSectorIndex = (sectorsNeeded - (sectorGroupsNeeded * disk_info.sectors_per_group)) + 1;
						if (lastSectorIndex < 0)
						{
							lastSectorIndex = 0;
						}

						dir_entry.filename = ASCIIEncoding.ASCII.GetBytes(HDOSFileName.Replace(' ', '\0'));
						dir_entry.fileext = ASCIIEncoding.ASCII.GetBytes(HDOSFileExt.Replace(' ', '\0'));
						dir_entry.project = 0;
						dir_entry.version = 0;
						dir_entry.cluster_factor = 3;
						dir_entry.flags = 0;
						dir_entry.flags2 = 0;
						dir_entry.first_group_num = (byte)startGrp;
						dir_entry.last_group_num = (byte)last_grp;
						dir_entry.last_sector_index = (byte)lastSectorIndex;
						dir_entry.creation_date = 0x0E21;
						dir_entry.alteration_date = 0x0E21;

						AddHDOSDirEntry(disk_info, dir_entry, HDOSDirOffset);
						WriteHDOSFileContents(disk_info, dir_entry, fileBytes);
					}
					else
					{
						ShowResults("NOT ENOUGH FREE SPACE ON DISK");
					}
				}
			}
		}

		private void AddHDOSDirEntry(HDOSDiskInfo disk_info, HDOSDirEntry dir_entry, int offset, bool erase = false)
		{
			Buffer.BlockCopy(dir_entry.filename, 0, diskImageBytes, offset, 8);
			offset += 8;
			Buffer.BlockCopy(dir_entry.fileext, 0, diskImageBytes, offset, 3);
			offset += 3;
			diskImageBytes[offset++] = dir_entry.project;
			diskImageBytes[offset++] = dir_entry.version;
			diskImageBytes[offset++] = dir_entry.cluster_factor;
			diskImageBytes[offset++] = dir_entry.flags;
			diskImageBytes[offset++] = dir_entry.flags2;
			diskImageBytes[offset++] = dir_entry.first_group_num;
			diskImageBytes[offset++] = dir_entry.last_group_num;
			diskImageBytes[offset++] = dir_entry.last_sector_index;
			diskImageBytes[offset++] = (byte)(dir_entry.creation_date & 0x00FF);
			diskImageBytes[offset++] = (byte)((dir_entry.creation_date & 0xFF00) >> 8);
			diskImageBytes[offset++] = (byte)(dir_entry.alteration_date & 0x00FF);
			diskImageBytes[offset++] = (byte)((dir_entry.alteration_date & 0xFF00) >> 8);

			if (erase)
			{
				byte freeChainGrp = HDOSGrtTable[0];
				HDOSGrtTable[dir_entry.last_group_num] = freeChainGrp;
				HDOSGrtTable[0] = dir_entry.first_group_num;
			}
			else
			{
				HDOSGrtTable[0] = HDOSGrtTable[dir_entry.last_group_num];
				HDOSGrtTable[dir_entry.last_group_num] = 0;
			}

			Buffer.BlockCopy(HDOSGrtTable, 0, diskImageBytes, (int)disk_info.grt_sector, 256);
		}

		private void DeleteFileFromImage(string imageNameAndPath, string fileName)
		{
			if (IsHDOSDisk(imageNameAndPath))
			{
				// delete HDOS file (brute force)
				DeleteHDOSFileFromImage(imageNameAndPath, fileName);
			}
			else
			{
				// delete CPM file (cpmrm)
				// cpmrm -f h8d1s40t images\C80CPM1-DUP.h8d as.com

				string format = GetCPMDiskFormat(diskImageBytes.Length);
				string fileToDelete = fileName;

				Debug.WriteLine("DELETE FILE:" + imageNameAndPath + " " + fileToDelete);

				Process proc = new Process();

				proc.StartInfo.FileName = "cpmrm.exe";

				proc.StartInfo.Arguments = format + imageNameAndPath + " " + fileToDelete;
				proc.StartInfo.CreateNoWindow = true;
				proc.StartInfo.UseShellExecute = false;
				proc.StartInfo.RedirectStandardOutput = true;

				proc.Start();

				proc.WaitForExit();
			}
		}

		private void DeleteHDOSFileFromImage(string imageNameAndPath, string fileName)
		{
			HDOSDiskInfo disk_info = GetHDOSDiskInfo();
			HDOSDirEntry entry = GetHDOSDirEntry(disk_info, fileName);

			entry.filename[0] = 0xFF;
			AddHDOSDirEntry(disk_info, entry, HDOSDirOffset, true);
			File.WriteAllBytes(imageNameAndPath, diskImageBytes);
		}

		private void RenameDiskImage(int idx)
		{

			diskHash = 0;
			string fileExt = Path.GetExtension(imageFileList[idx]).ToUpper();

			string fileName = GetHDOSLabelOrFileName(imageFileList[idx]);
			if (string.IsNullOrEmpty(fileName) || GetCleanFileName(fileName).Length < 20)
			{
				fileName = Path.GetFileNameWithoutExtension(imageFileList[idx]);
			}

			string renameFile = GetRenameFileName(fileName);
			renameFile += fileExt;

			string filePath = Path.GetDirectoryName(imageFileList[idx]);
			string directoryName = filePath;
			filePath = Path.Combine(directoryName, renameFile);

			if (!File.Exists(filePath))
			{
				//Debug.WriteLine(imageFileList[idx] + "->" + filePath);
				File.Move(imageFileList[idx], filePath);
			}
		}

		// fileName = fileName without extension
		private string GetRenameFileName(string fileName)
		{
			string renameFile = GetCleanFileName(fileName);

			if (renameFile.Length >= 8)
			{
				string prefix = renameFile.Substring(0, 8);
				if (prefix.Contains("885-") && renameFile.Length >= 9)
				{
					// make sure 885-xxxx_
					if (renameFile[9] == '-')
					{
						string postfix = renameFile.Substring(10);
						renameFile = prefix + "_" + postfix;
					}
					else if (renameFile[10] == '-')
					{
						string postfix = renameFile.Substring(11);
						renameFile = prefix + "_" + postfix;
					}
					else
					{
						string postfix = renameFile.Substring(9);
						renameFile = prefix + "_" + postfix;
					}
				}
			}

			string hashStr = diskHash.ToString("X8");
			if (!renameFile.Contains(hashStr))
			{
				renameFile += "_" + hashStr;
			}

			renameFile = renameFile.ToUpper();

			return renameFile;
		}

		private string GetHDOSLabelOrFileName(string diskImageListStr)
		{
			string fileName = Path.GetFileNameWithoutExtension(diskImageListStr);

			string labelFileName = GetHDOSLabel(diskImageListStr);
			if (!string.IsNullOrEmpty(labelFileName))
			{
				fileName = labelFileName;
			}

			return fileName;
		}

		private string GetHDOSLabel(string diskImageListStr)
		{
			string labelName = string.Empty;
			if (IsHDOSDisk(diskImageListStr))
			{
				labelName = ASCIIEncoding.ASCII.GetString(diskImageBytes, 0x911, 68);
			}
			for (int i = 0; i < diskImageBytes.Length; i++)
			{
				diskHash += diskImageBytes[i];
			}
			return labelName;
		}


		// s = fileName with no extension
		public static string GetCleanFileName(string s)
		{
			string fileName = string.Empty;

			bool escapeMode = false;
			bool graphicsMode = false;
			int spaceCount = 0;
			for (int i = 0; i < s.Length; i++)
			{
				if (escapeMode)
				{
					if (s[i] == 'F')
					{
						graphicsMode = true;
					}
					if (s[i] == 'G')
					{
						graphicsMode = false;
					}
					escapeMode = false;
					continue;
				}
				if (s[i] == 0x1B)
				{
					escapeMode = true;
					continue;
				}
				if (graphicsMode)
				{
					continue;
				}
				if (s[i] >= '0' && s[i] <= '9')
				{
					fileName += s[i];
					spaceCount = 0;
				}
				else if (s[i] >= 'A' && s[i] <= 'Z')
				{
					fileName += s[i];
					spaceCount = 0;
				}
				else if (s[i] >= 'a' && s[i] <= 'z')
				{
					fileName += s[i];
					spaceCount = 0;
				}
				else
				{
					if (fileName.Length > 0)
					{
						if (spaceCount == 0)
						{
							if (fileName[fileName.Length - 1] != '-')
							{
								fileName += '-';
							}
						}
					}
					spaceCount = 1;
				}
			}

			if (s.Contains("885-"))
			{
				int startIndex = s.IndexOf("885-");
				if (startIndex >= 8)
				{
					// move P/N to front if not already there
					int n = s.Length - startIndex < 8 ? s.Length - startIndex : 8;
					string partNum = s.Substring(startIndex, n).Trim();
					fileName = partNum + "_" + fileName;
				}
			}

			char[] trimChars = { ' ', '-' };
			fileName = fileName.Trim(trimChars);

			return fileName;
		}

		private void LoadSettings()
		{
			if (File.Exists(settingsFileName))
			{
				string[] settings = File.ReadAllLines(settingsFileName);
				for (int i = 0; i < settings.Length; i++)
				{
					if (settings[i].Contains(settingsKey[i]))
					{
						workingFolder = settings[i].Substring(settingsKey[i].Length);
						GetWorkingFolderFileList();
					}
				}
			}
		}

		private void SaveSettings()
		{
			List<string> settings = new List<string>();

			string s = settingsKey[0] + workingFolder;
			settings.Add(s);

			File.WriteAllLines(settingsFileName, settings.ToArray());
		}

		private void ShowResults(string s)
		{
			textBox2.Text = s;
		}
	}
}