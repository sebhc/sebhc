﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO.Ports;
using System.Diagnostics;
using System.Timers;

namespace H8DUTILITY4x64
{
	public partial class Form3 : Form
	{
		private bool sending;
		private bool cancelFlag;
		private bool busy;

		private string imageFileNameAndPath;

		private bool timeOutFlag;
		System.Timers.Timer timer = new System.Timers.Timer();

		private byte[] readDiskImageBuffer = new byte[2560 * 160]; // maximum size 2S80T
		private int readDiskImageBufferIdx;

		private string hdosLabel;
		private string hdosVolume;

		private int lastComIdx = 0;
		private int lastBaudIdx = 2;

		public static Form3 thisForm = null;

		public Form3()
		{
			InitializeComponent();
			thisForm = this;

			timer.Elapsed += SetTimeOutCallback;

			comboBox2.SelectedIndex = 2;
			comboBox3.SelectedIndex = 0;
		}

		public void SendDiskImage(string s)
		{
			imageFileNameAndPath = s;
			string fileName = Path.GetFileName(s);
			ShowResult("READY TO SEND: " + fileName, true);
			sending = true;

			comboBox1.Items.Clear();

			string[] ports = SerialPort.GetPortNames();
			comboBox1.Items.AddRange(ports);
			comboBox1.SelectedIndex = lastComIdx;
			comboBox2.SelectedIndex = lastBaudIdx;
		}

		public void ReceiveDiskImage()
		{
			ShowResult("READY TO RECEIVE", true);
			sending = false;

			comboBox1.Items.Clear();

			string[] ports = SerialPort.GetPortNames();
			comboBox1.Items.AddRange(ports);
			comboBox1.SelectedIndex = lastComIdx;
			comboBox2.SelectedIndex = lastBaudIdx;
		}

		private void button1_Click(object sender, EventArgs e)
		{
			lastComIdx = comboBox1.SelectedIndex;
			lastBaudIdx = comboBox2.SelectedIndex;

			if (sending)
			{
				string fileName = Path.GetFileName(imageFileNameAndPath);
				ShowResult("SENDING: " + fileName, true);

				// open port, set baud rate, send file
				SendDiskImageBegin();
			}
			else
			{
				ShowResult("RECEIVING A DISK IMAGE", true);

				if (RecvDiskImageBegin())
				{
					int diskHash = 0;
					for (int i = 0; i < readDiskImageBufferIdx; i++)
					{
						diskHash += readDiskImageBuffer[i];
					}

					saveFileDialog1.Filter = "H8D Files | *.H8D";
					saveFileDialog1.DefaultExt = "H8D";
					saveFileDialog1.FileName = Form1.GetCleanFileName(hdosLabel).ToUpper() + "_" + diskHash.ToString("X8");

					DialogResult res = saveFileDialog1.ShowDialog();
					if (res == DialogResult.OK)
					{
						Debug.WriteLine(saveFileDialog1.FileName);

						ShowResult(saveFileDialog1.FileName);

						byte[] writeBuffer = new byte[readDiskImageBufferIdx];
						Buffer.BlockCopy(readDiskImageBuffer, 0, writeBuffer, 0, readDiskImageBufferIdx);
						File.WriteAllBytes(saveFileDialog1.FileName, writeBuffer);
					}
				}
			}

			button1.Enabled = true;
		}

		private void button2_Click(object sender, EventArgs e)
		{
			cancelFlag = true;

			if (!busy)
			{
				Form1.thisForm.Enabled = true;
				thisForm.Visible = false;
			}
		}

		private void SendDiskImageBegin()
		{
			// send '0' or '1' for SY0 (1S40T) or SY1 (2S80T)
			// if '?' response and SY1 abort transfer (old version on client)
			// send '4','5','6','7' for 1S40T,2S40T,1S80T,2S80T
			// response = '4','5','6','7'
			// send 'V',volume override value
			// response 'V' if success
			// send 'W' to switch client to write mode
			// loop
			// send 'W'
			// send track data (2560 bytes)
			// response 'W' if success
			// go to loop until all tracks sent
			// tracks=40,80,80,160

			button1.Enabled = false;

			string portName = comboBox1.SelectedItem.ToString().Trim();
			string baudStr = comboBox2.SelectedItem.ToString();
			int baudRate = int.Parse(baudStr);

			Debug.WriteLine(portName + " at " + baudRate.ToString());

			SerialPort port = new SerialPort(portName, baudRate);

			port.DataBits = 8;
			port.StopBits = StopBits.One;
			port.Parity = Parity.None;

			try
			{
				port.Open();
			}
			catch
			{
				ShowResult("SELECTED PORT " + portName + " IS ALREADY IN USE");
				return;
			}

			byte[] data = File.ReadAllBytes(imageFileNameAndPath);
			if (data.Length > 0)
			{
				int trackSize = 2560;
				int numTracks = data.Length / 2560;

				ShowResult("NUM TRACKS: " + numTracks.ToString());

				if (numTracks == 40 || numTracks == 80 || numTracks == 160)
				{
					progressBar1.Minimum = 0;
					progressBar1.Maximum = numTracks;
					progressBar1.Step = 1;
					progressBar1.Value = 0;

					int track = 0;
					int driveType = 0;

					int volumeId = 0;
					char diskType = '4'; // 1S40T
					if (Form1.IsHDOSDiskCheck(data))
					{
						volumeId = data[0x900];
						int diskTypeNum = data[0x910];
						if (diskTypeNum == 1)
						{
							diskType = '5'; // 2S40T
						}
						else if (diskTypeNum == 2)
						{
							diskType = '6'; // 1S80T
							driveType = 1;
						}
						else if (diskTypeNum == 3)
						{
							diskType = '7'; // 2S80T
							driveType = 1;
						}
					}
					else
					{
						if (numTracks == 80)
						{
							diskType = '5';
						}
						else if (numTracks == 160)
						{
							diskType = '7';
							driveType = 1;
						}
					}

					if (CheckClientReady(port))
					{
						if (SendDriveType(port, driveType))
						{
							if (SendDiskType(port, diskType))
							{
								if (SendVolumeId(port, volumeId))
								{
									if (SendWriteCmd(port))
									{
										busy = true;

										int offset = 0;
										while (track < numTracks && !cancelFlag)
										{
											// send chunk
											if (SendTrack(port, data, offset, trackSize))
											{
												offset += trackSize;
												track++;

												string s = "TRACK " + track.ToString() + "/" + numTracks.ToString() + " SENT";
												listBox1.Items.Add(s);

												progressBar1.PerformStep();
												progressBar1.Refresh();
											}
											else
											{
												// abort
												string s = "TRACK " + track.ToString() + " FAILED";
												listBox1.Items.Add(s);
												break;
											}
											listBox1.SelectedIndex = listBox1.Items.Count - 1;
											listBox1.Refresh();
										}
										string msg = imageFileNameAndPath + " COMPLETE";
										listBox1.Items.Add(msg);
										listBox1.SelectedIndex = listBox1.Items.Count - 1;
										listBox1.Refresh();

										busy = false;
									}
								}
							}
						}
					}
				}
			}

			cancelFlag = false;

			port.Close();

			Debug.WriteLine(portName + " CLOSED");

			button1.Enabled = true;
		}

		private bool RecvDiskImageBegin()
		{
			bool result = false;

			string portName = comboBox1.SelectedItem.ToString().Trim();
			string baudStr = comboBox2.SelectedItem.ToString();

			int baudRate = int.Parse(baudStr);
			int driveType = comboBox3.SelectedIndex;

			Debug.WriteLine(portName + " at " + baudRate.ToString());

			SerialPort port = new SerialPort(portName, baudRate);
			port.DataBits = 8;
			port.StopBits = StopBits.One;
			port.Parity = Parity.None;

			try
			{
				port.Open();
			}
			catch
			{
				ShowResult("SELECTED PORT " + portName + " IS ALREADY IN USE");
				return false;
			}

			progressBar1.Minimum = 0;
			progressBar1.Step = 1;
			progressBar1.Value = 0;

			if (CheckClientReady(port))
			{
				if (SendDriveType(port, driveType))
				{
					int diskType = SendQueryDisk(port);
					if (diskType >= 0 && diskType <= 3)
					{
						// switch client to receive mode
						byte[] cmdBuf = { (byte)'R' };
						port.Write(cmdBuf, 0, 1);

						int track = 0;
						int expectedTracks = (diskType == 0) ? 40 : (diskType == 1) ? 80 : (diskType == 2) ? 80 : 160;

						string s = "EXPECTED TRACKS: " + expectedTracks.ToString();
						listBox1.Items.Add(s);
						listBox1.SelectedIndex = listBox1.Items.Count - 1;
						listBox1.Refresh();

						progressBar1.Maximum = expectedTracks;

						Application.DoEvents();

						SetTimeOut(500);

						while (!timeOutFlag)
						{
						}

						readDiskImageBufferIdx = 0;

						hdosVolume = "000";
						hdosLabel = "UNLABELED";

						busy = true;

						while (track < expectedTracks && !cancelFlag)
						{
							if (ReadTrack(port))
							{
								if (track == 0)
								{
									hdosLabel = "CP/M DISK IMAGE";
									if (Form1.IsHDOSDiskCheck(readDiskImageBuffer))
									{
										hdosVolume = Form1.GetHDOSVolume(readDiskImageBuffer);
										hdosLabel = Form1.GetHDOSLabel(readDiskImageBuffer);
									}
									s = "VOLUME: " + hdosVolume;
									listBox1.Items.Add(s);
									s = "LABEL: " + hdosLabel;
									listBox1.Items.Add(s);
								}

								progressBar1.PerformStep();
								progressBar1.Refresh();

								track++;

								s = "TRACK " + track.ToString() + "/" + expectedTracks.ToString() + " RECEIVED";
								listBox1.Items.Add(s);
								listBox1.SelectedIndex = listBox1.Items.Count - 1;
								listBox1.Refresh();

								Application.DoEvents();
							}
							else
							{
								s = "READ DISK FAILED ON TRACK " + track.ToString();
								listBox1.Items.Add(s);
								listBox1.SelectedIndex = listBox1.Items.Count - 1;
								listBox1.Refresh();
								break;
							}
						}

						if (track == expectedTracks)
						{
							result = true;
						}

						busy = false;
					}
				}
			}

			cancelFlag = false;

			port.Close();

			return result;
		}

		private bool CheckClientReady(SerialPort port)
		{
			bool isReady = false;

			port.DiscardInBuffer();

			byte[] cmdBuf = { (byte)'?' };
			port.Write(cmdBuf, 0, 1);

			SetTimeOut(2000);

			while (true)
			{
				if (port.BytesToRead > 0 || timeOutFlag)
				{
					if (timeOutFlag)
					{
						ShowResult("CHECK CLIENT READY: TIME OUT");
						break;
					}
					int c = port.ReadByte();
					if (c == '?')
					{
						ShowResult("CHECK CLIENT READY: CLIENT IS READY");
						isReady = true;
					}
					else
					{
						ShowResult("CHECK CLIENT READY: CLIENT IS NOT READY - INVALID RESPONSE");
						isReady = false;
					}
					break;
				}
			}

			return isReady;
		}

		private bool SendDriveType(SerialPort port, int driveType)
		{
			byte[] cmdBuf = new byte[2];
			cmdBuf[0] = (driveType == 0) ? (byte)'0' : (byte)'1';

			port.Write(cmdBuf, 0, 1);

			SetTimeOut(2000);

			while (port.BytesToRead <= 0 && !timeOutFlag)
			{
			}

			if (timeOutFlag)
			{
				ShowResult("SEND DRIVE TYPE: CLIENT TIMED OUT");
			}
			else
			{
				int c = port.ReadByte();
				if (c == cmdBuf[0])
				{
					ShowResult("DRIVE TYPE SET TO: " + c.ToString());
					return true;
				}
				else
				{
					ShowResult("SEND DRIVE TYPE: INVALID RESPONSE '" + (char)c + "' INSTEAD OF '" + driveType + "'");
				}
			}
			return false;
		}

		private bool SendDiskType(SerialPort port, char diskType)
		{
			byte[] cmdBuf = new byte[2];
			cmdBuf[0] = (byte)diskType;
			port.Write(cmdBuf, 0, 1);

			SetTimeOut(2000);

			while (port.BytesToRead <= 0 && !timeOutFlag)
			{
			}

			if (timeOutFlag)
			{
				ShowResult("SEND DISK TYPE: CLIENT TIMED OUT");
			}
			else
			{
				int c = port.ReadByte();
				if (c == diskType)
				{
					ShowResult("DISK TYPE SET TO: " + c.ToString());
					return true;
				}
				else
				{
					ShowResult("SEND DISK TYPE: INVALID RESPONSE '" + (char)c + "' INSTEAD OF '" + diskType + "'");
				}
			}
			return false;
		}

		private bool SendVolumeId(SerialPort port, int vol)
		{
			byte[] cmdBuf = new byte[2];
			cmdBuf[0] = (byte)'V';
			cmdBuf[1] = (byte)vol;
			port.Write(cmdBuf, 0, 2);

			SetTimeOut(2000);

			while (port.BytesToRead <= 0 && !timeOutFlag)
			{
			}

			if (timeOutFlag)
			{
				ShowResult("SEND VOLUME: CLIENT TIMED OUT");
			}
			else
			{
				int c = port.ReadByte();
				if (c == 'V')
				{
					ShowResult("VOLUME ID SET TO: " + vol.ToString());
					return true;
				}
				else
				{
					ShowResult("SEND VOLUME: INVALID RESPONSE '" + (char)c + "' INSTEAD OF 'V'");
				}
			}
			return false;
		}

		private int SendQueryDisk(SerialPort port)
		{
			byte[] cmdBuf = { (byte)'Q' };
			port.Write(cmdBuf, 0, 1);

			SetTimeOut(4000);

			while (port.BytesToRead <= 0 && !timeOutFlag)
			{
			}

			if (timeOutFlag)
			{
			}
			else
			{
				string s = "QUERY RETURNED: 1S40T";

				int cmd = port.ReadByte();
				if (cmd == 'Q')
				{
					int diskType = port.ReadByte();
					if (diskType == 1)
					{
						// 2S40T
						s = "QUERY RETURNED: 2S40T";
					}
					else if (diskType == 2)
					{
						// 1S80T
						s = "QUERY RETURNED: 1S80T";
					}
					else if (diskType == 3)
					{
						// 2S80T
						s = "QUERY RETURNED: 2S80T";
					}
					listBox1.Items.Add(s);
					listBox1.SelectedIndex = listBox1.Items.Count - 1;
					listBox1.Refresh();

					Application.DoEvents();

					return diskType;
				}
				else
				{
					s = "QUERY DISK RETURNED INVALID RESPONSE: '" + cmd.ToString() + "' INSTEAD OF 'Q'";
					listBox1.Items.Add(s);
					listBox1.SelectedIndex = listBox1.Items.Count - 1;
					listBox1.Refresh();

					Application.DoEvents();
				}
			}

			return -1;
		}

		private bool SendWriteCmd(SerialPort port)
		{
			byte[] cmdBuf = { (byte)'W' };
			port.Write(cmdBuf, 0, 1);

			SetTimeOut(500);

			while (port.BytesToRead <= 0 && !timeOutFlag)
			{
			}

			ShowResult("CLIENT SET TO WRITE MODE");

			return true;
		}

		private bool SendTrack(SerialPort port, byte[] data, int offset, int count)
		{
			byte[] cmdBuf = { (byte)'W' };
			port.Write(cmdBuf, 0, 1);

			SetTimeOut(100); // 100ms

			while (!timeOutFlag)
			{
			}

			port.Write(data, offset, count);

			SetTimeOut(4000);

			// wait for ack
			while (port.BytesToRead <= 0 && !timeOutFlag)
			{
				Application.DoEvents();
			}

			if (timeOutFlag)
			{
				ShowResult("SEND TRACK: CLIENT TIMED OUT");
			}
			else
			{
				int c = port.ReadByte();
				if (c == 'W')
				{
					return true;
				}
				else
				{
					ShowResult("SEND TRACK: INVALID RESPONSE '" + c.ToString() + "' INSTEAD OF 'W'");
				}
			}
			return false;
		}

		private bool SendReadCmd(SerialPort port)
		{
			byte[] cmdBuf = { (byte)'R' };
			port.Write(cmdBuf, 0, 1);

			SetTimeOut(2000);

			while (port.BytesToRead <= 0 && !timeOutFlag)
			{
			}

			if (timeOutFlag)
			{
				ShowResult("SEND READ COMMAND: CLIENT TIMED OUT");
			}
			else
			{
				int c = port.ReadByte();
				if (c == 'R')
				{
					return true;
				}
				else
				{
					ShowResult("READ CMD: INVALID RESPONSE '" + c.ToString() + "' INSTEAD OF 'R'");
				}
			}
			return false;
		}

		private bool ReadTrack(SerialPort port)
		{
			byte[] cmdBuf = { (byte)'R' };
			port.Write(cmdBuf, 0, 1);

			int readBytes = 0;
			int trackSize = 2560;
			int expectedBytes = trackSize + 1; // track plus 'R' response
			byte[] inBuf = new byte[expectedBytes];

			SetTimeOut(500);

			while (!timeOutFlag)
			{
			}

			while (readBytes < expectedBytes)
			{
				int bytesToRead = port.BytesToRead;
				if (bytesToRead > 0)
				{
					port.Read(inBuf, readBytes, bytesToRead);
					readBytes += bytesToRead;
				}

				int bytesIn = Math.Max(readBytes - 1, 0);
				textBox1.Text = bytesIn.ToString("D4") + "/" + "2560" + " [" + hdosVolume + "] " + hdosLabel;

				Application.DoEvents();
			}

			byte response = inBuf[expectedBytes - 1];
			if (response == 'R' || response == 'r')
			{
				Buffer.BlockCopy(inBuf, 0, readDiskImageBuffer, readDiskImageBufferIdx, trackSize);
				readDiskImageBufferIdx += trackSize;

				return true;
			}

			textBox1.Text += " FAILED: RESPONSE WAS '" + response.ToString() + "' INSTEAD OF 'R'";

			return false;
		}

		private void ShowResult(string s, bool textBoxOnly = false)
		{
			textBox1.Text = s;
			textBox1.Refresh();

			if (!textBoxOnly)
			{
				listBox1.Items.Add(s);
				listBox1.Refresh();
			}
		}

		private void SetTimeOut(double milliseconds)
		{
			timeOutFlag = false;
			timer.Interval = milliseconds;
			timer.Start();
		}

		private void SetTimeOutCallback(object? sender, ElapsedEventArgs e)
		{
			timeOutFlag = true;
			timer.Stop();
		}

		private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
		{

		}
	}
}
