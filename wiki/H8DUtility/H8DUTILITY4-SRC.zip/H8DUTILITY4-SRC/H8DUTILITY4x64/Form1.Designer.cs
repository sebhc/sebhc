﻿namespace H8DUTILITY4x64
{
	partial class Form1
	{
		/// <summary>
		///  Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		///  Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		///  Required method for Designer support - do not modify
		///  the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			folderBrowserDialog1 = new FolderBrowserDialog();
			listBox2 = new ListBox();
			listBox1 = new ListBox();
			panel6 = new Panel();
			button7 = new Button();
			button6 = new Button();
			button8 = new Button();
			panel1 = new Panel();
			button19 = new Button();
			button18 = new Button();
			button17 = new Button();
			button11 = new Button();
			button14 = new Button();
			button13 = new Button();
			button12 = new Button();
			button9 = new Button();
			button16 = new Button();
			button15 = new Button();
			panel3 = new Panel();
			button1 = new Button();
			button2 = new Button();
			button5 = new Button();
			panel2 = new Panel();
			button3 = new Button();
			textBox1 = new TextBox();
			tableLayoutPanel1 = new TableLayoutPanel();
			panel5 = new Panel();
			textBox4 = new TextBox();
			panel4 = new Panel();
			button4 = new Button();
			button10 = new Button();
			textBox3 = new TextBox();
			panel7 = new Panel();
			progressBar1 = new ProgressBar();
			textBox2 = new TextBox();
			openFileDialog1 = new OpenFileDialog();
			saveFileDialog1 = new SaveFileDialog();
			panel6.SuspendLayout();
			panel1.SuspendLayout();
			panel3.SuspendLayout();
			panel2.SuspendLayout();
			tableLayoutPanel1.SuspendLayout();
			panel5.SuspendLayout();
			panel4.SuspendLayout();
			panel7.SuspendLayout();
			SuspendLayout();
			// 
			// listBox2
			// 
			listBox2.Dock = DockStyle.Fill;
			listBox2.Font = new Font("Consolas", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
			listBox2.FormattingEnabled = true;
			listBox2.ItemHeight = 15;
			listBox2.Location = new Point(688, 36);
			listBox2.Name = "listBox2";
			listBox2.SelectionMode = SelectionMode.MultiSimple;
			listBox2.Size = new Size(332, 407);
			listBox2.TabIndex = 1;
			listBox2.SelectedIndexChanged += listBox2_SelectedIndexChanged;
			// 
			// listBox1
			// 
			listBox1.Dock = DockStyle.Fill;
			listBox1.Font = new Font("Consolas", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
			listBox1.FormattingEnabled = true;
			listBox1.HorizontalScrollbar = true;
			listBox1.ItemHeight = 15;
			listBox1.Location = new Point(3, 36);
			listBox1.Name = "listBox1";
			listBox1.SelectionMode = SelectionMode.MultiSimple;
			listBox1.Size = new Size(679, 407);
			listBox1.TabIndex = 0;
			listBox1.SelectedIndexChanged += listBox1_SelectedIndexChanged;
			// 
			// panel6
			// 
			panel6.Controls.Add(button7);
			panel6.Controls.Add(button6);
			panel6.Dock = DockStyle.Fill;
			panel6.Location = new Point(688, 482);
			panel6.Name = "panel6";
			panel6.Size = new Size(332, 28);
			panel6.TabIndex = 10;
			// 
			// button7
			// 
			button7.Enabled = false;
			button7.Location = new Point(93, 0);
			button7.Name = "button7";
			button7.Size = new Size(75, 23);
			button7.TabIndex = 1;
			button7.Text = "SAVE HTM";
			button7.UseVisualStyleBackColor = true;
			button7.Click += button7_Click;
			// 
			// button6
			// 
			button6.Enabled = false;
			button6.Location = new Point(12, 0);
			button6.Name = "button6";
			button6.Size = new Size(75, 23);
			button6.TabIndex = 0;
			button6.Text = "SAVE TXT";
			button6.UseVisualStyleBackColor = true;
			button6.Click += button6_Click;
			// 
			// button8
			// 
			button8.Enabled = false;
			button8.Location = new Point(254, 0);
			button8.Name = "button8";
			button8.Size = new Size(75, 23);
			button8.TabIndex = 2;
			button8.Text = "DEL FILE";
			button8.UseVisualStyleBackColor = true;
			button8.Click += button8_Click;
			// 
			// panel1
			// 
			panel1.Controls.Add(button19);
			panel1.Controls.Add(button18);
			panel1.Controls.Add(button17);
			panel1.Controls.Add(button11);
			panel1.Controls.Add(button14);
			panel1.Controls.Add(button13);
			panel1.Controls.Add(button12);
			panel1.Controls.Add(button9);
			panel1.Dock = DockStyle.Fill;
			panel1.Location = new Point(3, 449);
			panel1.Name = "panel1";
			panel1.Size = new Size(679, 27);
			panel1.TabIndex = 5;
			// 
			// button19
			// 
			button19.Enabled = false;
			button19.Location = new Point(405, 0);
			button19.Name = "button19";
			button19.Size = new Size(75, 23);
			button19.TabIndex = 13;
			button19.Text = "RELABEL";
			button19.UseVisualStyleBackColor = true;
			button19.Click += button19_Click;
			// 
			// button18
			// 
			button18.Enabled = false;
			button18.Location = new Point(324, 0);
			button18.Name = "button18";
			button18.Size = new Size(75, 23);
			button18.TabIndex = 12;
			button18.Text = "SAVE AS";
			button18.UseVisualStyleBackColor = true;
			button18.Click += button18_Click;
			// 
			// button17
			// 
			button17.Location = new Point(81, 0);
			button17.Name = "button17";
			button17.Size = new Size(75, 23);
			button17.TabIndex = 11;
			button17.Text = "SEL ALL";
			button17.UseVisualStyleBackColor = true;
			button17.Click += button17_Click;
			// 
			// button11
			// 
			button11.Enabled = false;
			button11.Location = new Point(162, 0);
			button11.Name = "button11";
			button11.Size = new Size(75, 23);
			button11.TabIndex = 1;
			button11.Text = "VIEW HEX";
			button11.UseVisualStyleBackColor = true;
			button11.Click += button11_Click;
			// 
			// button14
			// 
			button14.Enabled = false;
			button14.Location = new Point(576, 0);
			button14.Name = "button14";
			button14.Size = new Size(100, 23);
			button14.TabIndex = 5;
			button14.Text = "RENAME ALL";
			button14.UseVisualStyleBackColor = true;
			button14.Click += button14_Click;
			// 
			// button13
			// 
			button13.Enabled = false;
			button13.Location = new Point(495, 0);
			button13.Name = "button13";
			button13.Size = new Size(75, 23);
			button13.TabIndex = 2;
			button13.Text = "DELETE";
			button13.UseVisualStyleBackColor = true;
			button13.Click += button13_Click;
			// 
			// button12
			// 
			button12.Enabled = false;
			button12.Location = new Point(243, 0);
			button12.Name = "button12";
			button12.Size = new Size(75, 23);
			button12.TabIndex = 1;
			button12.Text = "DUPLICATE";
			button12.UseVisualStyleBackColor = true;
			button12.Click += button12_Click;
			// 
			// button9
			// 
			button9.Location = new Point(0, 0);
			button9.Name = "button9";
			button9.Size = new Size(75, 23);
			button9.TabIndex = 0;
			button9.Text = "CLEAR SEL";
			button9.UseVisualStyleBackColor = true;
			button9.Click += button9_Click;
			// 
			// button16
			// 
			button16.Location = new Point(81, 0);
			button16.Name = "button16";
			button16.Size = new Size(75, 23);
			button16.TabIndex = 7;
			button16.Text = "RECV IMG";
			button16.UseVisualStyleBackColor = true;
			button16.Click += button16_Click;
			// 
			// button15
			// 
			button15.Enabled = false;
			button15.Location = new Point(0, 0);
			button15.Name = "button15";
			button15.Size = new Size(75, 23);
			button15.TabIndex = 6;
			button15.Text = "SEND IMG";
			button15.UseVisualStyleBackColor = true;
			button15.Click += button15_Click;
			// 
			// panel3
			// 
			panel3.Controls.Add(button8);
			panel3.Controls.Add(button1);
			panel3.Controls.Add(button2);
			panel3.Controls.Add(button5);
			panel3.Dock = DockStyle.Fill;
			panel3.Location = new Point(688, 449);
			panel3.Name = "panel3";
			panel3.Size = new Size(332, 27);
			panel3.TabIndex = 7;
			// 
			// button1
			// 
			button1.Enabled = false;
			button1.Location = new Point(174, 0);
			button1.Name = "button1";
			button1.Size = new Size(75, 23);
			button1.TabIndex = 3;
			button1.Text = "ADD FILE";
			button1.UseVisualStyleBackColor = true;
			button1.Click += button1_Click;
			// 
			// button2
			// 
			button2.Enabled = false;
			button2.Location = new Point(93, 0);
			button2.Name = "button2";
			button2.Size = new Size(75, 23);
			button2.TabIndex = 4;
			button2.Text = "VIEW";
			button2.UseVisualStyleBackColor = true;
			button2.Click += button2_Click;
			// 
			// button5
			// 
			button5.Enabled = false;
			button5.Location = new Point(12, 0);
			button5.Name = "button5";
			button5.Size = new Size(75, 23);
			button5.TabIndex = 0;
			button5.Text = "EXTRACT";
			button5.UseVisualStyleBackColor = true;
			button5.Click += button5_Click;
			// 
			// panel2
			// 
			panel2.Controls.Add(button3);
			panel2.Controls.Add(textBox1);
			panel2.Dock = DockStyle.Bottom;
			panel2.Location = new Point(3, 8);
			panel2.Name = "panel2";
			panel2.Size = new Size(679, 22);
			panel2.TabIndex = 6;
			// 
			// button3
			// 
			button3.Dock = DockStyle.Right;
			button3.Location = new Point(604, 0);
			button3.Name = "button3";
			button3.Size = new Size(75, 22);
			button3.TabIndex = 1;
			button3.Text = "FOLDER";
			button3.UseVisualStyleBackColor = true;
			button3.Click += button3_Click;
			// 
			// textBox1
			// 
			textBox1.Dock = DockStyle.Fill;
			textBox1.Location = new Point(0, 0);
			textBox1.Name = "textBox1";
			textBox1.Size = new Size(679, 23);
			textBox1.TabIndex = 0;
			textBox1.Text = "Folder Name";
			// 
			// tableLayoutPanel1
			// 
			tableLayoutPanel1.ColumnCount = 2;
			tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 66.95992F));
			tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 33.0400772F));
			tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 20F));
			tableLayoutPanel1.Controls.Add(listBox1, 0, 1);
			tableLayoutPanel1.Controls.Add(listBox2, 1, 1);
			tableLayoutPanel1.Controls.Add(panel2, 0, 0);
			tableLayoutPanel1.Controls.Add(panel3, 1, 2);
			tableLayoutPanel1.Controls.Add(panel1, 0, 2);
			tableLayoutPanel1.Controls.Add(panel5, 0, 3);
			tableLayoutPanel1.Controls.Add(panel6, 1, 3);
			tableLayoutPanel1.Controls.Add(panel4, 1, 0);
			tableLayoutPanel1.Controls.Add(textBox3, 1, 4);
			tableLayoutPanel1.Controls.Add(panel7, 0, 4);
			tableLayoutPanel1.Dock = DockStyle.Fill;
			tableLayoutPanel1.Location = new Point(0, 0);
			tableLayoutPanel1.Name = "tableLayoutPanel1";
			tableLayoutPanel1.RowCount = 5;
			tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 7.522124F));
			tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 92.4778748F));
			tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Absolute, 33F));
			tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Absolute, 34F));
			tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Absolute, 28F));
			tableLayoutPanel1.Size = new Size(1023, 542);
			tableLayoutPanel1.TabIndex = 0;
			// 
			// panel5
			// 
			panel5.Controls.Add(textBox4);
			panel5.Controls.Add(button16);
			panel5.Controls.Add(button15);
			panel5.Dock = DockStyle.Fill;
			panel5.Location = new Point(3, 482);
			panel5.Name = "panel5";
			panel5.Size = new Size(679, 28);
			panel5.TabIndex = 9;
			// 
			// textBox4
			// 
			textBox4.Location = new Point(162, 1);
			textBox4.Name = "textBox4";
			textBox4.PlaceholderText = "HDOS DISK LABEL";
			textBox4.ReadOnly = true;
			textBox4.Size = new Size(514, 23);
			textBox4.TabIndex = 8;
			textBox4.TabStop = false;
			textBox4.KeyDown += textBox4_KeyDown;
			// 
			// panel4
			// 
			panel4.Controls.Add(button4);
			panel4.Controls.Add(button10);
			panel4.Dock = DockStyle.Bottom;
			panel4.Location = new Point(688, 3);
			panel4.Name = "panel4";
			panel4.Size = new Size(332, 27);
			panel4.TabIndex = 11;
			// 
			// button4
			// 
			button4.Enabled = false;
			button4.Location = new Point(3, 4);
			button4.Name = "button4";
			button4.Size = new Size(120, 23);
			button4.TabIndex = 0;
			button4.Text = "SHOW FILES";
			button4.UseVisualStyleBackColor = true;
			button4.Click += button4_Click;
			// 
			// button10
			// 
			button10.Location = new Point(129, 4);
			button10.Name = "button10";
			button10.Size = new Size(120, 23);
			button10.TabIndex = 1;
			button10.Text = "CLEAR SELECTIONS";
			button10.UseVisualStyleBackColor = true;
			button10.Click += button10_Click;
			// 
			// textBox3
			// 
			textBox3.Dock = DockStyle.Fill;
			textBox3.Location = new Point(688, 516);
			textBox3.Name = "textBox3";
			textBox3.ReadOnly = true;
			textBox3.Size = new Size(332, 23);
			textBox3.TabIndex = 13;
			// 
			// panel7
			// 
			panel7.Controls.Add(progressBar1);
			panel7.Controls.Add(textBox2);
			panel7.Dock = DockStyle.Fill;
			panel7.Location = new Point(3, 516);
			panel7.Name = "panel7";
			panel7.Size = new Size(679, 23);
			panel7.TabIndex = 14;
			// 
			// progressBar1
			// 
			progressBar1.Dock = DockStyle.Fill;
			progressBar1.Location = new Point(0, 0);
			progressBar1.Name = "progressBar1";
			progressBar1.Size = new Size(679, 23);
			progressBar1.TabIndex = 1;
			progressBar1.Visible = false;
			// 
			// textBox2
			// 
			textBox2.Dock = DockStyle.Fill;
			textBox2.Font = new Font("Arial", 8.25F, FontStyle.Regular, GraphicsUnit.Point);
			textBox2.Location = new Point(0, 0);
			textBox2.Name = "textBox2";
			textBox2.ReadOnly = true;
			textBox2.Size = new Size(679, 20);
			textBox2.TabIndex = 0;
			textBox2.Text = "H8DUTILITY 4";
			// 
			// openFileDialog1
			// 
			openFileDialog1.FileName = "openFileDialog1";
			openFileDialog1.Multiselect = true;
			// 
			// Form1
			// 
			AutoScaleDimensions = new SizeF(7F, 15F);
			AutoScaleMode = AutoScaleMode.Font;
			AutoSize = true;
			ClientSize = new Size(1023, 542);
			Controls.Add(tableLayoutPanel1);
			Name = "Form1";
			Text = "H8DUTILITY V4.0 (2023 Les Bird)";
			Load += Form1_Load;
			panel6.ResumeLayout(false);
			panel1.ResumeLayout(false);
			panel3.ResumeLayout(false);
			panel2.ResumeLayout(false);
			panel2.PerformLayout();
			tableLayoutPanel1.ResumeLayout(false);
			tableLayoutPanel1.PerformLayout();
			panel5.ResumeLayout(false);
			panel5.PerformLayout();
			panel4.ResumeLayout(false);
			panel7.ResumeLayout(false);
			panel7.PerformLayout();
			ResumeLayout(false);
		}

		#endregion
		private FolderBrowserDialog folderBrowserDialog1;
		private ListBox listBox2;
		private ListBox listBox1;
		private Panel panel6;
		private Button button8;
		private Button button7;
		private Button button6;
		private Panel panel1;
		private Panel panel3;
		private Button button1;
		private Button button2;
		private Button button5;
		private Panel panel2;
		private Button button3;
		private TextBox textBox1;
		private TableLayoutPanel tableLayoutPanel1;
		private Button button9;
		private Button button11;
		private OpenFileDialog openFileDialog1;
		private Button button12;
		private Button button13;
		private Button button14;
		private Button button16;
		private Button button15;
		private Button button17;
		private SaveFileDialog saveFileDialog1;
		private Panel panel4;
		private Button button4;
		private Button button10;
		private Button button18;
		private Panel panel5;
		private TextBox textBox2;
		private TextBox textBox3;
		private Panel panel7;
		private Button button19;
		private TextBox textBox4;
		private ProgressBar progressBar1;
	}
}