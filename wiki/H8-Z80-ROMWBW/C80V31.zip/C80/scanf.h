/* Header file for scanf */
#undef scanf
#undef fscanf
#undef sscanf
#define scanf STK_pos(),scan_f
#define fscanf STK_pos(),f_scan
#define sscanf STK_pos(),s_scan


















/*
		       SAMPLE PROGRAM TO TEST SCANF.C
		  