Name      Issue #   Description
--------------------------------------------------------------
BUG8-1    02.01.01  H8 Console Debugger
BUG8-2    02.05.00  "  "       "
BUG8-6    02.06.00  "  "       "
TED8-1     3.01.01  H8 Text Editor
TED8-2     3.05.00  "  "    "
TED8-6    03.06.00  "  "    "
HASL8-1    4.01.01  H8 Assembly Language
HASL8-2   04.05.00  "  "        "
HASL8-6   04.06.00  "  "        "
BHBASIC1  05.01.01  Benton Harbor Basic
BHBASIC2  05.01.02  "      "      "
EXBASIC1  10.01.01  Extended Benton Harbor Basic
EXBASIC2  10.02.01  "        "      "      "
EXBASIC3  10.05.00  "        "      "      "
EXBASIC5  10.05.01  "        "      "      "
EXBASIC6  10.06.00  "        "      "      "

H8HANGM   20.00.00  H8 Hangman game
H8CRAPS   21.00.00  H8 Craps game
H8NIM     22.00.00  H8 NIM game
H8HEXPAW  23.00.00  H8 Hexpawn game
H8TICTAC  24.00.00  H8 Tic-Tac-Toe game
H8ORBIT   25.00.00  H8 Lunar Orbit game
HAMRABI   26.00.00  H8 Hamurabi game
H8DERBY   27.00.00  H8 Derby game
H8CHESS   --.--.--  H8 Chess game

CLOCK     --.--.--  front panel clock
CHASELED  --.--.--  cute front panel game
MASTMIND  --.--.--  Mastermind game
H8DEMO    --.--.--  H8 Front Panel DEMO program 
BHBCONS   --.--.--  Benton Harbor Basic Console functions (from tape label)
LED1/2/3  --.--.--  These appear to be LED test programs ???
UNKNOWN   --.--.--  No Idea - crashes!

