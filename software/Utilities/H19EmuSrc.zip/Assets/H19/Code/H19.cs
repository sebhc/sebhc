﻿using System.Collections;
using System.Collections.Generic;
using System.IO.Ports;
using UnityEngine;

public class H19 : MonoBehaviour
{
	public UnityEngine.UI.Text h19DebugText;
	//public MeshRenderer[,] h19Screen = new MeshRenderer[80, 25];
	//public MeshRenderer h19Cursor;
	public MeshRenderer h19FontChar;
	private H19Font h19Font;

	public Canvas configScreen;
	public UnityEngine.UI.Dropdown baudDropDown;
	public UnityEngine.UI.Dropdown comDropDown;

	private Texture2D h19ScreenTexture;
	public Renderer h19ScreenRenderer;

	public UnityEngine.UI.Slider s401_1;
	public UnityEngine.UI.Slider s401_2;
	public UnityEngine.UI.Slider s401_3;
	public UnityEngine.UI.Slider s401_4;
	public UnityEngine.UI.Slider s401_5;
	public UnityEngine.UI.Slider s401_6;
	public UnityEngine.UI.Slider s401_7;
	public UnityEngine.UI.Slider s401_8;

	public UnityEngine.UI.Slider s402_1;
	public UnityEngine.UI.Slider s402_2;
	public UnityEngine.UI.Slider s402_3;
	public UnityEngine.UI.Slider s402_4;
	public UnityEngine.UI.Slider s402_5;
	public UnityEngine.UI.Slider s402_6;
	public UnityEngine.UI.Slider s402_7;
	public UnityEngine.UI.Slider s402_8;

	[SerializeField]
	private Vector3 savePos;
	[SerializeField]
	private int column;
	[SerializeField]
	private int line;
	private byte[] vidmem = new byte[80 * 25];

	// 0-3=baud rate
	// 4=no parity/parity
	// 5=odd parity/even parity
	// 6=normal parity/?
	// 7=half duplex/full duplex
	public byte[] S401;
	// 0=underscore (0)/block cursor (1)
	// 1=key click (0)/no key click (1)
	// 2=discard past end of line/wrap around
	// 3=no auto-lf on cr/auto-lf on cr
	// 4=no auto-cr on lf/auto-cr on lf
	// 5=heath mode/ansi mode
	// 6=keypad normal/keypad shifted
	// 7=60hz/50hz
	public byte[] S402;

	private bool dca; // direct cursor address
	private int dcaIndex;
	private bool escSeq;
	private int escSeqIndex;
	private bool specialMode;
	private bool resetMode;
	private bool baudSeq;
	public bool offline;
	public bool halfDuplex;

	private byte[] ansiSeq = new byte[8];

	private int lineCursor = 27;
	private int blockCursor = 144;
	private int cursorType;
	private float blinkTimer;

	// states
	public bool enableANSIMode;
	public bool enableBlockCursor;
	public bool enableCursor;
	public bool enableInsertChar;
	public bool enableKeyboard;
	public bool enableKeyClick;
	public bool enableLine25;
	public bool enableLFonCR;
	public bool enableCRonLF;
	public bool enableWrapAround;
	public bool graphMode;
	public bool reverse;
	public bool shift;
	public bool control;
	public bool keypadShifted;
	public bool altKeypadMode;

	// I/O ports
	private SerialPort serialPort;
	private byte[] readBuffer = new byte[256];
	private byte[] writeBuffer = new byte[256];
	private int writeIndex;

	public string portName;
	public string portBaud;

	void Start()
	{
		cursorType = lineCursor;

		InitCOMPortItems();

		InitScreen();
		SetDefaults();
		ShowConfig();
	}

	void InitScreen()
	{
		h19ScreenTexture = new Texture2D(640, 250, TextureFormat.RGBA32, false, false);
		h19ScreenRenderer.material.mainTexture = h19ScreenTexture;

		int n = 0;
		for (int j = 0; j < 25; j++)
		{
			for (int i = 0; i < 80; i++)
			{
				//h19Screen[i, j] = Instantiate<MeshRenderer>(h19FontChar);
				//h19Screen[i, j].transform.parent = transform;
				//h19Screen[i, j].transform.localScale = new Vector3(8, -20, 1);
				//h19Screen[i, j].transform.position = new Vector3(-320 + (i * 8), 240 - (j * 20), 0);

				vidmem[n++] = 0x20;
			}
		}
		h19Font = GameObject.FindObjectOfType<H19Font>();

		//h19Cursor = Instantiate<MeshRenderer>(h19FontChar);
		//h19Cursor.transform.parent = transform;
		//h19Cursor.transform.localScale = new Vector3(8, -20, 1);
		//h19Cursor.transform.position = new Vector3(-320 + (column * 8), 240 - (line * 20), -1);
		//h19Cursor.material.mainTexture = h19Font.fontCharArray[27];
	}

	void SetDefaults()
	{
		enableANSIMode = false;
		enableBlockCursor = false;
		enableCRonLF = false;
		enableCursor = true;
		enableInsertChar = false;
		enableKeyboard = true;
		enableKeyClick = true;
		enableLFonCR = false;
		enableWrapAround = false;

		escSeq = false;
		graphMode = false;
		reverse = false;
		specialMode = false;
		resetMode = false;

		// 0=underscore (0)/block cursor (1)
		// 1=key click (0)/no key click (1)
		// 2=discard past end of line/wrap around
		// 3=no auto-lf on cr/auto-lf on cr
		// 4=no auto-cr on lf/auto-cr on lf
		// 5=heath mode/ansi mode
		// 6=keypad normal/keypad shifted
		// 7=60hz/50hz
		if (S402[0] != 0)
		{
			SetSpecialMode((byte)'4');
		}
		if (S402[1] != 0)
		{
			SetSpecialMode((byte)'2');
		}
		Disable25();
	}

	void Update()
	{
		UpdateConfigSwitches();
		HandleSerialPort();
		HandleKeyboardInput();
		UpdateVideo();
	}

	void UpdateConfigSwitches()
	{
		if (configScreen.gameObject.activeInHierarchy)
		{
			S401[0] = (byte)s401_1.value;
			S401[1] = (byte)s401_2.value;
			S401[2] = (byte)s401_3.value;
			S401[3] = (byte)s401_4.value;
			S401[4] = (byte)s401_5.value;
			S401[5] = (byte)s401_6.value;
			S401[6] = (byte)s401_7.value;
			S401[7] = (byte)s401_8.value;

			S402[0] = (byte)s402_1.value;
			S402[1] = (byte)s402_2.value;
			S402[2] = (byte)s402_3.value;
			S402[3] = (byte)s402_4.value;
			S402[4] = (byte)s402_5.value;
			S402[5] = (byte)s402_6.value;
			S402[6] = (byte)s402_7.value;
			S402[7] = (byte)s402_8.value;
		}
		else
		{
			s401_1.value = S401[0];
			s401_2.value = S401[1];
			s401_3.value = S401[2];
			s401_4.value = S401[3];
			s401_5.value = S401[4];
			s401_6.value = S401[5];
			s401_7.value = S401[6];
			s401_8.value = S401[7];

			s402_1.value = S401[0];
			s402_2.value = S401[1];
			s402_3.value = S401[2];
			s402_4.value = S401[3];
			s402_5.value = S401[4];
			s402_6.value = S401[5];
			s402_7.value = S401[6];
			s402_8.value = S401[7];
		}
	}

	void UpdateVideo()
	{
		// update Unity screen to represent H19 screen
		RenderScreen();
	}

	void HandleKeyboardInput()
	{
		if (Input.GetKeyDown(KeyCode.F12))
		{
			ShowConfig();
			return;
		}
		if (enableKeyboard)
		{
			byte c = KeyboardKey();
			if (c != 0)
			{
				if (shift && c == 0x1B)
				{
					Application.Quit();
				}
				else
				{
					if (shift)
					{
						c = HandleShiftedKey(c);
					}
					if (control)
					{
						c = HandleControlKey(c);
					}
					if (offline || halfDuplex)
					{
						InChar(c);
					}
					OutChar(c);
				}
			}
		}
	}

	byte HandleShiftedKey(byte c)
	{
		//Debug.Log("HandleShiftedKey() c=" + c.ToString());

		if (c == ';')
		{
			c = (byte)':';
		}
		else if (c == '\'')
		{
			c = (byte)'\"';
		}
		else if (c == ',')
		{
			c = (byte)'<';
		}
		else if (c == '.')
		{
			c = (byte)'>';
		}
		else if (c == '[')
		{
			c = (byte)'{';
		}
		else if (c == ']')
		{
			c = (byte)'}';
		}
		else if (c == '\\')
		{
			c = (byte)'|';
		}
		else if (c == '`')
		{
			c = (byte)'~';
		}
		else if (c == '1')
		{
			c = (byte)'!';
		}
		else if (c == '2')
		{
			c = (byte)'@';
		}
		else if (c == '3')
		{
			c = (byte)'#';
		}
		else if (c == '4')
		{
			c = (byte)'$';
		}
		else if (c == '5')
		{
			c = (byte)'%';
		}
		else if (c == '6')
		{
			c = (byte)'^';
		}
		else if (c == '7')
		{
			c = (byte)'&';
		}
		else if (c == '8')
		{
			c = (byte)'*';
		}
		else if (c == '9')
		{
			c = (byte)'(';
		}
		else if (c == '0')
		{
			c = (byte)')';
		}
		else if (c == '-')
		{
			c = (byte)'_';
		}
		else if (c == '=')
		{
			c = (byte)'+';
		}
		else if (c == '/')
		{
			c = (byte)'?';
		}
		else if (c >= 'a' && c <= 'z')
		{
			c &= 0x5F;
		}

		return c;
	}

	byte HandleControlKey(byte c)
	{
		c &= 0x1F;
		return c;
	}

	byte KeyboardKey()
	{
		if (Input.GetKeyDown(KeyCode.LeftShift) || Input.GetKeyDown(KeyCode.RightShift))
		{
			shift = true;
		}
		else if (Input.GetKeyUp(KeyCode.LeftShift) || Input.GetKeyUp(KeyCode.RightShift))
		{
			shift = false;
		}
		if (Input.GetKeyDown(KeyCode.LeftControl) || Input.GetKeyDown(KeyCode.RightControl))
		{
			control = true;
		}
		else if (Input.GetKeyUp(KeyCode.LeftControl) || Input.GetKeyUp(KeyCode.RightControl))
		{
			control = false;
		}
		else
		{
			if (keypadShifted)
			{
				if (Input.GetKeyDown(KeyCode.Keypad1))
				{
					OutChar(0x1B); // ESC
					OutChar((byte)'L');
					return 0;
				}
				if (Input.GetKeyDown(KeyCode.Keypad2))
				{
					OutChar(0x1B); // ESC
					OutChar((byte)'B');
					return 0;
				}
				if (Input.GetKeyDown(KeyCode.Keypad3))
				{
					OutChar(0x1B); // ESC
					OutChar((byte)'M');
					return 0;
				}
				if (Input.GetKeyDown(KeyCode.Keypad4))
				{
					OutChar(0x1B); // ESC
					OutChar((byte)'D');
					return 0;
				}
				if (Input.GetKeyDown(KeyCode.Keypad5))
				{
					OutChar(0x1B); // ESC
					OutChar((byte)'H');
					return 0;
				}
				if (Input.GetKeyDown(KeyCode.Keypad6))
				{
					OutChar(0x1B); // ESC
					OutChar((byte)'C');
					return 0;
				}
				if (Input.GetKeyDown(KeyCode.Keypad7))
				{
					OutChar(0x1B); // ESC
					OutChar((byte)'@');
					return 0;
				}
				if (Input.GetKeyDown(KeyCode.Keypad8))
				{
					OutChar(0x1B); // ESC
					OutChar((byte)'A');
					return 0;
				}
				if (Input.GetKeyDown(KeyCode.Keypad9))
				{
					OutChar(0x1B); // ESC
					OutChar((byte)'N');
					return 0;
				}
			}
			else
			{
				if (Input.GetKeyDown(KeyCode.Keypad1))
				{
					return (byte)'1';
				}
				if (Input.GetKeyDown(KeyCode.Keypad2))
				{
					return (byte)'2';
				}
				if (Input.GetKeyDown(KeyCode.Keypad3))
				{
					return (byte)'3';
				}
				if (Input.GetKeyDown(KeyCode.Keypad4))
				{
					return (byte)'4';
				}
				if (Input.GetKeyDown(KeyCode.Keypad5))
				{
					return (byte)'5';
				}
				if (Input.GetKeyDown(KeyCode.Keypad6))
				{
					return (byte)'6';
				}
				if (Input.GetKeyDown(KeyCode.Keypad7))
				{
					return (byte)'7';
				}
				if (Input.GetKeyDown(KeyCode.Keypad8))
				{
					return (byte)'8';
				}
				if (Input.GetKeyDown(KeyCode.Keypad9))
				{
					return (byte)'9';
				}
				if (Input.GetKeyDown(KeyCode.F1))
				{
					OutChar(0x1B);
					OutChar((byte)'S');
					return 0;
				}
				if (Input.GetKeyDown(KeyCode.F2))
				{
					OutChar(0x1B);
					OutChar((byte)'T');
					return 0;
				}
				if (Input.GetKeyDown(KeyCode.F3))
				{
					OutChar(0x1B);
					OutChar((byte)'U');
					return 0;
				}
				if (Input.GetKeyDown(KeyCode.F4))
				{
					OutChar(0x1B);
					OutChar((byte)'V');
					return 0;
				}
				if (Input.GetKeyDown(KeyCode.F5))
				{
					OutChar(0x1B);
					OutChar((byte)'W');
					return 0;
				}
				if (Input.GetKeyDown(KeyCode.F6)) // blue
				{
					OutChar(0x1B);
					OutChar((byte)'P');
					return 0;
				}
				if (Input.GetKeyDown(KeyCode.F7)) // red
				{
					OutChar(0x1B);
					OutChar((byte)'Q');
					return 0;
				}
				if (Input.GetKeyDown(KeyCode.F8)) // gray
				{
					OutChar(0x1B);
					OutChar((byte)'R');
					return 0;
				}
				if (Input.GetKeyDown(KeyCode.F10))
				{
					if (shift)
					{
						ResetToPowerUpConfig();
						EraseScreen();
					}
					return 0;
				}
			}
			for (int i = 0; i < 128; i++)
			{
				if (Input.GetKeyDown((KeyCode)i))
				{
					int n = i;
					return (byte)n;
				}
			}
		}
		return 0;
	}

	void InChar(byte c)
	{
		if (escSeq)
		{
			// escape command
			escSeqIndex = 0;
			HandleESCSeq(c);
		}
		else if (c == 0x1B)
		{
			escSeq = true;
		}
		else if (c >= 0x20 && c < 0x7F)
		{
			int m = (line * 80) + column;
			if (graphMode)
			{
				if (c == '^')
				{
					c = 127;
				}
				else if (c == '_')
				{
					c = 31;
				}
				else if (c >= 96 && c <= 126)
				{
					c -= 96;
				}
			}
			if (reverse)
			{
				c += 128;
			}

			if (enableInsertChar)
			{
				int e = ((line * 80) + 80) - 1;
				for (int i = e; i > m; i--)
				{
					vidmem[i] = vidmem[i - 1];
				}
			}

			vidmem[m] = c;

			column++;
			if (column == 80)
			{
				if (enableWrapAround)
				{
					column = 0;
					NextLine();
				}
				else
				{
					column = 79;
				}
			}
		}
		else if (c == 0x08)
		{
			column = (column > 0) ? column - 1 : 0;
		}
		else if (c == 0x09)
		{
			while ((column % 8) != 0)
			{
				column++;
			}
		}
		else if (c == 0x0D)
		{
			column = 0;
			if (enableLFonCR)
			{
				NextLine();
			}
		}
		else if (c == 0x0A)
		{
			if (enableCRonLF)
			{
				column = 0;
			}
			NextLine();
		}
	}

	void PrevLine()
	{
		if (line == 24)
		{
			return;
		}
		if (line == 0)
		{
			ScrollDown();
		}
		else
		{
			line--;
		}
	}

	void NextLine()
	{
		if (line == 24)
		{
			return;
		}
		if (line == 23)
		{
			ScrollUp();
		}
		else
		{
			line++;
		}
	}

	void OutChar(byte c)
	{
		if (offline)
		{
			return;
		}
		writeBuffer[writeIndex++] = c;
	}

	void HandleESCSeq(byte c)
	{
		if (enableANSIMode)
		{
			HandleANSIESCSeq(c);
			return;
		}
		if (dca)
		{
			DirectCursorAddress(c);
			return;
		}

		if (specialMode)
		{
			SetSpecialMode(c);
			specialMode = false;
			resetMode = false;
			escSeq = false;
			return;
		}

		if (baudSeq)
		{
			// Bn
			baudSeq = false;
			escSeq = false;
			return;
		}

		if (c == 'H')
		{
			SetCursorHome();
		}
		else if (c == 'C')
		{
			SetCursorForward();
		}
		else if (c == 'D')
		{
			SetCursorBackward();
		}
		else if (c == 'B')
		{
			SetCursorDown();
		}
		else if (c == 'A')
		{
			SetCursorUp();
		}
		else if (c == 'I')
		{
			PrevLine();
		}
		else if (c == 'n')
		{
			// report cursor position
			OutChar(0x1B); // ESC
			OutChar((byte)'Y'); // Y
			OutChar((byte)(line + 32));
			OutChar((byte)(column + 32));
		}
		else if (c == 'j')
		{
			SaveCursorPosition();
		}
		else if (c == 'k')
		{
			RestoreCursorPosition();
		}
		else if (c == 'Y')
		{
			dca = true;
			dcaIndex = 0;
			return;
		}
		else if (c == 'E')
		{
			EraseScreen();
		}
		else if (c == 'b')
		{
			EraseToBeginningOfScreen();
		}
		else if (c == 'J')
		{
			EraseToEndOfScreen();
		}
		else if (c == 'l')
		{
			EraseLine();
		}
		else if (c == 'o')
		{
			EraseToBeginningOfLine();
		}
		else if (c == 'K')
		{
			EraseToEndOfLine();
		}
		else if (c == 'L')
		{
			InsertLine();
		}
		else if (c == 'M')
		{
			DeleteLine();
		}
		else if (c == 'N')
		{
			DeleteChar();
		}
		else if (c == '@')
		{
			EnterInsertCharMode();
		}
		else if (c == 'O')
		{
			ExitInsertCharMode();
		}
		else if (c == 'z')
		{
			ResetToPowerUpConfig();
		}
		else if (c == 'G')
		{
			graphMode = false;
		}
		else if (c == 'F')
		{
			graphMode = true;
		}
		else if (c == 'p')
		{
			reverse = true;
		}
		else if (c == 'q')
		{
			reverse = false;
		}
		else if (c == 't')
		{
			// keypad shifted mode
		}
		else if (c == 'u')
		{
			// keypad unshifted mode
		}
		else if (c == '=')
		{
			// alternate keypad mode
		}
		else if (c == '>')
		{
			// exit alternate keypad mode
		}
		else if (c == 'x')
		{
			resetMode = false;
			specialMode = true;
			return;
		}
		else if (c == 'y')
		{
			resetMode = true;
			specialMode = true;
			return;
		}
		else if (c == '<')
		{
			enableANSIMode = true;
		}
		else if (c == '}')
		{
			// disable keyboard
			enableKeyboard = false;
		}
		else if (c == '{')
		{
			// enable keyboard
			enableKeyboard = true;
		}
		else if (c == 'v')
		{
			// enable wrap around at eol
			enableWrapAround = true;
		}
		else if (c == 'w')
		{
			// disable wrap around at eol
			enableWrapAround = false;
		}
		else if (c == 'Z')
		{
			// VT52
			OutChar(0x1B);
			OutChar((byte)'K');
		}
		else if (c == ']')
		{
			// xmit 25th line
		}
		else if (c == '#')
		{
			// xmit page
		}
		else if (c == 'r')
		{
			baudSeq = true;
			return;
		}

		//char ch = (char)c;
		//Debug.Log("HandleESCSeq() c=" + ch.ToString() + " line=" + line.ToString() + " column=" + column.ToString());

		escSeq = false;
	}

	void HandleANSIESCSeq(byte c)
	{
		switch (escSeqIndex)
		{
			case 0:
				if (c == '[')
				{
					escSeqIndex++;
					return;
				}
				else if (c == 'M')
				{
					// reverse index
					PrevLine();
				}
				break;
			default:
				if ((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z'))
				{
					PerformANSISeq(c);
				}
				else
				{
					ansiSeq[escSeqIndex] = c;
					escSeqIndex++;
					return;
				}
				break;
		}
		escSeq = false;
	}

	int ansiValueIndex;

	int GetANSIValue(int n)
	{
		int v = 0;
		for (int i = n; i < escSeqIndex; i++)
		{
			if (ansiSeq[i] == ';')
			{
				ansiValueIndex = i + 1;
				return v;
			}
			if (v != 0)
			{
				v *= 10;
			}
			v += (ansiSeq[i] - '0');
		}
		return v;
	}

	void PerformANSISeq(byte c)
	{
		if (c == 'H' || c == 'f')
		{
			if (escSeqIndex == 1)
			{
				SetCursorHome();
			}
			else
			{
				// line ; column
				int y = GetANSIValue(1);
				int x = GetANSIValue(ansiValueIndex);
				//int y = ansiSeq[1];
				//if (y == 0)
				//{
				//	y = 1;
				//}
				//int x = ansiSeq[3];
				//if (x == 0)
				//{
				//	x = 1;
				//}
				SetCursorAddress(x - 1, y - 1);
			}
		}
		else if (c == 'C')
		{
			int n = GetANSIValue(1);
			if (n == 0)
			{
				n = 1;
			}
			for (int i = 0; i < n; i++)
			{
				SetCursorForward();
			}
		}
		else if (c == 'D')
		{
			int n = GetANSIValue(1);
			if (n == 0)
			{
				n = 1;
			}
			for (int i = 0; i < n; i++)
			{
				SetCursorBackward();
			}
		}
		else if (c == 'B')
		{
			int n = GetANSIValue(1);
			if (n == 0)
			{
				n = 1;
			}
			for (int i = 0; i < n; i++)
			{
				SetCursorDown();
			}
		}
		else if (c == 'A')
		{
			int n = GetANSIValue(1);
			if (n == 0)
			{
				n = 1;
			}
			for (int i = 0; i < n; i++)
			{
				SetCursorUp();
			}
		}
		else if (c == 'n')
		{
			OutChar(0x1B);
			OutChar((byte)'[');
			string s1 = line.ToString();
			for (int i = 0; i < s1.Length; i++)
			{
				OutChar((byte)s1[i]);
			}
			//OutChar((byte)line);
			OutChar((byte)';');
			string s2 = column.ToString();
			for (int i = 0; i < s2.Length; i++)
			{
				OutChar((byte)s2[i]);
			}
			//OutChar((byte)column);
			OutChar((byte)'R');
		}
		else if (c == 's')
		{
			SaveCursorPosition();
		}
		else if (c == 'u')
		{
			RestoreCursorPosition();
		}
		else if (c == 'J')
		{
			int n = GetANSIValue(1);
			switch (n)
			{
				case 0:
					EraseToEndOfScreen();
					break;
				case 1:
					EraseToBeginningOfScreen();
					break;
				case 2:
					EraseScreen();
					break;
			}
		}
		else if (c == 'K')
		{
			int n = GetANSIValue(1);
			switch (n)
			{
				case 0:
					EraseToEndOfLine();
					break;
				case 1:
					EraseToBeginningOfLine();
					break;
				case 2:
					EraseLine();
					break;
			}
		}
		else if (c == 'L')
		{
			int n = GetANSIValue(1);
			if (n == 0)
			{
				n = 1;
			}
			for (int i = 0; i < n; i++)
			{
				InsertLine();
			}
		}
		else if (c == 'M')
		{
			int n = GetANSIValue(1);
			if (n == 0)
			{
				n = 1;
			}
			for (int i = 0; i < n; i++)
			{
				DeleteLine();
			}
		}
		else if (c == 'P')
		{
			int n = GetANSIValue(1);
			if (n == 0)
			{
				n = 1;
			}
			for (int i = 0; i < n; i++)
			{
				DeleteChar();
			}
		}
		else if (c == 'h')
		{
			if (ansiSeq[1] == '4')
			{
				EnterInsertCharMode();
			}
			else if (ansiSeq[1] == '>')
			{
				// set mode
				int n = GetANSIValue(2);
				switch (n)
				{
					case 1:
						Enable25();
						break;
					case 2:
						enableKeyClick = false;
						break;
					case 3:
						// enter hold screen mode
						break;
					case 4:
						enableBlockCursor = true;
						break;
					case 5:
						enableCursor = false;
						break;
					case 6:
						keypadShifted = true;
						break;
					case 7:
						altKeypadMode = true;
						break;
					case 8:
						enableLFonCR = true;
						break;
					case 9:
						enableCRonLF = true;
						break;
				}
			}
			else if (ansiSeq[1] == '?')
			{
				if (ansiSeq[2] == '7')
				{
					enableWrapAround = true;
				}
			}
		}
		else if (c == 'l')
		{
			if (ansiSeq[1] == '4')
			{
				ExitInsertCharMode();
			}
			else if (ansiSeq[1] == '>')
			{
				// reset mode
				int n = GetANSIValue(2);
				switch (n)
				{
					case 1:
						Disable25();
						break;
					case 2:
						enableKeyClick = true;
						break;
					case 3:
						// exit hold screen mode
						break;
					case 4:
						enableBlockCursor = false;
						break;
					case 5:
						enableCursor = true;
						break;
					case 6:
						keypadShifted = false;
						break;
					case 7:
						altKeypadMode = false;
						break;
					case 8:
						enableLFonCR = false;
						break;
					case 9:
						enableCRonLF = false;
						break;
				}
			}
			else if (ansiSeq[1] == '?')
			{
				if (ansiSeq[2] == '2')
				{
					enableANSIMode = false;
				}
				else if (ansiSeq[2] == '7')
				{
					enableWrapAround = false;
				}
			}
		}
		else if (c == 'z')
		{
			ResetToPowerUpConfig();
		}
		else if (c == 'm')
		{
			if (escSeqIndex == 1)
			{
				reverse = false;
			}
			else
			{
				int n = GetANSIValue(1);
				switch (n)
				{
					case 0:
						reverse = false;
						break;
					case 7:
						reverse = true;
						break;
					case 10:
						graphMode = true;
						break;
					case 11:
						graphMode = false;
						break;
				}
			}
		}
		else if (c == 'q')
		{
			// xmit 25th line
		}
		else if (c == 'p')
		{
			// xmit page
		}
	}

	void DirectCursorAddress(byte c)
	{
		if (dcaIndex == 0)
		{
			line = c - 32;
			dcaIndex++;
		}
		else
		{
			column = c - 32;
			escSeq = false;
			dca = false;
		}
	}

	void SetSpecialMode(byte c)
	{
		if (c == '1')
		{
			enableLine25 = (resetMode) ? false : true;
			if (enableLine25)
			{
				Enable25();
			}
			else
			{
				Disable25();
			}
		}
		else if (c == '2')
		{
			// no key click
			enableKeyClick = (resetMode) ? true : false;
		}
		else if (c == '3')
		{
			// hold screen mode
		}
		else if (c == '4')
		{
			// block cursor
			enableBlockCursor = (resetMode) ? false : true;
		}
		else if (c == '5')
		{
			// cursor off
			enableCursor = (resetMode) ? true : false;
		}
		else if (c == '6')
		{
			// keypad shifted
			keypadShifted = (resetMode) ? false : true;
		}
		else if (c == '7')
		{
			// alternate keypad mode
			altKeypadMode = (resetMode) ? false : true;
		}
		else if (c == '8')
		{
			// auto linefeed on CR
			enableLFonCR = (resetMode) ? false : true;
		}
		else if (c == '9')
		{
			// auto CR on linefeed
			enableCRonLF = (resetMode) ? false : true;
		}
	}

	// scroll text down
	void ScrollDown()
	{
		int end = 23;
		int beg = 0;
		for (int i = end; i > beg; i--)
		{
			int n = i - 1;
			if (n >= 0)
			{
				int idx1 = n * 80;
				int idx2 = i * 80;
				for (int j = 0; j < 80; j++)
				{
					vidmem[idx2 + j] = vidmem[idx1 + j];
				}
			}
		}

		int idx = 0;
		for (int i = 0; i < 80; i++)
		{
			vidmem[idx + i] = 0x20;
		}
	}

	// scroll text up
	void ScrollUp()
	{
		int end = 23;
		int beg = 0;
		for (int i = beg; i < end; i++)
		{
			int n = i + 1;
			if (n < 24)
			{
				int idx1 = n * 80;
				int idx2 = i * 80;
				for (int j = 0; j < 80; j++)
				{
					vidmem[idx2 + j] = vidmem[idx1 + j];
				}
			}
		}

		int idx = 23 * 80;
		for (int i = 0; i < 80; i++)
		{
			vidmem[idx + i] = 0x20;
		}
	}

	void PutDebugLine(int i, string s)
	{
		int n = i * 80;
		for (int j = 0; j < s.Length; j++)
		{
			vidmem[n + j] = (byte)s[j];
		}
	}

	void SetCursorHome()
	{
		line = 0;
		column = 0;
	}

	void SetCursorForward()
	{
		column = Mathf.Min(79, column + 1);
	}

	void SetCursorBackward()
	{
		column = Mathf.Max(0, column - 1);
	}

	void SetCursorDown()
	{
		line = Mathf.Min(23, line + 1);
	}

	void SetCursorUp()
	{
		line = Mathf.Max(0, line - 1);
	}

	void SaveCursorPosition()
	{
		savePos = new Vector3(column, line, 0);
	}

	void RestoreCursorPosition()
	{
		column = (int)savePos.x;
		line = (int)savePos.y;
	}

	void SetCursorAddress(int x, int y)
	{
		line = y;
		column = x;
	}

	void EraseSection(int beg, int end)
	{
		for (int i = beg; i <= end; i++)
		{
			vidmem[i] = 0x20;
		}
	}

	void EraseScreen()
	{
		if (line == 24)
		{
			int beg = 24 * 80;
			int end = beg + 80;
			EraseSection(beg, end - 1);
			column = 0;
		}
		else
		{
			int end = 24 * 80;
			EraseSection(0, end - 1);
			SetCursorHome();
		}
	}

	void EraseToBeginningOfScreen()
	{
		if (line == 24)
		{
			EraseToBeginningOfLine();
		}
		else
		{
			int end = (line * 80) + column;
			EraseSection(0, end);
		}
	}

	void EraseToEndOfScreen()
	{
		if (line == 24)
		{
			EraseToEndOfLine();
		}
		else
		{
			int beg = (line * 80) + column;
			int end = 24 * 80;
			EraseSection(beg, end - 1);
		}
	}

	void EraseLine()
	{
		int beg = line * 80;
		int end = beg + 80;
		EraseSection(beg, end - 1);
	}

	void EraseToBeginningOfLine()
	{
		int end = (line * 80) + column;
		int beg = (line * 80);
		EraseSection(beg, end);
	}

	void EraseToEndOfLine()
	{
		int end = (line * 80) + 80;
		int beg = (line * 80) + column;
		EraseSection(beg, end - 1);
	}

	void InsertLine()
	{
		int end = 23;
		int beg = line;
		for (int i = end; i > beg; i--)
		{
			int n = i - 1;
			if (n >= 0)
			{
				int idx1 = n * 80;
				int idx2 = i * 80;
				for (int j = 0; j < 80; j++)
				{
					vidmem[idx2 + j] = vidmem[idx1 + j];
				}
			}
		}

		int idx = line * 80;
		for (int i = 0; i < 80; i++)
		{
			vidmem[idx + i] = 0x20;
		}

		column = 0;
	}

	void DeleteLine()
	{
		int end = 23;
		int beg = line;
		for (int i = beg; i < end; i++)
		{
			int n = i + 1;
			if (n < 24)
			{
				int idx1 = n * 80;
				int idx2 = i * 80;
				for (int j = 0; j < 80; j++)
				{
					vidmem[idx2 + j] = vidmem[idx1 + j];
				}
			}
		}

		int idx = 23 * 80;
		for (int i = 0; i < 80; i++)
		{
			vidmem[idx + i] = 0x20;
		}

		column = 0;
	}

	void DeleteChar()
	{
		int idx1 = (line * 80);
		for (int i = column; i < 80; i++)
		{
			int n = idx1 + i;
			if (((n + 1) % 80) != 0)
			{
				vidmem[n] = vidmem[n + 1];
			}
		}
		vidmem[idx1 + 79] = 0x20;
	}

	void EnterInsertCharMode()
	{
		enableInsertChar = true;
	}

	void ExitInsertCharMode()
	{
		enableInsertChar = false;
	}

	void ResetToPowerUpConfig()
	{
		SetDefaults();
	}

	void RenderScreen()
	{
		/*
		int n = 0;
		for (int y = 0; y < 25; y++)
		{
			for (int x = 0; x < 80; x++)
			{
				byte c = (byte)(n % 256);
				if (c != 0)
				{
					RenderChar(x, y, c);
				}
				n++;
			}
		}
		//*/
		///*
		for (int i = 0; i < vidmem.Length; i++)
		{
			int x = i % 80;
			int y = i / 80;
			byte c = vidmem[i];
			RenderChar(x, y, c);
		}

		ShowCursor();

		h19ScreenTexture.Apply();
		//*/
	}

	void RenderChar(int x, int y, byte c)
	{
		//h19Screen[x, y].material.mainTexture = h19Font.fontCharArray[c];
		Texture2D tex = h19Font.fontCharArray[c];

		int yPos = y * 10;
		for (int j = 0; j < 10; j++)
		{
			int xPos = x * 8;
			for (int i = 0; i < 8; i++)
			{
				h19ScreenTexture.SetPixel(xPos, yPos, tex.GetPixel(i,j));
				xPos++;
			}
			yPos++;
		}
	}

	void Enable25()
	{
		enableLine25 = true;
	}

	void Disable25()
	{
		int y = 24 * 80;
		for (int i = 0; i < 80; i++)
		{
			int n = y + i;
			vidmem[n] = 0x20;
		}
		enableLine25 = false;
	}

	private bool cursorVis;

	void ShowCursor()
	{
		if (enableCursor)
		{
			blinkTimer += Time.deltaTime;
			if (blinkTimer > 0.1f)
			{
				//h19Cursor.gameObject.SetActive(!h19Cursor.gameObject.activeSelf);
				cursorVis = !cursorVis;
				blinkTimer = 0;
			}
		}
		else
		{
			//h19Cursor.gameObject.SetActive(false);
		}
		//h19Cursor.transform.position = new Vector3(-320 + (column * 8), 240 - (line * 20), -1);

		if (enableBlockCursor)
		{
			cursorType = blockCursor;
		}
		else
		{
			cursorType = lineCursor;
		}
		//h19Cursor.material.mainTexture = h19Font.fontCharArray[cursorType];

		if (cursorVis && enableCursor)
		{
			RenderChar(column, line, (byte)cursorType);
		}
	}

	//
	public string comPortString;
	public int baudRate;

	public void ShowConfig()
	{
		configScreen.gameObject.SetActive(true);
		h19ScreenRenderer.gameObject.SetActive(false);
		SetBaud();
	}

	public void HideConfig()
	{
		configScreen.gameObject.SetActive(false);
		h19ScreenRenderer.gameObject.SetActive(true);
	}

	public void SetBaud()
	{
		baudRate = int.Parse(baudDropDown.captionText.text);
		SetBaudDipSwitches();
	}

	void SetBaudDipSwitches()
	{
		switch (baudRate)
		{
			case 300:
				s401_1.value = 1;
				s401_2.value = 1;
				s401_3.value = 0;
				s401_4.value = 0;
				break;
			case 600:
				s401_1.value = 0;
				s401_2.value = 0;
				s401_3.value = 1;
				s401_4.value = 0;
				break;
			case 1200:
				s401_1.value = 1;
				s401_2.value = 0;
				s401_3.value = 1;
				s401_4.value = 0;
				break;
			case 2400:
				s401_1.value = 0;
				s401_2.value = 0;
				s401_3.value = 0;
				s401_4.value = 1;
				break;
			case 4800:
				s401_1.value = 0;
				s401_2.value = 1;
				s401_3.value = 0;
				s401_4.value = 1;
				break;
			case 9600:
				s401_1.value = 0;
				s401_2.value = 0;
				s401_3.value = 1;
				s401_4.value = 1;
				break;
			case 19200:
				s401_1.value = 1;
				s401_2.value = 0;
				s401_3.value = 1;
				s401_4.value = 1;
				break;
			case 38400:
				s401_1.value = 0;
				s401_2.value = 1;
				s401_3.value = 1;
				s401_4.value = 1;
				break;
			case 57600:
				s401_1.value = 1;
				s401_2.value = 1;
				s401_3.value = 1;
				s401_4.value = 1;
				break;
		}
	}

	public void SetCOMPort()
	{
		if (string.IsNullOrEmpty(comDropDown.captionText.text))
		{
			return;
		}
		comPortString = comDropDown.captionText.text;
	}

	void InitCOMPortItems()
	{
		string[] comPortNames = SerialPort.GetPortNames();
		for (int i = 0; i < comDropDown.options.Count; i++)
		{
			if (i < comPortNames.Length)
			{
				comDropDown.options[i].text = comPortNames[i];
			}
			else
			{
				comDropDown.options[i].text = "";
			}
		}
		comDropDown.captionText.text = comPortNames[0];
	}

	public void SetupSerialPort()
	{
		if (serialPort != null)
		{
			if (serialPort.IsOpen)
			{
				serialPort.Close();
			}
			serialPort = null;
		}

		comPortString = comDropDown.captionText.text;

		int baud = 0;
		int b = S401[0] | (S401[1] << 1) | (S401[2] << 2) | (S401[3] << 3);
		switch (b)
		{
			case 0x01:
				baud = 110;
				break;
			case 0x02:
				baud = 150;
				break;
			case 0x03:
				baud = 300;
				break;
			case 0x04:
				baud = 600;
				break;
			case 0x05:
				baud = 1200;
				break;
			case 0x06:
				baud = 1800;
				break;
			case 0x07:
				baud = 2000;
				break;
			case 0x08:
				baud = 2400;
				break;
			case 0x09:
				baud = 3600;
				break;
			case 0x0A:
				baud = 4800;
				break;
			case 0x0B:
				baud = 7200;
				break;
			case 0x0C:
				baud = 9600;
				break;
			case 0x0D:
				baud = 19200;
				break;
			case 0x0E:
				baud = 38400;
				break;
			case 0x0F:
				baud = 57600;
				break;
			default:
				baud = 9600;
				break;
		}

		serialPort = new SerialPort(comPortString, baud, Parity.None, 8, StopBits.One);
		//serialPort.BaudRate = baud;
		//serialPort.Parity = Parity.None;
		//serialPort.DataBits = 8;
		//serialPort.StopBits = StopBits.One;
		serialPort.Handshake = Handshake.None; // Handshake.RequestToSend;

		portName = serialPort.PortName;
		portBaud = serialPort.BaudRate.ToString();

		Debug.Log("serialPort.Open() " + serialPort.PortName + " baud=" + baud.ToString());

		try
		{
			serialPort.Open();
			Debug.Log("SerialPort open");
		}
		catch
		{
			Debug.Log("No serial port found");
			offline = true;
		}

		HideConfig();
	}

	void HandleSerialPort()
	{
		if (offline)
		{
			return;
		}
		if (serialPort != null && serialPort.IsOpen)
		{
			int bytes = serialPort.BytesToRead;
			if (bytes > 0)
			{
				serialPort.Read(readBuffer, 0, bytes);
				for (int i = 0; i < bytes; i++)
				{
					byte b = readBuffer[i];

					//Debug.Log("In " + b.ToString());

					InChar(b);
				}
			}

			if (writeIndex > 0)
			{
				//if (serialPort.CtsHolding)
				{
					//Debug.Log("Out " + writeIndex.ToString());
					serialPort.Write(writeBuffer, 0, writeIndex);
					//Debug.Log("Out " + writeIndex.ToString() + " Byte=" + writeBuffer[0].ToString());
				}
				writeIndex = 0;
			}
		}
	}
}
