﻿//
//  Heathkit H19 Emulator
//  02/16/2010 by Les Bird
//  http://sebhc.lesbird.com
//
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.IO.Ports;
using System.Linq;
using System.Media;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows.Forms;
using Microsoft.Xna.Framework.Graphics;
using Z80;

namespace H19Emu
{
    public partial class Form1 : Form
    {
        public class H19Panel : Form
        {
            protected override void OnPaintBackground(PaintEventArgs e)
            {
            }
        }

        //
        //  the variables
        //

        string Vers = "V1.18";

        public H19.H19Memory H19MEM;
        public H19.H19IO H19IO;
        public uP H19Z80;
        public Z80Disassembler Z80Disasm;
        public Form2 Z80DisasmOutput;
        public ushort BreakPointAdr;
        public bool bStepping;
        public bool bViewScatchPad;

        public Form3 ScratchPadDump;

        private bool bH19Init;
        private bool bH19CursorOn;
        private int H19CursorUpdateCount;
        private System.Drawing.Color H19ScreenColor = System.Drawing.Color.Lime;
        //private PointF H19Scale = new PointF(1.4f, 2);
        private PointF H19Scale = new PointF(2, 3);
        private const int H19FontHeight = 16;
        private const int H19FontWidth = 8;
        private int H19ScreenCellWidth = 8;
        private int H19ScreenCellHeight = 10;
        private SpriteBatch H19FontSprite;
        private Texture2D[] H19Font = new Texture2D[256];
        private GraphicsDevice H19RenderDevice;
        private PresentationParameters H19RenderParams;
        private H19Panel H19RenderSurface;
        //  Indexes into H19MEM.Raw[]
        private int H19CursH = 0x40BA;  //  cursor horizontal position
        private int H19CursV = 0x40BB;  //  cursor vertical position
        private int H19VidOr = 0x40B6;  //  video memory origin
        private int H19VidSA = 0x40C1;  //  video start address (offset from above)
        private int H19ModeA = 0x40C7;  //  mode A bits
        private int H19ModeB = 0x40C8;  //  mode B bits
        private int H19ModeI = 0x40C9;  //  mode I bits

        struct ScratchPadRam
        {
            public int H19CursH;
            public int H19CursV;
            public int H19VidOr;
            public int H19VidSA;
            public int H19ModeA;
            public int H19ModeB;
            public int H19ModeI;
        };

        ScratchPadRam[] ScratchPad = new ScratchPadRam[3];

        private bool bInterrupt;
        private char[] KeyboardBuffer = new char[64];
        private int KeyboardBufferBeg;
        private int KeyboardBufferEnd;

        private byte[] SerOutputBuf = new byte[2];

        private int GlobalTick;
        private int UpdateTick;

        public bool bSetSwitchButtons = false;

        public int SW401 = 0x8C;
        public int SW402 = 0x00;

        public RadioButton[] SW401Button = new RadioButton[16];
        public RadioButton[] SW402Button = new RadioButton[16];

        public int FrameCount;

        //
        //  the code
        //

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            label23.Text = Vers;

            H19MEM = new H19Emu.H19.H19Memory();
            H19IO = new H19Emu.H19.H19IO(this);
            H19Z80 = new uP(H19MEM, H19IO);
            H19Z80.OnFetch += new uP.OnFetchHandler(H19Z80_OnFetch);
            H19MEM.OnRead += new OnReadHandler(H19MEM_OnRead);
            H19MEM.OnWrite += new OnWriteHandler(H19MEM_OnWrite);
            Z80Disasm = new Z80Disassembler(H19MEM);

            //  These are memory addresses into the scratchpad area where I can
            //  extract useful information. These values were sent directly to the
            //  CRTC on a real H19.
            ScratchPad[0].H19CursH = 0x40BA;    //  standard H19 ROM
            ScratchPad[0].H19CursV = 0x40BB;
            ScratchPad[0].H19VidOr = 0x40B6;
            ScratchPad[0].H19VidSA = 0x40C1;
            ScratchPad[0].H19ModeA = 0x40C7;
            ScratchPad[0].H19ModeB = 0x40C8;
            ScratchPad[0].H19ModeI = 0x40C9;

            ScratchPad[1].H19CursH = 0x40BA;    //  Super-19 ROM
            ScratchPad[1].H19CursV = 0x40BB;
            ScratchPad[1].H19VidOr = 0x40B6;
            ScratchPad[1].H19VidSA = 0x40C2;
            ScratchPad[1].H19ModeA = 0x40C7;
            ScratchPad[1].H19ModeB = 0x40C8;
            ScratchPad[1].H19ModeI = 0x40C9;

            ScratchPad[2].H19CursH = 0x40AA;    //  Watzmam ROM
            ScratchPad[2].H19CursV = 0x40AB;
            ScratchPad[2].H19VidOr = 0x40B6;
            ScratchPad[2].H19VidSA = 0x40AE;
            ScratchPad[2].H19ModeA = 0x40B4;
            ScratchPad[2].H19ModeB = 0x40B5;
            ScratchPad[2].H19ModeI = 0x40B6;

            string[] port_list = SerialPort.GetPortNames();
            if (port_list.Length > 0)
            {
                for (int i = 0; i < port_list.Length; i++)
                {
                    comboBox1.Items.Add(string.Format("{0}", port_list[i]));
                }
                comboBox1.SelectedIndex = 0;
            }

            comboBox2.Items.Add("N/A");
            comboBox2.Items.Add("110");
            comboBox2.Items.Add("150");
            comboBox2.Items.Add("300");
            comboBox2.Items.Add("600");
            comboBox2.Items.Add("1200");
            comboBox2.Items.Add("1800");
            comboBox2.Items.Add("2000");
            comboBox2.Items.Add("2400");
            comboBox2.Items.Add("3600");
            comboBox2.Items.Add("4800");
            comboBox2.Items.Add("7200");
            comboBox2.Items.Add("9600");
            comboBox2.Items.Add("19200");

            //  the code rom
            comboBox3.Items.Add("444-46");
            comboBox3.Items.Add("Super-19");
            comboBox3.Items.Add("Watzman-19");
            comboBox3.SelectedIndex = 0;
            comboBox3.Enabled = true;
            
            //  don't really use the keyboard rom
            comboBox4.Items.Add("444-37");
            comboBox4.SelectedIndex = 0;
            comboBox4.Enabled = false;
            
            //  copy the font rom to XNA sprites - actually done in H19LoadFont()
            comboBox5.Items.Add("444-29");
            comboBox5.SelectedIndex = 0;
            comboBox5.Enabled = false;

            SW401Button[0] = radioButton1;
            SW401Button[1] = radioButton2;
            SW401Button[2] = radioButton3;
            SW401Button[3] = radioButton4;
            SW401Button[4] = radioButton5;
            SW401Button[5] = radioButton6;
            SW401Button[6] = radioButton7;
            SW401Button[7] = radioButton8;
            SW401Button[8] = radioButton9;
            SW401Button[9] = radioButton10;
            SW401Button[10] = radioButton11;
            SW401Button[11] = radioButton12;
            SW401Button[12] = radioButton13;
            SW401Button[13] = radioButton14;
            SW401Button[14] = radioButton15;
            SW401Button[15] = radioButton16;

            SW402Button[0] = radioButton31;
            SW402Button[1] = radioButton32;
            SW402Button[2] = radioButton29;
            SW402Button[3] = radioButton30;
            SW402Button[4] = radioButton27;
            SW402Button[5] = radioButton28;
            SW402Button[6] = radioButton25;
            SW402Button[7] = radioButton26;
            SW402Button[8] = radioButton23;
            SW402Button[9] = radioButton24;
            SW402Button[10] = radioButton21;
            SW402Button[11] = radioButton22;
            SW402Button[12] = radioButton19;
            SW402Button[13] = radioButton20;
            SW402Button[14] = radioButton17;
            SW402Button[15] = radioButton18;

            SetSwitchButtons();
            SetBaudRateSelection();

            button3.BackColor = H19ScreenColor;

            H19LoadROM();
            H19Z80.Reset();
            H19IO.ResetPorts();
        }

        public void H19Reset()
        {
            H19Z80.Reset();
            H19IO.ResetPorts();
            KeyboardBufferBeg = KeyboardBufferEnd = 0;
            bInterrupt = false;
            bStepping = false;
        }

        public void H19Z80_OnFetch()
        {
            GlobalTick = Environment.TickCount & Int32.MaxValue;

            bool update_scratch = false;

            //  a timer for the events, kick it off every 66ms (15 times a second)
            if (GlobalTick - UpdateTick >= 66)
            {
                Application.DoEvents();
                UpdateTick = GlobalTick;
                //  check the cursor disable flag
                if ((H19MEM.Raw[H19ModeA] & 0x10) == 0x10)
                {
                    bH19CursorOn = false;
                }
                else
                {
                    //  blink the cursor
                    if ((H19CursorUpdateCount & 0x01) != 0)
                    {
                        if (bH19CursorOn)
                        {
                            bH19CursorOn = false;
                        }
                        else
                        {
                            bH19CursorOn = true;
                        }
                        H19Paint();
                    }
                    H19CursorUpdateCount++;
                }
                update_scratch = true;
            }
            if (bInterrupt)
            {
                if (H19Z80.Status.IFF1)
                {
                    H19Z80.Status.I = 7;
                    H19Z80.Interrupt();
                    bInterrupt = false;
                }
            }
            else
            {
                if ((H19IO.Ports[0x42] & 0x01) == 0x01)
                {
                    if (serialPort1.IsOpen)
                    {
                        if (serialPort1.BytesToRead > 0)
                        {
                            //  issue a data ready interrupt
                            H19IO.Ports[0x40] = (byte)serialPort1.ReadByte();
                            H19IO.Ports[0x42] = 0x04;
                            H19IO.Ports[0x45] = 0x61;
                            bInterrupt = true;
                        }
                    }
                    if (!bInterrupt)
                    {
                        if ((H19IO.Ports[0x41] & 0x02) == 0x02)
                        {
                            //  issue a transmitter shift register empty interrupt
                            H19IO.Ports[0x42] = 0x02;
                            H19IO.Ports[0x45] = 0x60;
                            bInterrupt = true;
                        }
                    }
                    if (!bInterrupt)
                    {
                        if ((H19IO.Ports[0xA0] & 0x80) == 0x80)
                        {
                            if (KeyboardBufferStatus())
                            {
                                //  set the keyboard data strobe
                                H19IO.Ports[0xA0] &= 0x7F;
                                bInterrupt = true;
                            }
                        }
                    }
                }
            }
            if (!bStepping)
            {
                if (BreakPointAdr != 0 && H19Z80.Status.PC == BreakPointAdr)
                {
                    bStepping = true;
                    H19Z80.StatementsToFetch = 1;
                    GotoZ80PC();
                }
            }
            if (bViewScatchPad)
            {
                if (update_scratch)
                {
                    string scratch_pad_text = "";

                    for (int i = 0; i < 0x0200; i += 16)
                    {
                        scratch_pad_text += string.Format("{0:X4}:", 0x4000 + i);
                        for (int j = 0; j < 16; j++)
                        {
                            scratch_pad_text += string.Format("{0:X2} ", H19MEM.Raw[0x4000 + i + j]);
                        }
                        scratch_pad_text += "\n";
                    }
                    ScratchPadDump.FillTextBox(scratch_pad_text);
                    ScratchPadDump.Update();
                }
            }
        }

        public void H19MEM_OnRead(ushort address)
        {
            if (address >= 0x1000)
            {
                if (checkBox3.Checked)
                {
                    AddToLog(string.Format("MEMR {0:X4}->{1:X2}", address, H19MEM.Raw[address]));
                }
            }
        }

        public void H19MEM_OnWrite(ushort address, byte value)
        {
            if (address >= 0x1000)
            {
                if (checkBox3.Checked)
                {
                    AddToLog(string.Format("MEMW {0:X4}<-{1:X2}", address, value));
                }
            }
            H19MEM.Raw[address] = value;
            if (address >= 0xF800)
            {
                H19Paint();
            }
        }

        public byte OnPortRead(ushort port, byte value)
        {
            //  keyboard encoder
            if (port == 0x80)
            {
                if (KeyboardBufferStatus())
                {
                    value = (byte)KeyboardBufferRead();
                }
                //  reset the keyboard data strobe
                if ((H19IO.Ports[0xA0] & 0x80) == 0)
                {
                    H19IO.Ports[0xA0] |= 0x80;
                }
            }
            //  keyboard status
            if (port == 0xA0)
            {
                if (checkBox1.Checked)
                {
                    value &= 0xF7;
                }
            }
            //  ACE port
            if (port >= 0x40 && port <= 0x47)
            {
                //  reset the interrupt pending bit
                if (port == 0x40)
                {
                    if ((H19IO.Ports[0x42] & 0x04) == 0x04)
                    {
                        H19IO.Ports[0x42] = 0x01;
                    }
                }
                else if (port == 0x42)
                {
                    if ((H19IO.Ports[0x42] & 0x02) == 0x02)
                    {
                        H19IO.Ports[0x42] = 0x01;
                    }
                }
            }
            if (checkBox4.Checked)
            {
                if (port < 0x60 || port > 0x6F)
                {
                    AddToLog(string.Format("INP {0:X2},{1:X2}", port, value));
                }
            }
            return (value);
        }

        public void OnPortWrite(ushort port, byte value)
        {
            if (port == 0x40)
            {
                if (serialPort1.IsOpen)
                {
                    SerOutputBuf[0] = value;
                    serialPort1.Write(SerOutputBuf, 0, 1);
                }
            }
            else if (port == 0xC0)
            {
                //  key click
            }
            else if (port == 0xE0)
            {
                //  bell
                SystemSounds.Beep.Play();
            }
            if (checkBox4.Checked)
            {
                if (port < 0x60 || port > 0x6F)
                {
                    AddToLog(string.Format("OUTP {0:X2},{1:X2}", port, value));
                }
            }
        }

        public void H19LoadROM()
        {
            H19Reset();
            string file_name = "";
            switch (comboBox3.SelectedIndex)
            {
                case 0:
                    file_name = "ROMS\\2732_444-46_H19CODE.BIN";
                    break;
                case 1:
                    file_name = "ROMS\\2732_H447_SUPER19.BIN";
                    break;
                case 2:
                    file_name = "ROMS\\2732_WATZMAN_H19CODE.BIN";
                    break;
            }
            H19CursH = ScratchPad[comboBox3.SelectedIndex].H19CursH;
            H19CursV = ScratchPad[comboBox3.SelectedIndex].H19CursV;
            H19VidOr = ScratchPad[comboBox3.SelectedIndex].H19VidOr;
            H19VidSA = ScratchPad[comboBox3.SelectedIndex].H19VidSA;
            H19ModeA = ScratchPad[comboBox3.SelectedIndex].H19ModeA;
            H19ModeB = ScratchPad[comboBox3.SelectedIndex].H19ModeB;
            H19ModeI = ScratchPad[comboBox3.SelectedIndex].H19ModeI;

            Stream stream = new FileStream(string.Format("{0}\\{1}", Application.StartupPath, file_name), FileMode.Open);
            stream.Read(H19MEM.Raw, 0x0000, (int)stream.Length);
            stream.Close();
        }

        private void H19Paint()
        {
            H19RenderSurface.Invalidate();
        }

        void H19Form_Paint(object sender, PaintEventArgs e)
        {
            if (H19RenderDevice == null)
            {
                return;
            }

            switch (H19RenderDevice.GraphicsDeviceStatus)
            {
                case GraphicsDeviceStatus.Lost:
                    return;
                    break;
                case GraphicsDeviceStatus.NotReset:
                    H19RenderDevice.Reset(H19RenderParams);
                    return;
                    break;
            }

            Microsoft.Xna.Framework.Graphics.Color color = new Microsoft.Xna.Framework.Graphics.Color(H19ScreenColor.R, H19ScreenColor.G, H19ScreenColor.B);
            Microsoft.Xna.Framework.Vector2 p = Microsoft.Xna.Framework.Vector2.Zero;

            H19RenderDevice.Clear(Microsoft.Xna.Framework.Graphics.Color.Black);

            Microsoft.Xna.Framework.Matrix scale = Microsoft.Xna.Framework.Matrix.CreateScale(H19Scale.X, H19Scale.Y, 1);
            H19FontSprite.Begin(SpriteBlendMode.Additive, SpriteSortMode.Immediate, SaveStateMode.None, scale);
            if (checkBox5.Checked)
            {
                H19RenderDevice.SamplerStates[0].MinFilter = TextureFilter.Linear;
                H19RenderDevice.SamplerStates[0].MagFilter = TextureFilter.Linear;
            }
            else
            {
                H19RenderDevice.SamplerStates[0].MinFilter = TextureFilter.None;
                H19RenderDevice.SamplerStates[0].MagFilter = TextureFilter.None;
            }

            //string frame = string.Format("{0}", FrameCount);
            //for (int n = 0; n < frame.Length; n++)
            //{
            //    H19MEM.Raw[0xF800 + n] = (byte)frame[n];
            //}

            int start_address = 0;
            //  standard 444-29 H19 code ROM
            if (comboBox3.SelectedIndex != 1)
            {   // the offset from 0xF800 (top of vid mem)
                start_address = ((int)H19MEM.Raw[H19VidSA + 1] << 8) | ((int)H19MEM.Raw[H19VidSA]);
            }
            //  compute the top of VRAM for Super-19 ROM (handled differently then standard ROM)
            else
            {   // the actual top of vid mem
                start_address = ((int)H19MEM.Raw[H19VidOr + 1] << 8) | ((int)H19MEM.Raw[H19VidOr]);
            }
            for (int j = 0; j < 25; j++)
            {
                if (j == 24 && (H19MEM.Raw[H19ModeI] & 0x80) == 0x00)
                {
                    continue;
                }
                for (int i = 0; i < 80; i++)
                {
                    int n = 0;
                    if (comboBox3.SelectedIndex != 1)
                    {
                        n = 0xF800 + ((start_address + (j * 80) + i) & 0x7FF);
                    }
                    else
                    {
                        n = start_address + (((j * 80) + i) & 0x7FF);
                    }
                    int c = H19MEM.Raw[n];
                    p.X = (float)((int)(i * H19ScreenCellWidth));
                    p.Y = (float)((int)(j * H19ScreenCellHeight));
                    H19FontSprite.Draw(H19Font[c], p, color);
                }
            }

            if (bH19CursorOn)
            {
                int i = (126 - 3) - 96;
                if ((H19MEM.Raw[H19ModeB] & 0x01) == 0x01)
                {
                    i = 112 - 96 + 128;
                }
                p.X = (int)H19MEM.Raw[H19CursH] * H19ScreenCellWidth;
                p.Y = (int)H19MEM.Raw[H19CursV] * H19ScreenCellHeight;
                H19FontSprite.Draw(H19Font[i], p, color);
            }

            H19FontSprite.End();

            H19RenderDevice.Present();

            FrameCount++;
        }

        public void SetSwitchButtons()
        {
            bSetSwitchButtons = true;
            for (int i = 0; i < 8; i++)
            {
                int n = i * 2;
                if ((SW401 & (1 << i)) == 0)
                {
                    SW401Button[n].Checked = true;
                }
                else
                {
                    SW401Button[n + 1].Checked = true;
                }
                if ((SW402 & (1 << i)) == 0)
                {
                    SW402Button[n].Checked = true;
                }
                else
                {
                    SW402Button[n + 1].Checked = true;
                }
            }
            bSetSwitchButtons = false;
        }

        public void SetSwitchBits()
        {
            if (bSetSwitchButtons)
            {
                return;
            }
            for (int i = 0; i < 8; i++)
            {
                int n = i * 2;
                if (!SW401Button[n].Checked)
                {
                    SW401 |= 0x01 << i;
                }
                else
                {
                    SW401 &= ~(0x01 << i);
                }
                if (!SW402Button[n].Checked)
                {
                    SW402 |= 0x01 << i;
                }
                else
                {
                    SW402 &= ~(0x01 << i);
                }
            }
        }

        public void SetBaudRateSelection()
        {
            int baud_rate = (SW401 & 0x0F);
            int baud_index = baud_rate;
            if (baud_index >= 0 && baud_index < 14)
            {
                comboBox2.SelectedIndex = baud_index;
            }
        }

        public void SW401Changed()
        {
            SetSwitchBits();
            SetBaudRateSelection();
        }

        public void SW402Changed()
        {
            SetSwitchBits();
            SetBaudRateSelection();
        }

        public void H19Init()
        {
            if (bH19Init)
            {
                return;
            }

            if (checkBox6.Checked)
            {
                H19Scale.X = 1;
                H19Scale.Y = 1;
            }

            H19RenderSurface = new H19Panel();
            H19RenderSurface.Text = "H19 Emulator Output";
            H19RenderSurface.ClientSize = new Size((int)(H19Scale.X * H19ScreenCellWidth) * 80, (int)(H19Scale.Y * H19ScreenCellHeight) * 25);
            H19RenderSurface.CausesValidation = false;
            H19RenderSurface.Visible = true;

            try
            {
                H19RenderParams = new PresentationParameters();
                H19RenderParams.BackBufferHeight = H19RenderSurface.ClientSize.Height;
                H19RenderParams.BackBufferWidth = H19RenderSurface.ClientSize.Width;
                H19RenderParams.DeviceWindowHandle = H19RenderSurface.Handle;
                H19RenderParams.IsFullScreen = false;
                H19RenderParams.MultiSampleType = MultiSampleType.FourSamples;
                H19RenderParams.MultiSampleQuality = 0;
                H19RenderDevice = new GraphicsDevice(GraphicsAdapter.DefaultAdapter, DeviceType.Hardware, H19RenderSurface.Handle, H19RenderParams);
            }
            catch (DeviceNotSupportedException e)
            {
                MessageBox.Show(string.Format("{0}", e.Message));
                Close();
                return;
            }

            H19FontSprite = new SpriteBatch(H19RenderDevice);

            H19RenderSurface.KeyDown += new KeyEventHandler(H19RenderSurface_KeyDown);
            H19RenderSurface.Paint += new PaintEventHandler(H19Form_Paint);
            H19RenderSurface.GotFocus += new EventHandler(H19RenderSurface_GotFocus);
            H19RenderSurface.LostFocus += new EventHandler(H19RenderSurface_LostFocus);

            H19RenderSurface.FormClosing += new FormClosingEventHandler(H19RenderSurface_FormClosing);

            H19LoadFont();
            bH19Init = true;
        }

        public void H19RenderSurfaceSetFocus()
        {
            H19RenderSurface.Focus();
        }

        void H19RenderSurface_GotFocus(object sender, EventArgs e)
        {
            bStepping = false;
            H19Z80.StatementsToFetch = -1;
            H19Z80.Execute();
            button1.Enabled = false;
        }

        void H19RenderSurface_LostFocus(object sender, EventArgs e)
        {
            H19Z80.StatementsToFetch = 1;
            button1.Enabled = true;
        }

        void H19RenderSurface_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                serialPort1.Close();
            }
            H19Z80.Reset();
            H19IO.ResetPorts();
            bH19Init = false;
        }

        //  copies the H19 font to XNA textures
        public void H19LoadFont()
        {
            int texture_size_w = 1;
            int font_width = H19FontWidth >> 1;
            while (font_width > 0)
            {
                texture_size_w <<= 1;
                font_width >>= 1;
            }

            int texture_size_h = 1;
            int font_height = H19FontHeight >> 1;
            while (font_height > 0)
            {
                texture_size_h <<= 1;
                font_height >>= 1;
            }

            int texture_size = texture_size_h;
            if (texture_size_w > texture_size_h)
            {
                texture_size = texture_size_w;
            }

            BinaryReader reader = new BinaryReader(File.Open(string.Format("{0}\\ROMS\\2716_444-29_H19FONT.BIN", Application.StartupPath), FileMode.Open));
            for (int i = 0; i < 128; i++)
            {
                System.Drawing.Bitmap nor = new System.Drawing.Bitmap(texture_size, texture_size);
                System.Drawing.Bitmap rev = new System.Drawing.Bitmap(texture_size, texture_size);
                for (int j = 0; j < H19FontHeight; j++)
                {
                    byte c = reader.ReadByte();
                    if (j >= 10)
                    {
                        continue;
                    }
                    int bit = 0x80;
                    for (int k = 0; k < H19FontWidth; k++)
                    {
                        if ((c & bit) != 0)
                        {
                            nor.SetPixel(k, j, System.Drawing.Color.White);
                            rev.SetPixel(k, j, System.Drawing.Color.Black);
                        }
                        else
                        {
                            nor.SetPixel(k, j, System.Drawing.Color.Black);
                            rev.SetPixel(k, j, System.Drawing.Color.White);
                        }
                        bit >>= 1;
                    }
                }

                Rectangle rect = new Rectangle(0, 0, nor.Width, nor.Height);
                System.Drawing.Imaging.BitmapData bitmap_data = nor.LockBits(rect, System.Drawing.Imaging.ImageLockMode.ReadOnly, nor.PixelFormat);
                int count = bitmap_data.Stride * nor.Height;
                byte[] nor_bytes = new byte[count];
                Marshal.Copy(bitmap_data.Scan0, nor_bytes, 0, count);
                nor.UnlockBits(bitmap_data);
                H19Font[i] = new Texture2D(H19RenderDevice, texture_size, texture_size, 1, TextureUsage.None, H19RenderDevice.PresentationParameters.BackBufferFormat);
                H19Font[i].SetData<byte>(nor_bytes);

                bitmap_data = rev.LockBits(rect, System.Drawing.Imaging.ImageLockMode.ReadOnly, rev.PixelFormat);
                Marshal.Copy(bitmap_data.Scan0, nor_bytes, 0, count);
                rev.UnlockBits(bitmap_data);
                H19Font[i + 128] = new Texture2D(H19RenderDevice, texture_size, texture_size, 1, TextureUsage.None, H19RenderDevice.PresentationParameters.BackBufferFormat);
                H19Font[i + 128].SetData<byte>(nor_bytes);
            }
            reader.Close();
        }

        void H19RenderSurface_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.ControlKey)
            {
                return;
            }
            else if (e.KeyCode == Keys.ShiftKey)
            {
                return;
            }
            else if (e.KeyCode == Keys.Alt)
            {
                return;
            }
            else if (e.KeyCode == Keys.CapsLock)
            {
                return;
            }
            else if (e.KeyCode == Keys.NumLock)
            {
                return;
            }
            else if (e.KeyCode == Keys.Pause)
            {
                return;
            }
            else if (e.KeyCode == Keys.PrintScreen)
            {
                return;
            }
            else if (e.KeyCode == Keys.F11)
            {
                return;
            }
            else if (e.KeyCode == Keys.F12)
            {
                return;
            }
            if (Control.IsKeyLocked(Keys.CapsLock))
            {
                H19IO.Ports[0xA0] &= 0xFD;
            }
            else
            {
                H19IO.Ports[0xA0] |= 0x02;
            }
            char c = (char)(e.KeyValue & 0x7F);
            if ((e.Modifiers & Keys.Shift) != 0)
            {
                H19IO.Ports[0xA0] |= 0x01;
                switch (e.KeyCode)
                {
                    case Keys.D1:
                        c = '!';
                        break;
                    case Keys.D3:
                        c = '#';
                        break;
                    case Keys.D4:
                        c = '$';
                        break;
                    case Keys.D5:
                        c = '%';
                        break;
                    case Keys.OemMinus:
                        c = '_';
                        break;
                    case Keys.Oemplus:
                        c = '+';
                        break;
                    case Keys.Oemtilde:
                        c = '`';
                        break;
                    case Keys.OemPipe:
                        c = '|';
                        break;
                    case Keys.OemSemicolon:
                        c = ';';
                        break;
                    case Keys.OemQuotes:
                        c = (char)0x27;
                        break;
                    case Keys.Oemcomma:
                        c = '<';
                        break;
                    case Keys.OemPeriod:
                        c = '>';
                        break;
                    case Keys.OemQuestion:
                        c = '?';
                        break;
                    case Keys.F10:
                        H19Reset();
                        return;
                        break;
                    default:
                        if (c == '[')
                        {
                            H19IO.Ports[0xA0] &= 0xFE;
                            c = '{';
                        }
                        else if (c == ']')
                        {
                            c = '{';
                        }
                        break;
                }
            }
            else
            {
                H19IO.Ports[0xA0] &= 0xFE;
                switch (e.KeyCode)
                {
                    case Keys.Oemtilde:
                        c = '`';
                        break;
                    case Keys.OemMinus:
                        c = '-';
                        break;
                    case Keys.Oemplus:
                        c = '=';
                        break;
                    case Keys.OemBackslash:
                        c = (char)0x5C;
                        break;
                    case Keys.OemSemicolon:
                        c = ';';
                        break;
                    case Keys.OemQuotes:
                        c = (char)0x27;
                        break;
                    case Keys.Oemcomma:
                        c = ',';
                        break;
                    case Keys.OemPeriod:
                        c = '.';
                        break;
                    case Keys.OemQuestion:
                        c = '/';
                        break;
                    case Keys.F10:
                        return;
                        break;
                    default:
                        if (c == ']')
                        {
                            H19IO.Ports[0xA0] |= 0x01;
                            c = '[';
                        }
                        else
                        {
                            if (c >= 'A' && c <= 'Z')
                            {
                                c |= (char)0x20;
                            }
                        }
                        break;
                }
            }
            if ((e.Modifiers & Keys.Control) != 0)
            {
                c |= (char)0x80;
            }
            else
            {
                if (e.KeyCode == Keys.F1)
                {
                    c = (char)0;
                }
                else if (e.KeyCode == Keys.F2)
                {
                    c = (char)1;
                }
                else if (e.KeyCode == Keys.F3)
                {
                    c = (char)2;
                }
                else if (e.KeyCode == Keys.F4)
                {
                    c = (char)3;
                }
                else if (e.KeyCode == Keys.F5)
                {
                    c = (char)4;
                }
                else if (e.KeyCode == Keys.F6)
                {
                    c = (char)5;
                }
                else if (e.KeyCode == Keys.F7)
                {
                    c = (char)6;
                }
                else if (e.KeyCode == Keys.F8)
                {
                    c = (char)7;
                }
                else if (e.KeyCode == Keys.F9)
                {
                    c = (char)14;
                }
                
                else if (e.KeyCode == Keys.NumPad0 || e.KeyCode == Keys.Insert)
                {
                    if (e.KeyCode == Keys.Insert)
                    {
                        H19IO.Ports[0xA0] |= 0x01;
                    }
                    c = (char)16;
                }
                else if (e.KeyCode == Keys.NumPad1 || e.KeyCode == Keys.End)
                {
                    if (e.KeyCode == Keys.End)
                    {
                        H19IO.Ports[0xA0] |= 0x01;
                    }
                    c = (char)17;
                }
                else if (e.KeyCode == Keys.NumPad2 || e.KeyCode == Keys.Down)
                {
                    if (e.KeyCode == Keys.Down)
                    {
                        H19IO.Ports[0xA0] |= 0x01;
                    }
                    c = (char)18;
                }
                else if (e.KeyCode == Keys.NumPad3 || e.KeyCode == Keys.PageDown)
                {
                    if (e.KeyCode == Keys.PageDown)
                    {
                        H19IO.Ports[0xA0] |= 0x01;
                    }
                    c = (char)19;
                }
                else if (e.KeyCode == Keys.NumPad4 || e.KeyCode == Keys.Left)
                {
                    if (e.KeyCode == Keys.Left)
                    {
                        H19IO.Ports[0xA0] |= 0x01;
                    }
                    c = (char)20;
                }
                else if (e.KeyCode == Keys.NumPad5)
                {
                    c = (char)21;
                }
                else if (e.KeyCode == Keys.NumPad6 || e.KeyCode == Keys.Right)
                {
                    if (e.KeyCode == Keys.Right)
                    {
                        H19IO.Ports[0xA0] |= 0x01;
                    }
                    c = (char)22;
                }
                else if (e.KeyCode == Keys.NumPad7 || e.KeyCode == Keys.Home)
                {
                    if (e.KeyCode == Keys.Home)
                    {
                        H19IO.Ports[0xA0] |= 0x01;
                    }
                    c = (char)23;
                }
                else if (e.KeyCode == Keys.NumPad8 || e.KeyCode == Keys.Up)
                {
                    if (e.KeyCode == Keys.Up)
                    {
                        H19IO.Ports[0xA0] |= 0x01;
                    }
                    c = (char)24;
                }
                else if (e.KeyCode == Keys.NumPad9 || e.KeyCode == Keys.PageUp)
                {
                    if (e.KeyCode == Keys.PageUp)
                    {
                        H19IO.Ports[0xA0] |= 0x01;
                    }
                    c = (char)25;
                }
                //else if (e.KeyCode == Keys.OemPeriod)
                //{
                //    c = (char)26;
                //}
                else if (e.KeyCode == Keys.Enter)
                {
                    c = (char)28;
                }
                
                else if (e.KeyCode == Keys.Scroll)
                {
                    c = (char)31;
                }
            }
            KeyboardCharInsert(c);
        }
        /*
        char KeyPadDecode(char c)
        {
            if ((H19MEM.Raw[H19ModeB] & 0x40) == 0x40 || (H19IO.Ports[0xA0]&0x01) == 0x01)
            {   //  keypad shifted mode
                if (c >= '1' && c <= '9')
                {
                    KeyboardCharInsert((char)0x1B);
                    switch (c)
                    {
                        case '1':
                            c = 'L';
                            break;
                        case '2':
                            c = 'B';
                            break;
                        case '3':
                            c = 'M';
                            break;
                        case '4':
                            c = 'D';
                            break;
                        case '5':
                            c = 'H';
                            break;
                        case '6':
                            c = 'C';
                            break;
                        case '7':
                            if ((H19MEM.Raw[H19ModeA] & 0x40) == 0x40)
                            {
                                c = 'O';
                            }
                            else
                            {
                                c = '@';
                            }
                            break;
                        case '8':
                            c = 'A';
                            break;
                        case '9':
                            c = 'N';
                            break;
                    }
                }
            }
            else if ((H19MEM.Raw[H19ModeB] & 0x80) == 0x80)
            {   //  keypad alternate mode
                KeyboardCharInsert((char)0x1B);
                if ((H19MEM.Raw[H19ModeB] & 0x20) == 0x20)
                {   //  ANSI ESC mode
                    KeyboardCharInsert('O');
                }
                else
                {
                    KeyboardCharInsert('?');
                }
                switch (c)
                {
                    case '0':
                        c = 'p';
                        break;
                    case '1':
                        c = 'q';
                        break;
                    case '2':
                        c = 'r';
                        break;
                    case '3':
                        c = 's';
                        break;
                    case '4':
                        c = 't';
                        break;
                    case '5':
                        c = 'u';
                        break;
                    case '6':
                        c = 'v';
                        break;
                    case '7':
                        c = 'w';
                        break;
                    case '8':
                        c = 'x';
                        break;
                    case '9':
                        c = 'y';
                        break;
                    case '.':
                        c = 'n';
                        break;
                    case (char)0x0D:
                        c = 'M';
                        break;
                }
            }
            return (c);
        }

        char KeyDecodeFunctionKey(char c)
        {
            KeyboardCharInsert((char)0x1B);
            if ((H19MEM.Raw[H19ModeB] & 0x20) == 0x20)
            {   //  ANSI ESC mode
                KeyboardCharInsert('O');
            }
            return (c);
        }

        void panel1_PreviewKeyDown(object sender, PreviewKeyDownEventArgs e)
        {
            char c = (char)(e.KeyValue & 0x7F);
            if (e.KeyCode == Keys.ControlKey)
            {
                return;
            }
            if (e.KeyCode == Keys.ShiftKey)
            {
                return;
            }
            if (e.KeyCode == Keys.Alt)
            {
                return;
            }
            if (Control.IsKeyLocked(Keys.CapsLock) == false)
            {
                H19IO.Ports[0xA0] |= 0x02;
            }
            else
            {
                H19IO.Ports[0xA0] &= 0xFD;
            }
            if (e.Modifiers == Keys.Control)
            {
                //c &= (char)0x1F;
                c |= (char)0x80;
            }
            else if (e.Modifiers == Keys.Shift)
            {
                H19IO.Ports[0xA0] |= 0x01;
                switch (e.KeyCode)
                {
                    case Keys.D0:
                        c = ')';
                        break;
                    case Keys.D1:
                        c = '!';
                        break;
                    case Keys.D2:
                        c = '@';
                        break;
                    case Keys.D3:
                        c = '#';
                        break;
                    case Keys.D4:
                        c = '$';
                        break;
                    case Keys.D5:
                        c = '%';
                        break;
                    case Keys.D6:
                        c = '^';
                        break;
                    case Keys.D7:
                        c = '&';
                        break;
                    case Keys.D8:
                        c = '*';
                        break;
                    case Keys.D9:
                        c = '(';
                        break;
                    case Keys.OemBackslash:
                        c = '|';
                        break;
                    case Keys.OemCloseBrackets:
                        c = '}';
                        break;
                    case Keys.Oemcomma:
                        c = '<';
                        break;
                    case Keys.OemMinus:
                        c = '_';
                        break;
                    case Keys.OemOpenBrackets:
                        c = '{';
                        break;
                    case Keys.OemPeriod:
                        c = '>';
                        break;
                    case Keys.OemPipe:
                        c = '|';
                        break;
                    case Keys.Oemplus:
                        c = '+';
                        break;
                    case Keys.OemQuestion:
                        c = '?';
                        break;
                    case Keys.OemQuotes:
                        c = '"';
                        break;
                    case Keys.OemSemicolon:
                        c = ':';
                        break;
                    case Keys.Oemtilde:
                        c = '~';
                        break;
                    case Keys.F10:
                        H19Reset();
                        return;
                        break;
                }
            }
            else
            {
                H19IO.Ports[0xA0] &= 0xFE;
                switch (e.KeyCode)
                {
                    case Keys.OemBackslash:
                        c = (char)0x5C;
                        break;
                    case Keys.OemCloseBrackets:
                        c = ']';
                        break;
                    case Keys.Oemcomma:
                        c = ',';
                        break;
                    case Keys.OemMinus:
                        c = '-';
                        break;
                    case Keys.OemOpenBrackets:
                        c = '[';
                        break;
                    case Keys.OemPeriod:
                        c = '.';
                        break;
                    case Keys.OemPipe:
                        c = (char)0x5C;
                        break;
                    case Keys.Oemplus:
                        c = '=';
                        break;
                    case Keys.OemQuestion:
                        c = '/';
                        break;
                    case Keys.OemQuotes:
                        c = (char)0x27;
                        break;
                    case Keys.OemSemicolon:
                        c = ';';
                        break;
                    case Keys.Oemtilde:
                        c = '`';
                        break;
                    case Keys.NumPad0:
                        c = '0';
                        break;
                    case Keys.NumPad1:
                    case Keys.End:
                        c = '1';
                        break;
                    case Keys.NumPad2:
                    case Keys.Down:
                        c = '2';
                        break;
                    case Keys.NumPad3:
                    case Keys.PageDown:
                        c = '3';
                        break;
                    case Keys.NumPad4:
                    case Keys.Left:
                        c = '4';
                        break;
                    case Keys.NumPad5:
                        c = '5';
                        break;
                    case Keys.NumPad6:
                    case Keys.Right:
                        c = '6';
                        break;
                    case Keys.NumPad7:
                    case Keys.Home:
                        c = '7';
                        break;
                    case Keys.NumPad8:
                    case Keys.Up:
                        c = '8';
                        break;
                    case Keys.NumPad9:
                    case Keys.PageUp:
                        c = '9';
                        break;
                    case Keys.Insert:
                        c = '0';
                        break;
                    case Keys.Delete:
                        c = '.';
                        break;
                    case Keys.F1:
                        KeyboardCharInsert((char)0x1B);
                        c = 'S';
                        break;
                    case Keys.F2:
                        KeyboardCharInsert((char)0x1B);
                        c = 'T';
                        break;
                    case Keys.F3:
                        KeyboardCharInsert((char)0x1B);
                        c = 'U';
                        break;
                    case Keys.F4:
                        KeyboardCharInsert((char)0x1B);
                        c = 'V';
                        break;
                    case Keys.F5:
                        KeyboardCharInsert((char)0x1B);
                        c = 'W';
                        break;
                    case Keys.F7:   //  blue
                        KeyboardCharInsert((char)0x1B);
                        c = 'P';
                        break;
                    case Keys.F8:   //  red
                        KeyboardCharInsert((char)0x1B);
                        c = 'Q';
                        break;
                    case Keys.F9:   //  gray
                        KeyboardCharInsert((char)0x1B);
                        c = 'R';
                        break;
                    case Keys.F10:  //  RESET
                        return;
                        break;
                    default:
                        if (e.KeyValue >= 'A' && e.KeyValue <= 'Z')
                        {
                            c |= (char)0x20;
                        }
                        break;
                }
            }
            KeyboardCharInsert(c);
        }
        */
        public void KeyboardCharInsert(char c)
        {
            KeyboardBuffer[KeyboardBufferEnd] = c;
            KeyboardBufferEnd = (KeyboardBufferEnd + 1) % 64;
        }

        public char KeyboardBufferRead()
        {
            char k = KeyboardBuffer[KeyboardBufferBeg];
            KeyboardBufferBeg = (KeyboardBufferBeg + 1) % 64;
            return (k);
        }

        public bool KeyboardBufferStatus()
        {
            if (KeyboardBufferBeg != KeyboardBufferEnd)
            {
                return (true);
            }
            return (false);
        }

        //  offline checkbox
        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        //  COM port combobox
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        //  baud rate combobox
        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            SW401 = (SW401 & 0xF0) | comboBox2.SelectedIndex;
            SetSwitchButtons();
        }

        //  code ROM combobox
        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            H19LoadROM();
        }

        //  keyboard ROM combobox
        private void comboBox4_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        //  font ROM combobox
        private void comboBox5_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        //  SW401 - 0 (on)
        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            SW401Changed();
        }

        //  SW401 - 0 (off)
        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            SW401Changed();
        }

        //  SW401 - 1 (on)
        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            SW401Changed();
        }

        //  SW401 - 1 (off)
        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {
            SW401Changed();
        }

        //  SW401 - 2 (on)
        private void radioButton5_CheckedChanged(object sender, EventArgs e)
        {
            SW401Changed();
        }

        //  SW401 - 2 (off)
        private void radioButton6_CheckedChanged(object sender, EventArgs e)
        {
            SW401Changed();
        }

        //  SW401 - 3 (on)
        private void radioButton7_CheckedChanged(object sender, EventArgs e)
        {
            SW401Changed();
        }

        //  SW401 - 3 (off)
        private void radioButton8_CheckedChanged(object sender, EventArgs e)
        {
            SW401Changed();
        }

        //  SW401 - 4 (on)
        private void radioButton9_CheckedChanged(object sender, EventArgs e)
        {
            SW401Changed();
        }

        //  SW401 - 4 (off)
        private void radioButton10_CheckedChanged(object sender, EventArgs e)
        {
            SW401Changed();
        }

        //  SW401 - 5 (on)
        private void radioButton11_CheckedChanged(object sender, EventArgs e)
        {
            SW401Changed();
        }

        //  SW401 - 5 (off)
        private void radioButton12_CheckedChanged(object sender, EventArgs e)
        {
            SW401Changed();
        }

        //  SW401 - 6 (on)
        private void radioButton13_CheckedChanged(object sender, EventArgs e)
        {
            SW401Changed();
        }

        //  SW401 - 6 (off)
        private void radioButton14_CheckedChanged(object sender, EventArgs e)
        {
            SW401Changed();
        }

        //  SW401 - 7 (on)
        private void radioButton15_CheckedChanged(object sender, EventArgs e)
        {
            SW401Changed();
        }

        //  SW401 - 7 (off)
        private void radioButton16_CheckedChanged(object sender, EventArgs e)
        {
            SW401Changed();
        }

        //  SW402 - 0 (on)
        private void radioButton32_CheckedChanged(object sender, EventArgs e)
        {
            SW402Changed();
        }

        //  SW402 - 0 (off)
        private void radioButton31_CheckedChanged(object sender, EventArgs e)
        {
            SW402Changed();
        }

        //  SW402 - 1 (on)
        private void radioButton30_CheckedChanged(object sender, EventArgs e)
        {
            SW402Changed();
        }

        //  SW402 - 1 (off)
        private void radioButton29_CheckedChanged(object sender, EventArgs e)
        {
            SW402Changed();
        }

        //  SW402 - 2 (on)
        private void radioButton28_CheckedChanged(object sender, EventArgs e)
        {
            SW402Changed();
        }

        //  SW402 - 2 (off)
        private void radioButton27_CheckedChanged(object sender, EventArgs e)
        {
            SW402Changed();
        }

        //  SW402 - 3 (on)
        private void radioButton26_CheckedChanged(object sender, EventArgs e)
        {
            SW402Changed();
        }

        //  SW402 - 3 (off)
        private void radioButton25_CheckedChanged(object sender, EventArgs e)
        {
            SW402Changed();
        }

        //  SW402 - 4 (on)
        private void radioButton24_CheckedChanged(object sender, EventArgs e)
        {
            SW402Changed();
        }

        //  SW402 - 4 (off)
        private void radioButton23_CheckedChanged(object sender, EventArgs e)
        {
            SW402Changed();
        }

        //  SW402 - 5 (on)
        private void radioButton22_CheckedChanged(object sender, EventArgs e)
        {
            SW402Changed();
        }

        //  SW402 - 5 (off)
        private void radioButton21_CheckedChanged(object sender, EventArgs e)
        {
            SW402Changed();
        }

        //  SW402 - 6 (on)
        private void radioButton20_CheckedChanged(object sender, EventArgs e)
        {
            SW402Changed();
        }

        //  SW402 - 6 (off)
        private void radioButton19_CheckedChanged(object sender, EventArgs e)
        {
            SW402Changed();
        }

        //  SW402 - 7 (on)
        private void radioButton18_CheckedChanged(object sender, EventArgs e)
        {
            SW402Changed();
        }

        //  SW402 - 7 (off)
        private void radioButton17_CheckedChanged(object sender, EventArgs e)
        {
            SW402Changed();
        }

        //  CONNECT button (start the emulator)
        private void button1_Click(object sender, EventArgs e)
        {
            if (!bH19Init)
            {
                H19Init();
                if (!serialPort1.IsOpen && comboBox1.Items.Count > 0)
                {
                    serialPort1.PortName = comboBox1.SelectedItem.ToString();
                    string baud_rate = comboBox2.GetItemText(comboBox2.SelectedItem);
                    serialPort1.BaudRate = int.Parse(baud_rate);
                    if ((SW401 & 0x10) != 0)
                    {
                        if ((SW401 & 0x20) != 0)
                        {
                            serialPort1.Parity = Parity.Even;
                        }
                        else
                        {
                            serialPort1.Parity = Parity.Odd;
                        }
                        if ((SW401 & 0x40) != 0)
                        {
                        }
                    }
                    else
                    {
                        serialPort1.Parity = Parity.None;
                    }
                    serialPort1.Open();
                }
            }
            H19Z80.event_next_event = int.MaxValue;
            H19Z80.Execute();
        }

        private void AddToLog(string s)
        {
            if (checkBox2.Checked)
            {
                listBox1.Items.Add(s);
                listBox1.SelectedIndex = listBox1.Items.Count - 1;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string oct;

            if (Z80DisasmOutput != null)
            {
                return;
            }
            Z80DisasmOutput = new Form2();
            Z80DisasmOutput.SetEmulator(this);
            ushort adr = 0x0000;
            while (adr < 0x1000)
            {
                ushort v = adr;
                int x;
                x = (v / 256);
                int d3 = (x % 8);
                x = x / 8;
                int d4 = (x % 8);
                x = x / 8;
                int d5 = (x % 8);
                x = (v % 256);
                int d0 = (x % 8);
                x = x / 8;
                int d1 = (x % 8);
                x = x / 8;
                int d2 = (x % 8);
                oct = string.Format("{0}{1}{2}.{3}{4}{5}", d5, d4, d3, d2, d1, d0);
                Z80DisasmOutput.AddToListBox(adr, string.Format("{0} {1}", oct, Z80Disasm.Disassemble(ref adr)));
            }
            Z80DisasmOutput.Show();
            Z80DisasmOutput.ScrollToZ80PC();
        }

        private void GotoZ80PC()
        {
            if (Z80DisasmOutput != null)
            {
                Z80DisasmOutput.ScrollToZ80PC();
                Z80DisasmOutput.Focus();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (colorDialog1.ShowDialog() == DialogResult.OK)
            {
                H19ScreenColor = colorDialog1.Color;
                button3.BackColor = H19ScreenColor;
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (ScratchPadDump == null)
            {
                ScratchPadDump = new Form3();
                ScratchPadDump.Show();
            }
            bViewScatchPad = true;
        }
    }
}
