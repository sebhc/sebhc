﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Z80;

namespace H19Emu.H19
{
    //  Power-up primary    (000Q / 0x00)
    //  Power-up secondary  (040Q / 0x20)
    //  COM port            (100Q / 0x40)
    //  CRT controller      (140Q / 0x60)
    //  Keyboard encoder    (200Q / 0x80)
    //  Keyboard status     (240Q / 0xA0)
    //  Key click enable    (300Q / 0xC0)
    //  Bell enable         (340Q / 0xE0)
    public class H19IO : IIO
    {
        private Form1 Emulator;

        public byte[] Ports = new byte[256];

        public H19IO(Form1 form)
        {
            Emulator = form;
        }

        public void ResetPorts()
        {
            for (int i = 0; i < 256; i++)
            {
                Ports[i] = 0;
            }
            Ports[0x42] = 0x01;
            Ports[0xA0] = 0xFF;
        }

        public byte ReadPort(ushort Port)
        {
            byte value = 0xFF;
            byte port = (byte)(Port & 0xFF);

            //  Power-up config (SW401)
            if (port == 0x00)
            {
                value = (byte)Emulator.SW401;
            }
            //  Power-up config (SW402)
            else if (port == 0x20)
            {
                value = (byte)Emulator.SW402;
            }
            else
            {
                value = Ports[port];
            }

            value = Emulator.OnPortRead(port, value);

            return (value);
        }

        public void WritePort(ushort Port, byte Value)
        {
            byte port = (byte)(Port & 0xFF);

            Ports[port] = Value;
            Emulator.OnPortWrite(port, Value);
        }
    }
}
