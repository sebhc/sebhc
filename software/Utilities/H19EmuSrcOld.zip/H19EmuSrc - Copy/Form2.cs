﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Z80;

namespace H19Emu
{
    public partial class Form2 : Form
    {
        public ushort[] Z80PC = new ushort[0x10000];
        public Form1 Emulator;

        //
        //
        //

        public Form2()
        {
            InitializeComponent();
        }

        public void SetEmulator(Form1 emu)
        {
            Emulator = emu;
        }

        public void AddToListBox(ushort adr, string s)
        {
            Z80PC[listBox1.Items.Count] = adr;
            listBox1.Items.Add(s);
        }

        public void ScrollToZ80PC()
        {
            Status Z80Regs = Emulator.H19Z80.Status;
            ushort adr = Z80Regs.PC;
            for (int i = 0; i < Z80PC.Length; i++)
            {
                if (Z80PC[i] == adr)
                {
                    listBox1.SelectedIndex = i;
                    break;
                }
            }
            label1.Text = string.Format("PC: {0}", ToOctalAdr(Z80Regs.PC));
            label2.Text = string.Format("AF: {0}", ToOctalAdr(Z80Regs.AF));
            label3.Text = string.Format("BC: {0}", ToOctalAdr(Z80Regs.BC));
            label4.Text = string.Format("DE: {0}", ToOctalAdr(Z80Regs.DE));
            label5.Text = string.Format("HL: {0}", ToOctalAdr(Z80Regs.HL));
            label6.Text = string.Format("SP: {0}", ToOctalAdr(Z80Regs.SP));
            label7.Text = string.Format("(M) {0}", ToOctal(Emulator.H19MEM.Raw[Z80Regs.HL]));
        }

        public string ToOctalAdr(ushort v)
        {
            int x;
            x = (v / 256);
            int d3 = (x % 8);
            x = x / 8;
            int d4 = (x % 8);
            x = x / 8;
            int d5 = (x % 8);
            x = (v % 256);
            int d0 = (x % 8);
            x = x / 8;
            int d1 = (x % 8);
            x = x / 8;
            int d2 = (x % 8);
            string oct = string.Format("{0}{1}{2}.{3}{4}{5}", d5, d4, d3, d2, d1, d0);
            return (oct);
        }

        public string ToOctal(byte v)
        {
            int x = v;
            int d3 = (x % 8);
            x = x / 8;
            int d4 = (x % 8);
            x = x / 8;
            int d5 = (x % 8);
            string oct = string.Format("{0}{1}{2}", d5, d4, d3);
            return (oct);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Emulator.bStepping = true;
            Emulator.H19Z80.StatementsToFetch = 1;
            Emulator.H19Z80.Execute();
            ScrollToZ80PC();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Emulator.bStepping = false;
            Emulator.BreakPointAdr = 0;
            textBox1.Text = string.Format("{0}", ToOctalAdr(Emulator.BreakPointAdr));
            Emulator.H19Z80.StatementsToFetch = -1;
            Emulator.H19Z80.Execute();
            Emulator.H19RenderSurfaceSetFocus();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            Emulator.BreakPointAdr = Z80PC[listBox1.SelectedIndex];
            textBox1.Text = string.Format("{0}", ToOctalAdr(Emulator.BreakPointAdr));
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Emulator.bStepping = true;
            Emulator.H19Z80.StatementsToFetch = 1;
            ScrollToZ80PC();
        }
    }
}
