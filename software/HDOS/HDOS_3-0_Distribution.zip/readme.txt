These are H37 soft sectored SS/SD images.
