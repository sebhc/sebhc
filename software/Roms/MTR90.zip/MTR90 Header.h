; File "MTR90 Header.H"
;========================================================================================

; Compiler equates
false	equ	0
true	equ	!false

; ASCII Equates
bell	equ	07h
bs	equ	08h
tab	equ	09h
lf	equ	0ah
cr	equ	0dh
esc	equ	1bh

;------------------------------
; System RAM Address Equates
;------------------------------
stack		equ	2280h   ; Top of Stack
usrfwa		equ	2280h   ; User First Working Address in RAM
Start		equ	2000H   ; Dump starting address
iowrk		equ	2002H   ; I/O work area RAM
regi		equ	2005H   ; Index of register under display
MFlag		equ	2008H   ; User option mode bits
CtlFlg		equ	2009H   ; Front Panel Control Bits
refind		equ	200AH   ; Refresh Index (0-7)
abuss		equ	2014H   ; H8 Front panel Address Buss Display
TicCnt		equ	201BH   ; 2msec clock tic counter
RegPtr		equ	201DH   ; Register Pointer
UiVec		equ	201fh   ; Start of User Interrupt Vectors
nmiret		equ	2034H   ; NMI Return Address storage
Data		equ	2036H   ; Output to 0F2H data save (GP Port)
blkicw		equ	2037H   ; H37 Interrupt Return Address
RadixFlg	equ	2039H   ; Radix Flag
ViewHold	equ	203AH   ; Holds address under VIEW
aio_uni		equ	2131H	; Unit number currently selected
aio_dir		equ	2132H   ; Directory Entry
prim		equ	2150H   ; Primary Boot Device port address
tmfg		equ	2151H   ; Timer Interrupt Flag (1=Z47, 0=H17)
mycnt		equ	2152h   ; Counter for timer interrupt
autob		equ	2153h   ; Auto Boot Flag
stk		equ	2154H   ; Stack Pointer for Re-Boot
os_id		equ	2156H   ; Operating System ID (H67)


;========================================================================================
; Machine Instruction definitions
;========================================================================================
MI_Halt		equ	076h		; Halt
MI_Jump		equ	0c3h		; Jump
MI_Ret		equ	0c9h		; Return


;========================================================================================
; I/O Ports
;
;	All references to the H8 front panel ports are trapped by the
;	Z80 NMI of the H88/H89.  OP.CTL will still perform as in an H8
;	in respect to the clock and single step control.  For more
;	information see the NMI routine.

; Writing GpPort
H88B_SS		equ	00000001b	; Single Step enable
H88B_CK		equ	00000010b	; 2mSec clock enable

;	  if  SpdBit4
;HiClkEn		equ	00010000b	; Hi speed clock enable @ Bit4
;	  else
;HiClkEn		equ	00001000b	; Hi speed clock enable @ Bit3
;	  endif
Ram0		equ	00100000b	; Set RAM only memory map

; Reading GpPort
H88_SW		equ	0f2h		; Switch Port (Read)
H88S_AT		equ	10000000b	; Auto boot switch
H88S_BR		equ	01000000b	; Baud Rate switch
H88S_M		equ	00100000b	; Memory Test bit
H88S_DV		equ	00010000b	; =0, boot from device @ 7CH (174Q)
					; =1, boot from device @ 78H (170Q)

; Additions and re-definitions to GpPort Read -> SW501 settings
H88S_RAM	equ	00100000b	; Copy to RAM bit
H88S_MBR	equ	11000000b	; MultiBaud Baud rate switches

; Front Panel hardware control bits
CB_SSI		equ	00010000b	; Single Step interrupt
CB_MTL		equ	00100000b	; Monitor Light
CB_CLI		equ	01000000b	; Clock interrupt enable
CB_SPK		equ	10000000b	; Speaker enable

;	READING GpPort (Sw501)
;	Bits 1,0:
;		00 - Port 7Ch has H17 Hard Sector floppy
;		01 - Z47 Drive
;		10 - PriGide
;		11 - SecGide
;
;	Bits 3,2:
;		00 - Port 78h has Z-89-37 Soft Sector floppy
;		01 - Z47
;		10 - SecGide
;		11 - PriGide
;
;	Bit 4	0 - Boot from port 7Ch drive
;		1 - Boot from port 78h drive
;
; Old Definition:
;	Bit 5	0 - Perform memory test on power up or reset
;		1 - No auto memory test
;
; New Definition:
;	Bit 5	0 - Execute code from ROM @ Slow speed
;		1 - Execute code from RAM @ High speed
;
; If MultiBaud is FALSE:
;	Bit 6	0 -  9,600 Baud Terminal
;		1 - 19,200 Baud Terminal
;	Bit 7	0 - Normal Boot
;		1 - Auto Boot on power up or reset (floppy)
;
; If MultiBaud is TRUE:
;	 Bits	 Baud
;	 7  6	 Rate
;	 ----	------
;	 0  0	 9,600
;	 0  1	19,200
;	 1  0	38,400
;	 1  1	57,600
;
;
;	WRITING GpPort
;	Bit 0	0 - Single-Step disable
;		1 - Single-Step enabled
;	Bit 1	0 - 2mSec Clock disable
;		1 - 2mSec clock enabled
;	Bit 2	Latched bit at mem expansion connector (Bank Select bit 0)
;	Bit 3	Not Used - AnaPro Speed Mod port (0=2Mhz, 1=4Mhz)
;	Bit 4	Latched bit at mem expansion connector (Bank Select bit 1)
;	Bit 5	0 - Selects HDOS memory map (RAM + ROM)
;		1 - Selects CP/M memory map (RAM Only)
;	Bit 6	Latched bit at I/O expansion connector
;	Bit 7	Latched bit at I/O expansion connector






















IP_PAD		equ	0f0h		; Keypad input port
OP_CTL		equ	0f0h		; Control Output port
OP_DIG		equ	0f0h		; Digit Select output port
OP_SEG		equ	0f1h		; Segment Select output port

; H88/H89 control port
H88_CTL		equ	0f2h		; H88/H89 port for the clock and single step
;H88B_CK		equ	00000010b	; 2msec Clock enable
;H88B_SS		equ	00000001b	; Single Step enable

;H88_SW		equ	0f2h		; 8-Position DIP switch
;H88S_AT		equ	10000000b	; Auto Boot switch
;H88S_BR		equ	01000000b	; Baud Rate switch
;H88S_M		equ	00100000b	; Memory Test switch
;H88S_DV		equ	00010000b	; =0 -> Boot from 174-177 port
					; =1 -> Boot from 170-173 port
;H88S_0		equ	00001100b	; Device at 170-173:
					; 00 -> H37
					; 01 -> Z47
					; 10 -> Z67
					; 00 -> Unk
;H88S_4		equ	00000011b	; Device at 174-177:
					; 00 -> H17
					; 01 -> Z47
					; 10 -> Z67
					; 00 -> Unk
; Front Panel hardware control bits
;CB_SSI		equ	00010000b	; Single Step interrupt
;CB_MTL		equ	00100000b	; Monitor Light
;CB_CLI		equ	01000000b	; Clock interrupt enable
;CB_SPK		equ	10000000b	; Speaker enable

;----------------------------------------------------------------------------
; 8250 UART Contgrol and Bit Definitions
SC_ACE		equ	0e8h		; System Console Port
AC_DLY		equ	110		; 220mSec delay for 8250

UR_RBR		equ	0		; Receiver Buffer register offset
UR_THR		equ	0		; Transmitter Holding register offset
UR_DLL		equ	0		; Divisor Latch (LSB) offset
UR_DLM		equ	1		; Divisor Latch (MSB) offset
UR_IER		equ	1		; Interrupt Enable register offset
UC_EDA		equ	00000001b	; Enable Rcvd Data Avail interrupt
UC_TRE		equ	00000010b	; Enable Trans Holding Reg Empty interrupt
UC_RSI		equ	00000100b	; Enable Receiver Status interrupt
UC_MSI		equ	00001000b	; Enable Modem Status interrupt

UR_IIR		equ	2		; Interrupt ID register offset
UC_IIP		equ	00000001b	; Interrupt Pending (0=pending)
UC_IID		equ	00000110b	; Interrupt ID

UR_LCR		equ	3		; Line Control register offset
UC_5BW		equ	00000000b	; 5 bit words
UC_6BW		equ	00000001b	; 6 bit words
UC_7BW		equ	00000010b	; 7 bit words
UC_8BW		equ	00000011b	; 8 Bit words
UC_DLA		equ	10000000b	; Divisor Latch Access

UR_MCR		equ	4		; Modem Control register offset

UR_LSR		equ	5		; Line Status register offset
UC_DR		equ	00000001b	; Data Ready
UC_THE		equ	00100000b	; Thransmitter Holding Reg empty

UR_MSR		equ	6		; Modem Status register offset

;------------------------------
; H17 ROM Routines
;------------------------------
$move		equ	18AAH   ; Move Data routine
$zero		equ     198AH   ; Zero RAM routine
r_abort		equ     1BF6H   ; Reset H17 disk system routine
clock17		equ     1C19H   ; H17 timer interrupt handler
r_read		equ     1C3FH   ; Read H17 routine
sdp3		equ     1E3BH   ; Set Device Parameter routine
whd		equ     1E9DH   ; Wait for Hole Detect routine
wnh		equ     1EB9H   ; Wait for No Hole routine
Boota		equ     1F5AH   ; Boot Vectors
BootaL		equ	0058h	; Length of H17 boot vectors

EiExit		equ	1c17h

;------------------------------
; H17 RAM Addresses
;------------------------------
D_Con		equ     2048H   ; H17 Disk constants
r_sdt		equ     2076H   ; H17 Seek Desired Track routine
d_sdp   	equ     2086H   ; H17 'Set Device Param' routine address
D_Ram   	equ     20A0H   ; H17 Work RAM area
D_RamL		equ	001fh	; Length of RAM work area
D_OeCnt 	equ     20B4H   ; H17 Max error count for operation


;========================================================================================
; H17 Disk Constants and Equates
;========================================================================================
UP_DP		equ	07ch		; Disk data port (read/write)
UP_FC		equ	07dh		; Fill character port (write)
UP_ST		equ	07dh		; Status flags (read)
UP_SC		equ	07eh		; Syn character (write)
UP_SR		equ	07eh		; Sync reset (read)
DP_DC		equ	07fh		; Disk control port

;=======================================================================================
; H37 Disk Constants and Equates
;=======================================================================================
DK_PORT		equ	78h		; Base port address

DK_CON		equ	DK_PORT		; Control Port
DK_INT		equ	DK_PORT+1	; Interface Control

FD_STAT		equ	DK_PORT+2	; Status Port (Read)
FD_CMD		equ	DK_PORT+2	; Command Port (Write)
FD_SEC		equ	DK_PORT+2	; Sector Register (Write)

FD_TRK		equ	DK_PORT+3	; Track Register (Write)
FD_DAT		equ	DK_PORT+3	; Data Port (Read/Write)

; FDC Commands

FDC_RST		equ	00000000b	; Restore
FDC_SEK		equ	00010000b	; Seek
FDC_STP		equ	00100000b	; Step same DIR as previous
FDC_STI		equ	01000000b	; Step IN
FDC_STO		equ	01100000b	; Step OUT
FDC_RDS		equ	10000000b	; Read Sector
FDC_WTS		equ	10100000b	; Write Sector
FDC_RDA		equ	11000000b	; Read Address
FDC_RDT		equ	11100000b	; Read Track
RDC_WTT		equ	11110000b	; Write Track

FDC_FI		equ	11010000b	; Force Interrupt

; Option bits for Restore and Step commands
FDF_UTR		equ	00010000b	; Update Track Reg
FDF_HLB		equ	00001000b	; Head Load at Beginning
FDF_VRF		equ	00000100b	; Vreify Destination

FDF_S06		equ	00000000b	; 6mSec step
FDF_S12		equ	00000001b	; 12mSec step
FDF_S20		equ	00000010b	; 20mSec step
FDF_S30		equ	00000011b	; 30mSec step

; Options for Read & Write commands
FDF_MRF		equ	00010000b	; Multiple Record Flag
FDF_SLF		equ	00001000b	; Sector Length Shift Right
FDF_DLF		equ	00000100b	; 15 (30 mSec) delay flag
FDF_SS1		equ	00000010b	; Side 1 Select
FDF_DDM		equ	00000001b	; Deleted Data Mark

; Status Bit Definitions
FDS_NRD		equ	10000000b	; Not Ready
FDS_WPV		equ	01000000b	; Write Protect
FDS_HLD		equ	00100000b	; Head is loaded
FDS_RTE		equ	00100000b	; Record Type
FDS_WTF		equ	00100000b	; Write Fault
FDS_SEK		equ	00010000b	; Seek Error
FDS_RNF		equ	00010000b	; Record Not Found
FDS_CRC		equ	00001000b	; CRC Error
FDS_TK0		equ	00000100b	; Over Track 0
FDS_LDT		equ	00000100b	; Lost Data
FDS_IND		equ	00000010b	; Index Pulse
FDS_DRQ		equ	00000010b	; Data Request
FDS_BSY		equ	00000001b	; Busy

; Control Port Bit Definitions
CON_EI		equ	00000001b	; Enable interrupt request
CON_DRQ		equ	00000010b	; Data transfer request
CON_MFM		equ	00000100b	; Set MFM recording
CON_MO		equ	00001000b	; All motors on
CON_DS0		equ	00010000b	; Drive 0
CON_DS1		equ	00100000b	; Drive 1
CON_DS2		equ	01000000b	; Drive 2
CON_DS3		equ	10000000b	; Drive 3

; Bits set to select alternate registers
CON_CD		equ	00000000b	; Command/Data registers
CON_ST		equ	00000001b	; Sector/Track registers

;========================================================================================
; Z47 Disk Constants and Equates
;========================================================================================
; Disk interface constants
D_STA		equ	78h		; Interface status port
D_DAT		equ	D_STA+1		; Interface Data port

S_ERR		equ	00000001b	; Error bit
S_DON		equ	00100000b	; Done
S_IEN		equ	01000000b	; Interrupt Enable
S_DTR		equ	10000000b	; Data Transfer Request

S_SW0		equ	00000010b	; DIP Switch 0
S_SW1		equ	00000100b	; DIP switch 1
S_SW2		equ	00001000b	; DIP switch 2
S_SW3		equ	00010000b	; DIP switch 3

W_RES		equ	00000010b	; Reset command

; Z47 Disk Controller Commands
DD_BOOT		equ	0		; Boot
DD_RST		equ	1		; Read controller status
DD_RAS		equ	2		; Read Aux Status
DD_LSC		equ	3		; Load Sector Count

DD_REA		equ	5		; Read Sectors
DD_WRI		equ	6		; Write Sectors

DD_REAB		equ	7		; Read sectors buffered
	
DD_RRDY		equ	16		; Read Ready status

;========================================================================================
; H67 Constants and Equates
;========================================================================================
Base		equ	78h		; Controll base port

RI_DAT		equ	0		; Data In/Out (Read/Write)
RI_CON		equ	1		; Control (Write)
RI_BST		equ	1		; Bus Status (Read)

; Control Register Definitions
BC_SEL		equ	01000000b	; Select and Data Bit 0
BC_IE		equ	00100000b	; Interrupt Enable
BC_RST		equ	00010000b	; Reset
BC_EDT		equ	00000010b	; Enable Data

; Bus Status Register Definitions
BS_REQ		equ	10000000b	; Data Transfer Request

BS_DTD		equ	01000000b	; Data Transfer Direction Mask
BS_IN		equ	00000000b	;  Transfer to host
BS_OUT		equ	01000000b	;  Transfer to Controller

BS_LMB		equ	00100000b	; Last byte in command/data string

BS_MTY		equ	00010000b	; Message Type flag
BS_DAT		equ	00000000b	;  Data
BS_COM		equ	00010000b	;  Command

BS_BSY		equ	00001000b	; Busy

; Status Byte Definitions
ST_LUN		equ	01100000b	; Logical Unit
ST_SPR		equ	00011100b	; Spare
ST_ERR		equ	00000010b	; Error
ST_PER		equ	00000001b	; PArity Error

; Commands
ClassM		equ	11100000b	; Class Mask

Class0		equ	00000000b	; Class 0 commands
Class1		equ	00100000b	; Class 1 commands
Class6		equ	11000000b	; Class 6 commands

OpCodeM		equ	00011111b	; Op-Code mask
LUNM		equ	01100000b	; Logical Unit Mask
LSA_2		equ	00011111b	; Logical Sector Address (2)

; Class 0 Commands
D_TDR		equ	Class0 +0	; Test Drive Ready
D_REC		equ	Class0 +1	; Recalibrate drive
D_RSY		equ	Class0 +2	; Request Syndrome
D_RSE		equ	Class0 +3	; Request Sense

D_REA		equ	Class0 +8	; Read

D_SEK		equ	Class0 +11	; Seek






;========================================================================================
; Addresses in Resident HDOS code
;
; D.CON Detailed Equivalences
;========================================================================================
D_CON		equ	2048h
D_WritA		equ	204Ah
D_WritB		equ	204Bh
D_WritC		equ	204Ch
D_MAIA		equ	204Dh			; Delay count for track timing
D_LPSA		equ	204Eh			; # tries for this sector
D_SDPA		equ	204Fh			; Head Settle delay time
D_SDPB		equ	2050h			; Motor ON delay time
D_STSA		equ	2051h
D_STSB		equ	2052h
D_WHDA		equ	2053h
D_WNHA		equ	2054h
D_WSCA		equ	2055h

;============================================================================
; Jump Vectors for Driver Routine Entry Points
;============================================================================
SYDD		equ	2058h			; H17 Device Driver
D_Mount		equ	205Bh
D_XOK		equ	205Eh			; Exit OK
D_Abort		equ	2061h
D_XIT		equ	2064h
D_Read		equ	2067h			; Read Sector
D_ReadR		equ	206Ah
D_Write		equ	206Dh			; Write Sector
D_CDE		equ	2070h
D_DTS		equ	2073h			; Decode Track and Sector
D_SDT		equ	2076h			; Seek Desired Track
D_MAI		equ	2079h			; Move Arm In
D_MAO		equ	207Ch			; Move Arm Out
D_LPS		equ	207Fh
D_RDB		equ	2082h			; Read Byte
D_SDP		equ	2085h
D_STS		equ	2088h			; Skip This Sector
D_STZ		equ	208Bh			; Seek Track Zero
D_UDLY		equ	208Eh			; Microsecond Delay timer
D_WSC		equ	2091h			; Wait for Sync Character
D_WSP		equ	2094h
D_WNB		equ	2097h			; Write Next Byte
D_ERRT		equ	209Ah
D_DLY		equ	209Dh

;========================================================================================
; EDRAM - Disk RAM Work area Definitions - Zeroed on Boot
;========================================================================================
D_RAM		equ	20A0h
D_TT		equ	20A0h			; Target Track
D_TS		equ	20A1h			; Target Sector
D_DvCtl		equ	20A2h			; Device Control Byte
D_DylMo		equ	20A3h			; Motor On Delay Count
D_DLYHS		equ	20A4h			; Head Settle Delay count
D_TRKPT		equ	20A5h			; (Word) Address in D_DRVTB for Track #
D_VOLPT		equ	20A7h			; (Word) Address in D_DRVTB for Volumn Number
D_DRVTB		equ	20A9h			; Start of 24-byte block holding
						;  Track # and Volumn # for 4 drives
D_SECNT		equ	20B2h			; (Word) Soft Error Count
D_OeCnt		equ	20B4h			; (Byte) Operation Error Count

;========================================================================================
; Global Disk Error Counters
;========================================================================================
D_E_MDS		equ	20B5h			; Missing Data Sync
D_E_CHK		equ	20B7h			; Data Checksum

;========================================================================================
; I/O Operation Counts
;========================================================================================
D_OPR		equ	20BBh			; (Word) Reads
D_OPW		equ	20BDh			; (Word) Writes

;========================================================================================
; HDOS System Data Word storage
;========================================================================================
S_SYSM		equ	20D0h			; FWA of Resident System
S_USRM		equ	20D2h			; LWA User Memory

;========================================================================================
; Device Driver Delayed Load Flags
;========================================================================================
S_DDLDA		equ	20F0h			; Driver Load Address
						;  (high byte = 0 if no load pending
S_DDLEN		equ	20F2h			; Code Length in bytes
S_DDSEC		equ	20F4h
S_DDDTA		equ	20F6h			; Device Address in DevList
S_DDOPC		equ	20F8h			; Open OPCODE pending

;========================================================================================
; Overlay Management Flags
;========================================================================================
S_OVLFL		equ	20F9h			; Overlay Flag
S_UCSF		equ	20FAh			; FWA Swapped User Code
S_UCSL		equ	20FCh			; Length swapped user code
S_OVLS		equ	20FEh			; Size of overlay code
S_OVLE		equ	2100h			; Entry Point of overlay code
S_SSN		equ	2102h			; Swap Area sector Number
S_OSN		equ	2104h			; Overlay Sector Number

;========================================================================================
; Jumps to routines in Resident HDOS code
;========================================================================================
S_FASER	equ		210Bh			; Fatal System Error

;========================================================================================
;
;	End of HDOS-only Equivalences
;
;	Begin XCON/8 Keyset Monitor Equvalences
;========================================================================================
; Active I/O Area storage
;========================================================================================
AIO_GRT	equ	2124h			; (Word) Address of Group Reserve Table
AIO_SPG	equ	2126h			; (Byte) Sectors per Group
AIO_CGN	equ	2127h			; (Byte) Current Group Number
AIO_CSI	equ	2128h			; (Byte) Current Sector Index
AIO_LGN	equ	2129h			; (Byte) Last Group Number
AIO_LSI	equ	212ah			; (Byte) Last Sector Index
AIO_DTA	equ	212bh			; (Word) Device Table Address
AIO_DES	equ	212dh			; (Word) Directory Sector
AIO_DEV	equ	212fh			; (Word) Device Code
AIO_UNI	equ	2131h			; (Byte) Current Unit Number (0-9)
AIO_DIR	equ	2132h			; Directory Entry (DIRLEN # of bytes)

AIO_CNT	equ	2149h			; (Byte) Sector counter
AIO_EOM	equ	214ah			; (Byte) End of Media flag
AIO_EOF	equ	214Bh			; (Byte) End of File flag
AIO_TFP	equ	214Ch			; (Word) Temp file pointer
AIO_CHA	equ	214eh			; (Word) Address of channel block

;========================================================================================
; Sub definition of AIO_DIR Directory Entry
;========================================================================================
Dir_Nam	equ	0			; Offset = 0, 8 bytes for name
Dir_Ext	equ	8			; Offset = 8, 3 bytes for extension
Dir_Pro	equ	11			; Offset = 11, 1 byte for Project
Dir_Ver	equ	12			; Offset = 12, 1 byte for Version
Dir_Clu	equ	13			; Offset = 13, 1 byte for Cluster Size
Dir_Flg	equ	14			; Offset = 14, 1 byte for Flags
; Reserve 1 byte for future use
Dir_Fgn	equ	16			; Offset = 16, 1 byte for First Group #
Dir_Lgn	equ	17			; Offset = 17, 1 byte for Last Group #
Dir_Lsi	equ	18			; Offset = 18, 1 byte for Last Sector
					;  Index (in last group)
Dir_Crd	equ	19			; (Word) Offset = 19, Creation Date
Dir_Ald	equ	21			; (Word) Offset = 21, Last Alteration Date
DirELen	equ	(Dir_Ald - Dir_Nam) + 2	; Directory Entry Length (23 bytes)

;========================================================================================
; User Option Bits (in cell MFlag)
;========================================================================================
UO_HLT	equ	10000000b		; Disable HALT procesing
UO_NFR	equ	CB_CLI			; No refresh of Front Panel
UO_DDU	equ	00000010b		; Disable Display Update
UO_CLK	equ	00000001b		; Allow private interrupt processing

;
; End of File "MTR90 Header.H"
;============================================================================
