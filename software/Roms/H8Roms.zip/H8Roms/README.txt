PAM8 - H8 Front Panel Monitor
=============================
Size:	1K
Eprom required:	2708
Heath Part Number:	444-13
Orginal Date: May, 1976
Author: J.G. Letwin

PAM8 resides in the low 1K bytes of memory starting at 0K. PAM8 provides H8
front panel monitor and control fuctions.  

Major fucntions are:
 - Memory display and alteration
 - Register display and alteration
 - Program execution including breakpoint and single step 
 - Port I/O 
 - Cassette tape I/O
-------------------------------------------------------------------------------

PAM8GO - H8 Front Panel Monitor
===============================
Size:	1K
Eprom required:	2708
Heath Part Number:	444-13
Orginal Date: Aug, 1979
Author: J.W. Tittsier

PAM8GO has all the functions of PAM8 but added the ability to boot from a
single button press if one had the H17 floppy controller present.
-------------------------------------------------------------------------------

PAM8AT - H8 Front Panel Monitor
===============================
Size:	2K
Eprom required:	2716
Heath Part Number:	444-13
Orginal Date: Dec, 1979
Author: J.W. Tittsier

PAM8AT has all the functions of PAM8 but added the ability to boot
automatically from power on if one had the H17 floppy controller present.
-------------------------------------------------------------------------------

XCON8 - H8 Front Panel Monitor
==============================
Size:	2K
Eprom required:	2716
Heath Part Number:	444-70
Orginal Date: Aug, 1980
Author: J.W. Tittsier

XCON8 has all the functions of PAM8AT but added the ability to allow RAM to 
start at zero.
-------------------------------------------------------------------------------

XCON8 - H8 Front Panel Monitor
==============================
Size:	4K
Eprom required:	2732
Heath Part Number:	444-70
Orginal Date: Aug, 1980
Author: G. Chandler

At some point, the AUG 80 issued code was merged with the H17 ROM program, 
and the resulting 4K EPROM was referred to as XCON/8, with a Heath part 
number of 444-70. This is the starting point for the current re-creation.	
The basic ROM program for the Heath H8 computer contains three elements
essential to the H8: the PAM-8 monitor, PAM-8 extensions, and the H17 Floppy
disk code.  The XCON8 EPROM contains all three elements.
-------------------------------------------------------------------------------

PAM37 - H8 Front Panel Monitor
======================================
Size:	4K
Eprom required:	2732
Heath Part Number:	444-140
Orginal Date:
Author:
-------------------------------------------------------------------------------

H17 - H8 Hard Sector Floppy Controller
======================================
Size:	2K
Eprom required:	2716
Heath Part Number:	444-19
Orginal Date: Oct, 1977
Author: J.G. Letwin

This is the code to control the Heath H17 Hard Sector Floppy drives.  It was
later merged into the 4K XCON8 code.
-------------------------------------------------------------------------------
