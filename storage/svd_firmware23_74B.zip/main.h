        extern	Start
	extern	DiskTable
