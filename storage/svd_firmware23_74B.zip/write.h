        extern	DDWriteSector
        extern	SDWriteSector
	extern  H17WriteSector
