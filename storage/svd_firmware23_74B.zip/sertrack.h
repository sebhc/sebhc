
	extern	SerTrack	; serialize a track out
