    extern	GCR6x2Sector
    extern	GCR5x3Sector
    extern	NIBSector
    extern	GCRTrailer
    extern	GCR6x2Map
    extern	GCR5x3Map
