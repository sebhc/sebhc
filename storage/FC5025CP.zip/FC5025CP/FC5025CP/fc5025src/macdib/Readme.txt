INSTALLING MACDIB
=================

To install MacDIB, drag MacDIB to the Applications folder.


INSTALLING THE COMMAND LINE TOOLS (Optional)
=================================

To install the command line tools, double-click
FC5025 Command Line Tools (optional).pkg.
If you are running Tiger, add the following two lines to your .profile:
export PATH=$PATH:/usr/local/bin
export MANPATH=`manpath`:/usr/local/man
