/* Heathkit 10 sector single-density definitions by Les Bird */

#include <stdio.h>
#include <stdint.h>
#ifdef WIN32
#include <winsock.h>
#else
#include <arpa/inet.h>
#endif
#include <usb.h>
#include <string.h>
#include "phys.h"
#include "fc5025.h"
#include "endec.h"
#include "crc.h"

static int min_track(struct phys *this)
{
	return 0;
}

static int max_track_40(struct phys *this)
{
	return 39;
}

static int max_track_80(struct phys *this)
{
	return 79;
}

static int num_sides_1(struct phys *this)
{
    return 0;
}

static int num_sides_2(struct phys *this)
{
    return 1;
}

static int physical_track_40(struct phys *this, int track)
{
	return track * 2;
}

static int physical_track_80(struct phys *this, int track)
{
	return track;
}

static int min_sector(struct phys *this, int track, int side)
{
	return 0;
}

static int max_sector(struct phys *this, int track, int side)
{
	return 9;
}

static int sector_bytes(struct phys *this, int track, int side, int sector)
{
	return 256;
}

// from Northstar MDS which may not be the same as Heath
static unsigned char ns_csum(unsigned char *buf, int count)
{
	unsigned char csum = 0;

	while (count--)
    {
		csum ^= *buf++;
		csum = (csum << 1) | (csum >> 7);
	}
	return csum;
}

static int read_sector(struct phys *this, unsigned char *out, int track, int side, int sector)
{
	//unsigned char id_field_raw[]={0xa1, 0xa1, 0xa1, 0xfe, track, side, sector, 1, 0, 0};
	unsigned int xferlen = 385;
	int xferlen_out;
	unsigned char raw[386] = {0, }, plain[262] = {0, };
	struct {
		uint8_t opcode, flags, format;
		uint16_t bitcell;
		uint8_t sectorhole;
		uint8_t rdelayh; uint16_t rdelayl;
		uint8_t idam, id_pat[12], id_mask[12], dam[3];
	} __attribute__ ((__packed__)) cdb={OPCODE_READ_FLEXIBLE, side, FORMAT_MFM, htons(3333), sector + 1, 0, htons(347), 0xFD, {0, }, {0, }, {0, }};
	
    int status = 0;
    
    // might need to do some enc_mfm() encoding
	status |= fc_bulk_cdb(&cdb, sizeof(cdb), 4000, NULL, raw, xferlen, &xferlen_out);
	if (xferlen_out != xferlen)
    {
		fprintf(stderr,"xferlen=%d out=%d\n", xferlen, xferlen_out);
        for (int i = 0; i < xferlen_out; i += 16)
        {
            char buf[256]={0};
            for (int j = 0; j < 16; j++)
            {
                char s[8]={0};
                sprintf(s, "%02X ", raw[i + j]);
                strcat(buf, s);
            }
            fprintf(stderr, "%s\n", buf);
        }
		status |= 1;
    }
    // need to do some enc_mfm() decoding
	return status;
}

struct phys phys_heath1s40t={
	.min_track = min_track,
	.max_track = max_track_40,
	.num_tracks = phys_gen_num_tracks,
	.min_side = num_sides_1,
	.max_side = num_sides_1,
	.num_sides = phys_gen_num_sides,
	.min_sector = min_sector,
	.max_sector = max_sector,
	.num_sectors = phys_gen_num_sectors,
	.tpi = phys_gen_48tpi,
	.density = phys_gen_low_density,
	.sector_bytes = sector_bytes,
	.track_bytes = phys_gen_track_bytes,
	.physical_track = physical_track_40,
	.best_read_order = phys_gen_best_read_order,
	.read_sector = read_sector,
	.prepare = phys_gen_no_prepare
};

struct phys phys_heath1s80t={
	.min_track = min_track,
	.max_track = max_track_80,
	.num_tracks = phys_gen_num_tracks,
	.min_side = num_sides_1,
	.max_side = num_sides_1,
	.num_sides = phys_gen_num_sides,
	.min_sector = min_sector,
	.max_sector = max_sector,
	.num_sectors = phys_gen_num_sectors,
	.tpi = phys_gen_96tpi,
	.density = phys_gen_low_density,
	.sector_bytes = sector_bytes,
	.track_bytes = phys_gen_track_bytes,
	.physical_track = physical_track_80,
	.best_read_order = phys_gen_best_read_order,
	.read_sector = read_sector,
	.prepare = phys_gen_no_prepare
};

struct phys phys_heath2s40t={
	.min_track = min_track,
	.max_track = max_track_40,
	.num_tracks = phys_gen_num_tracks,
	.min_side = num_sides_1,
	.max_side = num_sides_2,
	.num_sides = phys_gen_num_sides,
	.min_sector = min_sector,
	.max_sector = max_sector,
	.num_sectors = phys_gen_num_sectors,
	.tpi = phys_gen_48tpi,
	.density = phys_gen_low_density,
	.sector_bytes = sector_bytes,
	.track_bytes = phys_gen_track_bytes,
	.physical_track = physical_track_40,
	.best_read_order = phys_gen_best_read_order,
	.read_sector = read_sector,
	.prepare = phys_gen_no_prepare
};

struct phys phys_heath2s80t={
	.min_track = min_track,
	.max_track = max_track_80,
	.num_tracks = phys_gen_num_tracks,
	.min_side = num_sides_1,
	.max_side = num_sides_2,
	.num_sides = phys_gen_num_sides,
	.min_sector = min_sector,
	.max_sector = max_sector,
	.num_sectors = phys_gen_num_sectors,
	.tpi = phys_gen_96tpi,
	.density = phys_gen_low_density,
	.sector_bytes = sector_bytes,
	.track_bytes = phys_gen_track_bytes,
	.physical_track = physical_track_80,
	.best_read_order = phys_gen_best_read_order,
	.read_sector = read_sector,
	.prepare = phys_gen_no_prepare
};
