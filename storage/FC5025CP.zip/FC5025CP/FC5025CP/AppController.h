//
//  AppController.h
//  FC5025CP
//
//  Created by Les Bird on 5/22/13.
//  Copyright (c) 2013 Les Bird. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <libusb.h>

@interface AppController : NSObject <NSComboBoxDelegate, NSComboBoxDataSource>
{
    __weak NSComboBox *_supportedFormatsDropdown;
    __unsafe_unretained NSTextView *_logOutputView;
    __weak NSButton *_readButton;
    __weak NSButton *_formatsButton;
    __weak NSButton *_stopButton;
    __weak NSButton *_readSecButton;
    __weak NSButton *_testButton;
    __weak NSButton *_analyzeButton;
    __weak NSTextField *_customMinSec;
    __weak NSTextField *_customMaxSec;
    __weak NSTextField *_customNumBytes;
    __weak NSTextField *_customMaxTracks;
    __weak NSComboBox *_customNumSides;
    __weak NSComboBox *_customDensity;
    __weak NSComboBox *_customTPI;
}

@property (weak) IBOutlet NSButton *readButton;
- (IBAction)readButtonAction:(id)sender;

@property (weak) IBOutlet NSButton *formatsButton;
- (IBAction)formatsButtonAction:(id)sender;

@property (unsafe_unretained) IBOutlet NSTextView *logOutputView;

@property (weak) IBOutlet NSComboBox *supportedFormatsDropdown;
- (IBAction)supportedFormatsAction:(id)sender;

@property (weak) IBOutlet NSButton *stopButton;
- (IBAction)stopButtonAction:(id)sender;

@property (weak) IBOutlet NSButton *readSecButton;
- (IBAction)readSecAction:(id)sender;

@property (weak) IBOutlet NSButton *testButton;
- (IBAction)testButtonAction:(id)sender;

@property (weak) IBOutlet NSButton *analyzeButton;
- (IBAction)analyzeButtonAction:(id)sender;

@property (weak) IBOutlet NSTextField *customMinSec;
- (IBAction)customMinSectorAction:(id)sender;

@property (weak) IBOutlet NSTextField *customMaxSec;
- (IBAction)customMaxSectorAction:(id)sender;

@property (weak) IBOutlet NSTextField *customNumBytes;
- (IBAction)customNumBytesAction:(id)sender;

@property (weak) IBOutlet NSTextField *customMaxTracks;
- (IBAction)customMaxTracksAction:(id)sender;

@property (weak) IBOutlet NSComboBox *customNumSides;
- (IBAction)customNumSidesAction:(id)sender;

@property (weak) IBOutlet NSComboBox *customDensity;
- (IBAction)customDensityAction:(id)sender;

@property (weak) IBOutlet NSComboBox *customTPI;
- (IBAction)customTPIAction:(id)sender;

-(void)readDiskImage;
-(void)loadFormats;
@end
