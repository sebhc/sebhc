//
//  AppController.m
//  FC5025CP
//
//  Created by Les Bird on 5/22/13.
//  Copyright (c) 2013 Les Bird. All rights reserved.
//

#import "AppController.h"
#import "drives.h"
#import "formats.h"
#import "fc5025.h"
#import "phys.h"

static struct format_info *formats;
static struct format_info *fmt;
static struct phys *fmtphys;

static bool abortAction;

NSInteger readErrors;

NSInteger curSide, curTrack, curSector;
NSMutableArray *formatArray;
NSInteger selectedFormatIndex;

static AppController *globalAppController;

//
//
//

@implementation AppController

@synthesize readButton;
@synthesize readSecButton;
@synthesize formatsButton;
@synthesize stopButton;
@synthesize testButton;
@synthesize analyzeButton;
@synthesize logOutputView;
@synthesize supportedFormatsDropdown;
@synthesize customMinSec;
@synthesize customMaxSec;
@synthesize customNumBytes;
@synthesize customMaxTracks;
@synthesize customNumSides;
@synthesize customDensity;
@synthesize customTPI;

// performs a single sector read - for image_track() and for media test
static bool read_one_sector(struct phys *phys, unsigned char *buf, int track, int side, int sector)
{
	if (phys->read_sector(phys, buf, track, side, sector) != 0)
    {
        return NO;
    }
    return YES;
}

// reads disk track by track and writes to FILE
static void image_track(FILE *f, struct phys *phys, int track, int side)
{
    unsigned char *buf;
    struct sector_list *sector_list, *sector_entry;

    curSide = side;
    curTrack = track;

    int num_sectors = phys->num_sectors(phys, track, side);
    
    readErrors = 0;
    
    fc_SEEK_abs(phys->physical_track(phys, track));

	sector_list=malloc(sizeof(struct sector_list) * num_sectors);
    if (sector_list != NULL)
    {
        phys->best_read_order(phys, sector_list, track, side);
    
        sector_entry = sector_list;
    
        buf = malloc(phys->track_bytes(phys, track, side));
        if (buf != NULL)
        {
            while (num_sectors--)
            {
                int sector = sector_entry->sector;
                curSector = sector;
                
                if (read_one_sector(phys, buf + sector_entry->offset, track, side, sector))
                {
                    [globalAppController sendToTextView:[NSString stringWithFormat:@"READ SIDE %d TRACK %02d SECTOR %02d - SUCCESS\n", side, track, sector]];
                }
                else
                {
                    [globalAppController sendToTextView:[NSString stringWithFormat:@"READ SIDE %d TRACK %02d SECTOR %02d - FAIL\n", side, track, sector]];
                    readErrors++;
                }
                sector_entry++;
                
                if (abortAction)
                {
                    break;
                }
            }
            
            if (f != NULL)
            {
                fwrite(buf, phys->track_bytes(phys, track, side), 1, f);
            }
            
            free(buf);
        }
        
        free(sector_list);
    }
}

// performs an interface self test on the FC5025 - requires drive and any media inserted
static int self_test()
{
	struct {
		uint8_t opcode, board_test, interface_test;
	} __attribute__ ((__packed__)) cdb={OPCODE_SELF_TEST, 0, 1};
    
	fc_bulk_cdb(&cdb, sizeof(cdb), 600, NULL, NULL, 0, NULL);
    
	struct {
		uint32_t signature, tag;
		uint8_t status, sense, asc, ascq;
		uint8_t padding[20];
	} __attribute__ ((__packed__)) csw;
    
	int status = 0;
    int bytes_read = 0;
    char buf[32]={0};
    status |= fc_bulk_cdb(&cdb, sizeof(cdb), 4000, &csw, buf, 32, &bytes_read);
    
    [globalAppController sendToTextView:[NSString stringWithFormat:@"SELF TEST STATUS=%d BYTES=%d\n", status, bytes_read]];
    
    unsigned int e = 0;
    if (bytes_read > 0)
    {
        NSMutableString *str = [[NSMutableString alloc] init];
        for (int i = 0; i < 32; i++)
        {
            [str appendFormat:@"%02X ", buf[i]];
            e += buf[i];
        }
        [globalAppController sendToTextView:str];
    }
    
    [globalAppController sendToTextView:[NSString stringWithFormat:@"ERRORS: %s\n", (e != 0 || status != 0) ? "YES" : "NO"]];
    
    return status;
}

-(void)buttonsOn
{
    [readButton setEnabled:YES];
    [readSecButton setEnabled:YES];
    [stopButton setEnabled:YES];
    [testButton setEnabled:YES];
    [analyzeButton setEnabled:YES];
}

-(void)buttonsOff
{
    [readButton setEnabled:NO];
    [readSecButton setEnabled:NO];
    [stopButton setEnabled:NO];
    [testButton setEnabled:NO];
    [analyzeButton setEnabled:NO];
}

-(void)customOn
{
    [customDensity setEnabled:YES];
    [customMaxSec setEnabled:YES];
    [customMaxTracks setEnabled:YES];
    [customMinSec setEnabled:YES];
    [customNumBytes setEnabled:YES];
    [customNumSides setEnabled:YES];
    [customTPI setEnabled:YES];
}

-(void)customOff
{
    [customDensity setEnabled:NO];
    [customMaxSec setEnabled:NO];
    [customMaxTracks setEnabled:NO];
    [customMinSec setEnabled:NO];
    [customNumBytes setEnabled:NO];
    [customNumSides setEnabled:NO];
    [customTPI setEnabled:NO];
}

-(void)sendToTextView:(NSString *)str
{
    [self performSelectorOnMainThread:@selector(sendToTextViewMain:) withObject:str waitUntilDone:NO];
}

-(void)sendToTextViewMain:(NSString *)str
{
    [[[logOutputView textStorage] mutableString] appendString:str];
    [logOutputView scrollRangeToVisible:NSMakeRange([[logOutputView string] length], 0)];
    NSLog(@"%@", str);
}

-(void)showFormatSpecs
{
    [self sendToTextView:[NSString stringWithFormat:@"\n%s [%s]\n", fmt->id, fmt->desc]];
    [self sendToTextView:[NSString stringWithFormat:@"MinSector=%d\n", fmtphys->min_sector(fmtphys, 0, 0)]];
    [self sendToTextView:[NSString stringWithFormat:@"MaxSector=%d\n", fmtphys->max_sector(fmtphys, 0, 0)]];
    [self sendToTextView:[NSString stringWithFormat:@"SectorBytes=%d\n", fmtphys->sector_bytes(fmtphys, 0, 0, 0)]];
    [self sendToTextView:[NSString stringWithFormat:@"NumTracks=%d\n", fmtphys->max_track(fmtphys)]];
    [self sendToTextView:[NSString stringWithFormat:@"NumSides=%d\n", fmtphys->num_sides(fmtphys)]];
    [self sendToTextView:[NSString stringWithFormat:@"TPI=%d\n", fmtphys->tpi(fmtphys)]];
    [self sendToTextView:[NSString stringWithFormat:@"Density=%d\n\n", fmtphys->density(fmtphys)]];
}
//-----------------
//NSOpenPanel: Displaying a File Open Dialog in OS X 10.7
//-----------------

NSString *lastFileName = nil;

// Any ole method
- (FILE *)openFileForWrite
{
    NSString *file = nil;
    
    // Create a File Open Dialog class.
    NSSavePanel* saveDlg = [NSSavePanel savePanel];
    
    if (lastFileName != nil)
    {
        [saveDlg setNameFieldStringValue:lastFileName];
    }
    [saveDlg setCanCreateDirectories:YES];
    
    // Display the dialog box.  If the OK pressed,
    // process the files.
    if ([saveDlg runModal] == NSOKButton)
    {
        // Gets list of all files selected
        NSURL *fileurl = [saveDlg URL];
        file = [fileurl path];
        if (file != nil)
        {
            lastFileName = [[fileurl absoluteString] lastPathComponent];
            NSLog(@"File: %@", lastFileName);
        }
    }
    
    FILE *fp = nil;
    if (file != nil)
    {
        fp = fopen([file UTF8String], "wb");
    }
    return fp;
}

-(void)readDisk
{
    int track, side;
    
    FILE *fp = [self openFileForWrite];
    
    char *dev_id = open_default_drive();
    if (dev_id != NULL)
    {
        fc_recalibrate();
        
        fmt = &formats[selectedFormatIndex];
        fmtphys = fmt->phys;
        
        [self showFormatSpecs];
        
        fc_set_density(fmtphys->density(fmtphys));
        
        fmtphys->prepare(fmtphys);
        
        for (track = fmtphys->min_track(fmtphys); track <= fmtphys->max_track(fmtphys); track++)
        {
            for (side = fmtphys->min_side(fmtphys); side <= fmtphys->max_side(fmtphys); side++)
            {
                image_track(fp, fmtphys, track, side);
                if (abortAction)
                {
                    goto readDiskDone;
                }
            }
        }
        
    readDiskDone:
        if (abortAction)
        {
            [self sendToTextView:@"\nACTION ABORTED BY USER\n"];
            abortAction = NO;
        }
        else
        {
            [self sendToTextView:[NSString stringWithFormat:@"\nDONE with errors on %ld track(s)\n", readErrors]];
        }
        close_drive();
        
        if (fp != nil)
        {
            fclose(fp);
        }
    }
}

- (IBAction)readButtonAction:(id)sender
{
    [self performSelectorInBackground:@selector(readDisk) withObject:nil];
    //[self readDisk];
}

- (IBAction)stopButtonAction:(id)sender
{
    abortAction = YES;
}

-(void)loadFormats
{
	struct format_info *format;
    
	formats = get_format_list();
    
    if (formatArray != nil)
    {
        formatArray = nil;
    }
    formatArray = [[NSMutableArray alloc] init];
    
	for (format = formats; format->id != nil; format++)
    {
        NSString *str = [[NSString alloc] initWithFormat:@"%s", format->desc];
        [formatArray addObject:str];
	}
}

- (IBAction)formatsButtonAction:(id)sender
{
    [self loadFormats];
    [supportedFormatsDropdown reloadData];

    [self sendToTextView:@"\nFinding all defined formats\n"];

    for (int i = 0; i < formatArray.count; i++)
    {
        struct format_info *format = &formats[i];
        [self sendToTextView:[NSString stringWithFormat:@"%s [%s]\n", format->id, format->desc]];
    }
    
    [self buttonsOn];

    get_drive_list();
    
    globalAppController = self;
}

-(void)comboBoxSelectionDidChange:(NSNotification *)notification
{
    NSInteger idx = [(NSComboBox *)[notification object] indexOfSelectedItem];
    selectedFormatIndex = idx;
    if (formats != NULL)
    {
        fmt = &formats[idx];
        fmtphys = fmt->phys;
        if (strcmp(fmt->id, "custom") == 0)
        {
            [self customOn];
        }
        else
        {
            [self customOff];
        }
        [self showFormatSpecs];
    }
}

-(IBAction)supportedFormatsAction:(id)sender
{
}

-(NSInteger)numberOfItemsInComboBox:(NSComboBox *)aComboBox
{
    return formatArray.count;
}

-(id)comboBox:(NSComboBox *)aComboBox objectValueForItemAtIndex:(NSInteger)index
{
    return [formatArray objectAtIndex:index];
}

// reads a single sector - for media test
- (IBAction)readSecAction:(id)sender
{
    unsigned char buf[1024];
    struct sector_list sector_list[20];
    struct sector_list *sector_entry;
    
    [self sendToTextView:@"\nReading a single sector from the disk to test format compatibility\n"];
    
    char *dev_id = open_default_drive();
    if (dev_id != NULL)
    {
        fc_recalibrate();
        
        fmt = &formats[selectedFormatIndex];
        fmtphys = fmt->phys;
        
        [self showFormatSpecs];
        
        fc_set_density(fmtphys->density(fmtphys));
        
        fmtphys->prepare(fmtphys);
        
        int track = 0;
        int side = 0;
        
        fc_SEEK_abs(fmtphys->physical_track(fmtphys, track));

        fmtphys->best_read_order(fmtphys, sector_list, track, side);
        
        sector_entry = sector_list;
        
        int sector = sector_entry->sector;
        
        if (read_one_sector(fmtphys, buf, track, side, sector))
        {
            [self sendToTextView:[NSString stringWithFormat:@"READ SIDE %d TRACK %02d SECTOR %02d - SUCCESS\n", side, track, sector]];
        }
        else
        {
            [self sendToTextView:[NSString stringWithFormat:@"READ SIDE %d TRACK %02d SECTOR %02d - FAIL\n", side, track, sector]];
        }
        
        close_drive();
    }
}

- (IBAction)testButtonAction:(id)sender
{
    [self sendToTextView:@"\nPerforming a disk interface self-test (media required)\n"];

    char *dev_id = open_default_drive();
    if (dev_id != NULL)
    {
        fc_recalibrate();
        
        self_test();
        
        close_drive();
    }
}

// cycles through all supported formats and tests media - always seems to lock up when trying the 4th format
-(void)analyzeDisk
{
    unsigned char buf[1024];
    struct sector_list sector_list[20]; // C1541 can have up to 20 sectors
    struct sector_list *sector_entry;

    char *dev_id = open_default_drive();
    if (dev_id != NULL)
    {
        for (int i = 0; i < formatArray.count; i++)
        {
            fmt = &formats[i];
            
            fmtphys = fmt->phys;

            fc_recalibrate();
            fc_set_density(fmtphys->density(fmtphys));
        
            fmtphys->prepare(fmtphys);
        
            sector_entry = sector_list;
        
            bool success = NO;
            
            int side = 0;
            int track = 0;
            fc_SEEK_abs(fmtphys->physical_track(fmtphys, track));
            fmtphys->best_read_order(fmtphys, sector_list, track, side);
            if (read_one_sector(fmtphys, buf, track, side, sector_entry->sector)) // test track 0 side 0
            {
                [self sendToTextView:[NSString stringWithFormat:@"%s [%s] - PASS 1\n", fmt->id, fmt->desc]];
                if (fmtphys->num_sides(fmtphys) > 0)
                {
                    side = 1;
                    track = 15;
                    fc_SEEK_abs(fmtphys->physical_track(fmtphys, track));
                    fmtphys->best_read_order(fmtphys, sector_list, track, side);
                    if (read_one_sector(fmtphys, buf, track, side, sector_entry->sector)) // test track 15 side 1
                    {
                        success = YES;
                    }
                    else
                    {
                        [self sendToTextView:[NSString stringWithFormat:@"%s [%s] - FAIL 2\n", fmt->id, fmt->desc]];
                    }
                }
                else
                {
                    success = YES;
                }
            }
            else
            {
                [self sendToTextView:[NSString stringWithFormat:@"%s [%s] - FAIL\n", fmt->id, fmt->desc]];
            }
            
            if (abortAction)
            {
                abortAction = NO;
                break;
            }
        }
        close_drive();
    }
}

- (IBAction)analyzeButtonAction:(id)sender
{
    [self sendToTextView:@"\nTesting all defined formats against the inserted media to find one that is compatible\n"];

    [self performSelectorInBackground:@selector(analyzeDisk) withObject:nil];
}

extern int customMinSectorVal;

- (IBAction)customMinSectorAction:(id)sender
{
    customMinSectorVal = [customMinSec intValue];
}

extern int customMaxSectorVal;

- (IBAction)customMaxSectorAction:(id)sender
{
    customMaxSectorVal = [customMaxSec intValue];
}

extern int customNumBytesVal;

- (IBAction)customNumBytesAction:(id)sender
{
    customNumBytesVal = [customNumBytes intValue];
}

extern int customMaxTracksVal;

- (IBAction)customMaxTracksAction:(id)sender
{
    customMaxTracksVal = [customMaxTracks intValue];
}

extern int customNumSidesVal;

- (IBAction)customNumSidesAction:(id)sender
{
    customNumSidesVal = [customNumSides intValue];
}

extern int customDensityVal;

- (IBAction)customDensityAction:(id)sender
{
    NSString *str = [customDensity stringValue];
    if (str != nil)
    {
        if ([str compare:@"FM"] == NSOrderedSame)
        {
            customDensityVal = 0;
        }
        else
        {
            customDensityVal = 1;
        }
    }
}

extern int customTPIVal;

- (IBAction)customTPIAction:(id)sender
{
    int v = [customTPI intValue];
    if (v == 96)
    {
        customTPIVal = 1;
    }
    else if (v == 100)
    {
        customTPIVal = 2;
    }
    else
    {
        customTPIVal = 0;
    }
}

@end
