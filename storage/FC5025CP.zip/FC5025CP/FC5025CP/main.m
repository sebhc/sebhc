//
//  main.m
//  FC5025CP
//
//  Created by Les Bird on 5/21/13.
//  Copyright (c) 2013 Les Bird. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc, (const char **)argv);
}
