//
//  AppDelegate.m
//  FC5025CP
//
//  Created by Les Bird on 5/21/13.
//  Copyright (c) 2013 Les Bird. All rights reserved.
//

#import "AppDelegate.h"
#import "libusb.h"

@implementation AppDelegate

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification
{
    // Insert code here to initialize your application
}

@end
