;
; Track Functions (track.asm)
;
   extern NextTrack           ; jump to next track
   extern PrevTrack           ; jump to previous track
   extern ZeroTrack	      ; jump to track 0

;;;*******************************************************************
;;; NAME:	ZeroTrackMacro()
;;;
;;; DESCR:	MACRO - resets things back to track 0
;;;
;;; ARGS:	
;;;
;;; RETURNS:	
;;;
;;; NOTES:	- the index hole indicator isn't set by this routine
;;;*******************************************************************
ZeroTrackMacro:	macro
                movf	BASE_LO,W
                movwf	CURBASE_LO
                movf	BASE_HI,W
                movwf	CURBASE_HI
                clrf	CURTRACK
                endm

