;
; Utility Functions (utility.asm)
;
   extern Mod256	      ; used during alignment
   extern ModInverse          ; used during alignment
   extern Multiply	      ; simply does a multiply
   extern XmitWait	      ; returns when able to transmit again
   extern PrintByte	      ; prints out a byte


