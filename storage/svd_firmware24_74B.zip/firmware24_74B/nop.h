
   extern Nop4c			; like "wait" but without the headcheck
   extern Nop5c
   extern Nop6c
   extern Nop7c
   extern Nop8c
   extern Nop9c
   extern Nop10c
   extern Nop11c
   extern Nop12c
   extern Nop13c
   extern Nop14c
   extern Nop15c
   extern Nop16c
   extern Nop17c
   extern Nop18c
