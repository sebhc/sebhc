
    extern  GCR6x2WriteSector
    extern  NIBWriteSector
