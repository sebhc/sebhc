    extern	GCR6x2Sector
    extern	NIBSector
    extern	GCRTrailer
    extern	GCR6x2Map
    extern	rGCR6x2Map
    extern	rGCR6x2MapUnsafe
