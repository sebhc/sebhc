
	extern	SerTrack	; serialize a track out
	extern	SerTrackSecDone	; place to "goto" (return) when done with a sector
