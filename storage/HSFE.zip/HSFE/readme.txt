Burning ATTINY2313 HSFE rom images to chip

1. Install WinAVR from AVR/WinAVR-20090313-install.exe
2. Plugin the Sparkfun AVR Pocket Programmer to a USB port
3. Install the driver from the AVR folder at AVR/pocketprog.inf
4. Open a console window
5. CD to the HSFE folder that has the flash.bat file
6. The AVR Pocket Programmer should be connected to a barebones HSFE PCB with a socket for the ATTINY2313
7. Disconnect the AVR Pocket Programmer USB cable
8. Insert an ATTINY2313 chip into the HSFE barebones board (16 pin socket)
9. Connect the AVR Pocket Programmer USB cable
10. From the console window type "flash.bat"
11. If it does not verify correctly just do it again until the verification passes
12. Type "fuse.bat" to set the fuses
13. Disconnect the AVR Pocket Programmer USB cable and remove the chip - it should be ready for use

lesbird@lesbird.com
January 19, 2013
