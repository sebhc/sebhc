    extern	GCR6x2SectorP1
    extern	GCR5x3SectorP1
    extern	GCRTrailerP1
    extern	NIBSectorP1

