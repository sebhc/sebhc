;
; Utility Functions (utility.asm)
;
   extern Mod256	      ; used during alignment
   extern ModInverse          ; used during alignment
   extern Multiply	      ; simply does a multiply
   extern SerPrintNum	      ; sends a number in hex out to serial
   extern SerPrintNL	      ; prints out a newline
   extern SerPrint1	      ; prints out a value with label (1 byte)
   extern SerPrint2	      ; prints out a value with label (2 bytes)
   extern XmitWait	      ; returns when able to transmit again


