   extern SerialSetup         ; sets up serial port & functions
   extern SerialDispatch      ; called upon interrupt by the serial port
