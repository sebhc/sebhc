	extern	SByte		; serialize a byte out with adj clocking sig
	extern	SByteSimple	; serialize a byte out

	extern	DD0x4e		; generates a DD 0x4e (does auto-increment too)
        extern	DD0x00		; generates a DD 0x00
	extern  DD0xa1S		; generates the special DD 0x41 (missing transition)

        extern  SD0xff		; generates a SD 0xff (does auto-increment too)
        extern  SD0x00		; generates a SD 0x00
