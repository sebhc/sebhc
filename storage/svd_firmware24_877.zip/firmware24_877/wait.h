;;;
;;; wait.h
;;;   includes references for ALL of the different waits
;;;   that are used for either code page 1 or page 2
;;;
   extern Wait6c	      ; the following are "call" versions of "Wait"
   extern Wait7c
   extern Wait8c
   extern Wait9c
   extern Wait10c
   extern Wait11c
   extern Wait12c
   extern Wait13c
   extern Wait14c
   extern Wait15c
   extern Wait16c
   extern Wait17c
   extern Wait18c
   extern Wait19c
   extern Wait20c
   extern Wait21c
   extern Wait22c
   extern Wait23c
   extern Wait24c
   extern Wait25c

   extern Wait6cP1	      ; the following are "call" versions of "Wait"
   extern Wait7cP1
   extern Wait8cP1
   extern Wait9cP1
   extern Wait10cP1
   extern Wait11cP1
   extern Wait12cP1
   extern Wait13cP1
   extern Wait14cP1
   extern Wait15cP1
   extern Wait16cP1
   extern Wait17cP1
   extern Wait18cP1
   extern Wait19cP1
   extern Wait20cP1
   extern Wait21cP1
   extern Wait22cP1
   extern Wait23cP1
   extern Wait24cP1
   extern Wait25cP1
