        extern	DDWriteSector
        extern	SDWriteSector
	extern  H17WriteSector
	extern	PulseSync
