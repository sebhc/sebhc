	extern AltairSector
	extern Altair2Sector
	extern AltairWriteSector
