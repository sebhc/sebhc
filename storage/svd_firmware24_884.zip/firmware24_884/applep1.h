    extern	GCR6x2SectorP1
    extern	GCRTrailerP1
    extern	NIBSectorP1

