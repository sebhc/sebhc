; 
; Interrupt Functions (interrupt.asm)
;
   extern InterruptSetup      ; sets up interrupt processing
   extern Interrupt           ; main interrupt routine

